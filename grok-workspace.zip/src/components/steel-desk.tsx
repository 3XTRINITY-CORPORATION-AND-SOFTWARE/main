import { useEffect, useRef, useState, type ReactNode } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import {
  bounceWav,
  decodeSlot,
  loadDemoBeat,
  pitchLabel,
  playMix,
  pushParams,
  setBeatBuffer,
  setVocalBuffer,
  sharpMix,
  startLiveMic,
  stopLiveMic,
  stopMix,
  toggleVoiceRec,
} from "@/lib/desk/engine";
import { suggestMix } from "@/lib/desk/mix-ai";
import { NOTE_NAMES, useDesk } from "@/lib/desk/store";
import { t, type Lang } from "@/lib/i18n";
import { createSteelRow, listSteelRows, type SteelRow } from "@/lib/steel/rows";
import { useSteel } from "@/lib/steel/store";
import { cn } from "@/lib/utils";

export function SteelDesk() {
  const lang = useSteel((s) => s.lang);
  const d = useDesk();
  const beatRef = useRef<HTMLInputElement>(null);
  const vocalRef = useRef<HTMLInputElement>(null);
  const recRef = useRef<HTMLInputElement>(null);
  const [rows, setRows] = useState<SteelRow[]>([]);
  const [rowBusy, setRowBusy] = useState(false);

  useEffect(() => {
    void listSteelRows({ data: { kind: "mix" } })
      .then(setRows)
      .catch(() => undefined);
  }, []);

  useEffect(() => {
    return () => {
      stopMix();
      stopLiveMic();
    };
  }, []);

  useEffect(() => {
    pushParams();
  }, [d.amount, d.speed, d.tonic, d.mode, d.drive, d.ceiling, d.beatGain, d.vocalGain, d.glue]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.code !== "Space" || e.metaKey || e.ctrlKey || e.altKey) return;
      const tag = (e.target as HTMLElement)?.tagName;
      if (tag === "INPUT" || tag === "SELECT" || tag === "TEXTAREA") return;
      e.preventDefault();
      void onPlay();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  async function onBeat(file: File) {
    try {
      const buf = await decodeSlot(file);
      await setBeatBuffer(buf, file.name);
      toast.success(file.name);
    } catch {
      toast.error(t(lang, "decodeFail"));
    }
  }

  async function onVocal(file: File) {
    try {
      const buf = await decodeSlot(file);
      await setVocalBuffer(buf, file.name);
      toast.success(file.name);
    } catch {
      toast.error(t(lang, "decodeFail"));
    }
  }

  async function onPlay() {
    try {
      if (useDesk.getState().playing) stopMix();
      else await playMix();
    } catch {
      toast.error(t(useSteel.getState().lang, "needSlots"));
    }
  }

  async function onMic() {
    try {
      if (d.liveMic) stopLiveMic();
      else await startLiveMic();
    } catch {
      toast.error(t(lang, "micBlocked"));
    }
  }

  async function onRec() {
    try {
      const state = await toggleVoiceRec();
      toast.success(state === "start" ? t(lang, "recStart") : t(lang, "recDone"));
    } catch {
      recRef.current?.click();
    }
  }

  async function onAi() {
    sharpMix();
    d.set({ aiBusy: true });
    try {
      const res = await suggestMix({
        data: {
          peak: d.peak,
          rms: d.rms,
          lufs: d.lufs,
          pitch: d.pitch,
          hasBeat: Boolean(d.beatName),
          hasVocal: Boolean(d.vocalName) || d.liveMic,
          lang,
        },
      });
      if (res.ok) d.set({ aiNote: res.text, aiBusy: false });
      else d.set({ aiNote: t(lang, "heuristicApplied"), aiBusy: false });
    } catch {
      d.set({ aiNote: t(lang, "heuristicApplied"), aiBusy: false });
    }
    toast.success(t(lang, "heuristicApplied"));
  }

  async function onBounce() {
    try {
      const blob = await bounceWav();
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = "steel-mix.wav";
      a.click();
      URL.revokeObjectURL(a.href);
    } catch {
      toast.error(t(lang, "needSlots"));
    }
  }

  function parsePayload(row: SteelRow): Record<string, number> {
    try {
      const raw = JSON.parse(row.payloadJson) as Record<string, unknown>;
      const out: Record<string, number> = {};
      for (const [k, v] of Object.entries(raw)) {
        if (typeof v === "number" && Number.isFinite(v)) out[k] = v;
      }
      return out;
    } catch {
      return {};
    }
  }

  async function onSaveRow() {
    const s = useDesk.getState();
    setRowBusy(true);
    try {
      const title = `mix ${s.bpm}bpm`;
      await createSteelRow({
        data: {
          kind: "mix",
          title,
          payloadJson: JSON.stringify({
            amount: s.amount,
            speed: s.speed,
            tonic: s.tonic,
            mode: s.mode,
            drive: s.drive,
            ceiling: s.ceiling,
            beatGain: s.beatGain,
            vocalGain: s.vocalGain,
            glue: s.glue,
            bpm: s.bpm,
          }),
        },
      });
      const next = await listSteelRows({ data: { kind: "mix" } });
      setRows(next);
      toast.success(t(lang, "rowSaved"));
    } catch {
      toast.error(t(lang, "rowFail"));
    } finally {
      setRowBusy(false);
    }
  }

  function loadRow(row: SteelRow) {
    const p = parsePayload(row);
    const s = useDesk.getState();
    const num = (k: string, fallback: number) => (typeof p[k] === "number" ? p[k] : fallback);
    s.set({
      amount: num("amount", s.amount),
      speed: num("speed", s.speed),
      tonic: Math.round(num("tonic", s.tonic)) % 12,
      mode: (Math.round(num("mode", s.mode)) % 3) as 0 | 1 | 2,
      drive: num("drive", s.drive),
      ceiling: num("ceiling", s.ceiling),
      beatGain: num("beatGain", s.beatGain),
      vocalGain: num("vocalGain", s.vocalGain),
      glue: num("glue", s.glue),
      bpm: Math.round(num("bpm", s.bpm)),
    });
    pushParams();
    toast.success(row.title);
  }

  const peakDb = d.peak > 0 ? (20 * Math.log10(d.peak)).toFixed(1) : "-∞";
  const loudN = Math.min(1, Math.max(0, (d.lufs + 70) / 70));
  const duckDb = d.duck < 0.999 ? (20 * Math.log10(Math.max(0.001, d.duck))).toFixed(1) : "0.0";

  return (
    <div className="grid gap-8 lg:grid-cols-[minmax(0,1.1fr)_minmax(0,0.9fr)]">
      <section className="min-w-0">
        <p className="font-mono text-2xs tracking-[0.2em] text-steel uppercase">{t(lang, "deskKicker")}</p>
        <h1 className="mt-2 text-3xl sm:text-4xl">{t(lang, "deskTitle")}</h1>
        <p className="mt-3 max-w-prose text-sm leading-relaxed text-muted">{t(lang, "deskLead")}</p>

        <div className="mt-6 grid gap-3 sm:grid-cols-2">
          <SlotCard
            lang={lang}
            title={t(lang, "slotBeat")}
            name={d.beatName}
            onPick={() => beatRef.current?.click()}
            pickLabel={t(lang, "loadBeat")}
            extra={
              <Button type="button" variant="secondary" size="sm" onClick={() => void loadDemoBeat()}>
                {t(lang, "demoBeat")}
              </Button>
            }
          />
          <SlotCard
            lang={lang}
            title={t(lang, "slotVocal")}
            name={d.vocalName}
            onPick={() => vocalRef.current?.click()}
            pickLabel={t(lang, "loadVocal")}
            extra={
              <>
                <Button type="button" variant={d.recording ? "stamp" : "secondary"} size="sm" onClick={() => void onRec()}>
                  {t(lang, "recVoice")}
                </Button>
                <Button type="button" variant={d.liveMic ? "live" : "secondary"} size="sm" onClick={() => void onMic()}>
                  {t(lang, "liveMic")}
                </Button>
              </>
            }
          />
        </div>

        <input
          ref={beatRef}
          type="file"
          accept="audio/*,.mp3,.wav,.m4a,.aac,.ogg,.flac"
          className="hidden"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) void onBeat(f);
            e.target.value = "";
          }}
        />
        <input
          ref={vocalRef}
          type="file"
          accept="audio/*,.mp3,.wav,.m4a,.aac,.ogg"
          className="hidden"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) void onVocal(f);
            e.target.value = "";
          }}
        />
        <input
          ref={recRef}
          type="file"
          accept="audio/*"
          capture="user"
          className="hidden"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) void onVocal(f);
            e.target.value = "";
          }}
        />

        <div className="mt-5 flex flex-wrap items-center gap-2">
          <Button type="button" variant={d.playing ? "stamp" : "live"} onClick={() => void onPlay()}>
            {d.playing ? t(lang, "stopMix") : t(lang, "playMix")}
          </Button>
          <Button type="button" variant="secondary" onClick={() => void onAi()} disabled={d.aiBusy}>
            {d.aiBusy ? t(lang, "aiBusy") : t(lang, "aiMix")}
          </Button>
          <Button type="button" variant="secondary" onClick={() => void onBounce()}>
            {t(lang, "bounce")}
          </Button>
          <Button type="button" variant="secondary" onClick={() => void onSaveRow()} disabled={rowBusy}>
            {t(lang, "saveRow")}
          </Button>
          <p className="font-mono text-2xs text-faint">{t(lang, "spaceHint")}</p>
        </div>
        {d.error ? <p className="mt-3 text-sm text-clip">{d.error}</p> : null}

        <div className="mt-8">
          <p className="font-mono text-2xs tracking-wider text-muted uppercase">{t(lang, "autotune")}</p>
          <div className="mt-3 grid gap-4 sm:grid-cols-2">
            <Slider label={t(lang, "amount")} value={d.amount} min={0} max={1} onChange={(v) => d.set({ amount: v })} />
            <Slider label={t(lang, "speed")} value={d.speed} min={0.05} max={1} onChange={(v) => d.set({ speed: v })} />
          </div>
          <div className="mt-4 flex flex-wrap gap-2">
            {(
              [
                [0, t(lang, "chromatic")],
                [1, t(lang, "minor")],
                [2, t(lang, "major")],
              ] as const
            ).map(([m, label]) => (
              <button
                key={m}
                type="button"
                onClick={() => d.set({ mode: m })}
                className={cn(
                  "min-h-11 rounded-[var(--radius-sm)] border px-3 text-sm",
                  d.mode === m ? "border-ink bg-ink text-paper" : "border-rule text-muted",
                )}
              >
                {label}
              </button>
            ))}
          </div>
          <div className="nav-scroll mt-3 flex flex-nowrap gap-1 overflow-x-auto">
            {NOTE_NAMES.map((n, i) => (
              <button
                key={n}
                type="button"
                onClick={() => d.set({ tonic: i })}
                className={cn(
                  "min-h-11 min-w-11 shrink-0 rounded-[var(--radius-sm)] border px-2 font-mono text-2xs",
                  d.tonic === i ? "border-ink bg-ink text-paper" : "border-rule text-muted",
                )}
              >
                {n}
              </button>
            ))}
          </div>
        </div>
      </section>

      <aside className="min-w-0 rounded-[var(--radius-lg)] border border-rule bg-raised/60 p-5">
        <p className="font-mono text-2xs tracking-wider text-muted uppercase">{t(lang, "analytics")}</p>
        <div className="mt-4 space-y-3">
          <MeterBar label={t(lang, "peak")} unit={`${peakDb} dBFS`} value={d.peak} clip={d.peak > 0.95} />
          <MeterBar label={t(lang, "loud")} unit={`${d.lufs.toFixed(1)} LUFS`} value={loudN} clip={d.lufs > -9} />
        </div>
        <div className="mt-4 grid grid-cols-2 gap-3">
          <Stat label={t(lang, "detected")} value={pitchLabel(d.pitch)} unit={`${d.pitch.toFixed(0)} Hz`} />
          <Stat label={t(lang, "bpm")} value={`${d.bpm}`} unit="BPM" />
          <Stat label={t(lang, "duck")} value={duckDb} unit="dB" />
          <Stat label={t(lang, "clips")} value={`${d.clips}`} unit="tun" />
        </div>
        <div className="mt-5 space-y-3">
          <Slider label={t(lang, "slotBeat")} value={d.beatGain} min={0} max={1.2} onChange={(v) => d.set({ beatGain: v })} />
          <Slider label={t(lang, "slotVocal")} value={d.vocalGain} min={0} max={1.2} onChange={(v) => d.set({ vocalGain: v })} />
          <Slider label={t(lang, "glue")} value={d.glue} min={0} max={1} onChange={(v) => d.set({ glue: v })} />
          <Slider label={t(lang, "drive")} value={d.drive} min={0} max={1} onChange={(v) => d.set({ drive: v })} />
          <Slider label={t(lang, "ceiling")} value={d.ceiling} min={0.5} max={0.99} onChange={(v) => d.set({ ceiling: v })} />
        </div>
        {d.aiNote ? <p className="mt-5 text-sm leading-relaxed text-muted">{d.aiNote}</p> : null}
        <div className="mt-6 border-t border-rule pt-5">
          <p className="font-mono text-2xs tracking-wider text-muted uppercase">{t(lang, "rows")}</p>
          {rows.length === 0 ? (
            <p className="mt-2 text-sm text-faint">{t(lang, "noRows")}</p>
          ) : (
            <ul className="mt-2 divide-y divide-rule">
              {rows.map((row) => (
                <li key={row.id} className="flex items-center justify-between gap-2 py-2">
                  <div className="min-w-0">
                    <p className="truncate text-sm">{row.title}</p>
                    <p className="font-mono text-2xs text-faint tabular-nums">#{row.id}</p>
                  </div>
                  <Button type="button" variant="ghost" size="sm" onClick={() => loadRow(row)}>
                    {t(lang, "loadRow")}
                  </Button>
                </li>
              ))}
            </ul>
          )}
        </div>
        <p className="mt-6 text-xs leading-relaxed text-faint">{t(lang, "tuumNote")}</p>
      </aside>
    </div>
  );
}

function MeterBar({
  label,
  unit,
  value,
  clip,
}: {
  label: string;
  unit: string;
  value: number;
  clip: boolean;
}) {
  const n = Math.min(1, Math.max(0, value));
  return (
    <div>
      <div className="flex justify-between font-mono text-2xs">
        <span className="tracking-wider text-muted uppercase">{label}</span>
        <span className={cn("tabular-nums", clip ? "text-clip" : "text-ink")}>{unit}</span>
      </div>
      <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-rule">
        <div
          className={cn(
            "h-full origin-left rounded-full transition-transform duration-[var(--motion-quick)] ease-[var(--ease-out)]",
            clip ? "bg-clip" : "bg-live",
          )}
          style={{ transform: `scaleX(${n})` }}
        />
      </div>
    </div>
  );
}

function SlotCard({
  lang,
  title,
  name,
  onPick,
  pickLabel,
  extra,
}: {
  lang: Lang;
  title: string;
  name: string | null;
  onPick: () => void;
  pickLabel: string;
  extra: ReactNode;
}) {
  return (
    <div className="rounded-[var(--radius-md)] border border-rule bg-raised/40 p-4">
      <p className="font-mono text-2xs tracking-wider text-steel uppercase">{title}</p>
      <p className="mt-2 truncate text-sm">{name ?? t(lang, "emptySlot")}</p>
      <div className="mt-3 flex flex-wrap gap-2">
        <Button type="button" variant="secondary" size="sm" onClick={onPick}>
          {pickLabel}
        </Button>
        {extra}
      </div>
    </div>
  );
}

function Stat({ label, value, unit }: { label: string; value: string; unit: string }) {
  return (
    <div className="rounded-[var(--radius-md)] border border-rule px-3 py-3">
      <p className="font-mono text-2xs tracking-wider text-muted uppercase">{label}</p>
      <p className="mt-1 font-display text-2xl tabular-nums leading-none">{value}</p>
      <p className="mt-1 font-mono text-2xs text-faint">{unit}</p>
    </div>
  );
}

function Slider({
  label,
  value,
  min,
  max,
  onChange,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  onChange: (v: number) => void;
}) {
  return (
    <label className="block">
      <span className="flex justify-between font-mono text-2xs text-muted">
        <span className="tracking-wider uppercase">{label}</span>
        <span className="tabular-nums text-ink">{value.toFixed(2)}</span>
      </span>
      <input
        type="range"
        min={min}
        max={max}
        step={(max - min) / 200}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="mt-1 w-full accent-live"
      />
    </label>
  );
}
