import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { ASIO4ALL_VERSION } from "@/lib/steel/asio";
import { useSteel } from "@/lib/steel/store";
import type { KernelManifest } from "@/lib/steel/types";
import { applyKernel, checkChannel, versionGte } from "@/lib/steel/updates";

export function SteelKernel() {
  const kernel = useSteel((s) => s.kernel);
  const latest = useSteel((s) => s.latest);
  const updating = useSteel((s) => s.updating);
  const addons = useSteel((s) => s.addons);
  const [man, setMan] = useState<KernelManifest | null>(null);

  useEffect(() => {
    void checkChannel()
      .then(setMan)
      .catch((err: unknown) => toast.error(err instanceof Error ? err.message : "Channel down"));
  }, []);

  const behind = latest != null && !versionGte(kernel, latest);

  async function apply() {
    if (!latest) return;
    await applyKernel(latest);
    toast.success(`Kernel ${latest} on this host`);
    const next = await checkChannel();
    setMan(next);
  }

  return (
    <div className="grid gap-10 lg:grid-cols-2">
      <section>
        <p className="font-mono text-2xs tracking-[0.2em] text-steel uppercase">Update channel</p>
        <h2 className="mt-2 text-3xl">Kernel {kernel}</h2>
        <p className="mt-3 text-sm text-muted">
          Channel <span className="text-ink">{man?.channel ?? "stable"}</span>. ASIO4ALL target{" "}
          {man?.asio4all ?? ASIO4ALL_VERSION}. The worklet reloads when you apply a version — same
          contract a host would use for add-on reform.
        </p>
        <dl className="mt-6 grid grid-cols-2 gap-3">
          <div className="rounded-[var(--radius-md)] border border-rule px-3 py-3">
            <dt className="font-mono text-2xs tracking-wider text-muted uppercase">Running</dt>
            <dd className="mt-1 font-display text-2xl">{kernel}</dd>
          </div>
          <div className="rounded-[var(--radius-md)] border border-rule px-3 py-3">
            <dt className="font-mono text-2xs tracking-wider text-muted uppercase">Channel latest</dt>
            <dd className="mt-1 font-display text-2xl">{latest ?? "—"}</dd>
          </div>
        </dl>
        {man?.hosts ? (
          <p className="mt-4 font-mono text-2xs text-muted">
            FL {man.hosts.fl} · Live {man.hosts.ableton} · Win {man.hosts.windows} · Linux {man.hosts.linux}
          </p>
        ) : null}
        <div className="mt-5 flex flex-wrap gap-2">
          <Button type="button" variant="secondary" onClick={() => void checkChannel().then(setMan)}>
            Check channel
          </Button>
          <Button type="button" variant="live" disabled={!behind || updating} onClick={() => void apply()}>
            {updating ? "Reforming…" : behind ? `Apply ${latest}` : "Up to date"}
          </Button>
        </div>
        {man ? <p className="mt-4 text-sm text-muted">{man.notes}</p> : null}
      </section>
      <section>
        <p className="font-mono text-2xs tracking-wider text-muted uppercase">Add-ons</p>
        <ul className="mt-3 divide-y divide-rule border-y border-rule">
          {(man?.addons ?? []).map((addon) => {
            const allowed = versionGte(kernel, addon.minKernel);
            const on = Boolean(addons[addon.id]);
            return (
              <li key={addon.id} className="flex items-baseline justify-between gap-3 py-3">
                <div>
                  <p className="font-medium">{addon.name}</p>
                  <p className="font-mono text-2xs text-muted">
                    {addon.version} · min kernel {addon.minKernel}
                  </p>
                </div>
                <p className="font-mono text-2xs tracking-wider uppercase text-muted">
                  {!allowed ? "locked" : on ? "live" : "off"}
                </p>
              </li>
            );
          })}
        </ul>
      </section>
    </div>
  );
}
