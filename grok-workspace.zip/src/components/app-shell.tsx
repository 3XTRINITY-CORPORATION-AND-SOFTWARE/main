import { useEffect, type ReactNode } from "react";
import { Toaster } from "sonner";
import { teardownAura } from "@/lib/aura/engine";
import { teardownDesk } from "@/lib/desk/engine";
import { t, type I18nKey } from "@/lib/i18n";
import { disarmKernel } from "@/lib/steel/engine";
import { isolateForTab } from "@/lib/steel/isolate";
import { bindComputerKeys, unbindComputerKeys } from "@/lib/steel/midi";
import { hydrateSteel, useSteel, watchSteelPersist } from "@/lib/steel/store";
import type { SteelTab } from "@/lib/steel/types";
import { checkChannel, versionGte } from "@/lib/steel/updates";
import { cn } from "@/lib/utils";

const TABS: { id: SteelTab; key: I18nKey }[] = [
  { id: "desk", key: "desk" },
  { id: "console", key: "console" },
  { id: "aura", key: "aura" },
  { id: "pipeline", key: "pipeline" },
  { id: "hosts", key: "hosts" },
  { id: "kernel", key: "kernel" },
  { id: "audit", key: "audit" },
];

export function AppShell({ children }: { children: ReactNode }) {
  const tab = useSteel((s) => s.tab);
  const setTab = useSteel((s) => s.setTab);
  const lang = useSteel((s) => s.lang);
  const patch = useSteel((s) => s.patch);
  const armed = useSteel((s) => s.armed);
  const kernel = useSteel((s) => s.kernel);
  const latest = useSteel((s) => s.latest);
  const behind = latest != null && !versionGte(kernel, latest);

  useEffect(() => {
    hydrateSteel();
    const stopPersist = watchSteelPersist();
    void checkChannel().catch(() => undefined);
    bindComputerKeys();
    return () => {
      stopPersist();
      unbindComputerKeys();
      void disarmKernel();
      void teardownDesk();
      void teardownAura();
    };
  }, []);

  useEffect(() => {
    document.documentElement.lang = lang;
  }, [lang]);

  function go(next: SteelTab) {
    isolateForTab(next);
    setTab(next);
  }

  return (
    <div className="min-h-dvh bg-paper text-ink">
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 focus:bg-ink focus:px-3 focus:py-2 focus:text-paper"
      >
        {t(lang, "skip")}
      </a>
      <header className="sticky top-0 z-20 border-b border-rule bg-paper/95 backdrop-blur-sm">
        <div className="shell-header shell-pad mx-auto max-w-6xl">
          <div className="flex items-center justify-between gap-3 py-3">
            <div className="flex min-w-0 items-center gap-3">
              <span
                className={cn("size-2 shrink-0 rounded-full", armed ? "bg-live" : "bg-rule")}
                aria-hidden
              />
              <p className="font-display text-xl tracking-[0.14em]">STEEL</p>
              <p className="hidden font-mono text-2xs tracking-wider text-muted uppercase sm:block">
                kernel {kernel}
              </p>
              {behind ? (
                <button
                  type="button"
                  onClick={() => go("kernel")}
                  className="hidden rounded-[var(--radius-sm)] border border-live/40 px-2 py-1 font-mono text-2xs tracking-wider text-live uppercase sm:inline"
                >
                  {latest} {t(lang, "ready")}
                </button>
              ) : null}
            </div>
            <button
              type="button"
              onClick={() => patch({ lang: lang === "et" ? "en" : "et" })}
              className="min-h-11 min-w-11 shrink-0 rounded-[var(--radius-sm)] border border-rule px-2 font-mono text-2xs tracking-wider text-muted uppercase"
              aria-label="Language"
            >
              {lang === "et" ? "ET" : "EN"}
            </button>
          </div>
          <nav aria-label="Primary" className="nav-scroll -mx-1 flex flex-nowrap gap-1 overflow-x-auto pb-3">
            {TABS.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => go(item.id)}
                aria-current={tab === item.id ? "page" : undefined}
                className={cn(
                  "min-h-11 shrink-0 rounded-[var(--radius-sm)] px-3 py-2 text-sm transition-colors duration-[var(--motion-quick)]",
                  tab === item.id ? "bg-ink text-paper" : "text-muted hover:bg-ink/[0.06] hover:text-ink",
                )}
              >
                {t(lang, item.key)}
              </button>
            ))}
          </nav>
        </div>
      </header>
      <main
        id="main"
        className={
          tab === "aura"
            ? "shell-pad mx-auto max-w-6xl py-4"
            : "shell-pad mx-auto max-w-6xl py-6 sm:py-8"
        }
      >
        {children}
      </main>
      <footer className="shell-footer shell-pad mx-auto max-w-6xl border-t border-rule py-5 font-mono text-2xs tracking-wide text-muted uppercase">
        <span className="block max-w-full text-pretty">{t(lang, "footer")}</span>
      </footer>
      <Toaster
        position="bottom-center"
        toastOptions={{
          className: "!bg-raised !text-ink !border-rule !font-[inherit] !rounded-[6px]",
        }}
      />
    </div>
  );
}
