import { createFileRoute } from "@tanstack/react-router";
import { SteelAudit } from "@/components/steel-audit";
import { StudioBanks } from "@/components/studio/banks";
import { StudioCrew } from "@/components/studio/crew";
import { StudioDesk } from "@/components/studio/desk";
import { StudioFilm } from "@/components/studio/film";
import { StudioKernelBay } from "@/components/studio/kernel-bay";
import { StudioMatrix } from "@/components/studio/matrix";
import { StudioMonitor } from "@/components/studio/monitor";
import { StudioShell } from "@/components/studio/shell";
import { StudioTheory } from "@/components/studio/theory-box";
import { StudioVisuals } from "@/components/studio/visuals";
import { StudioVocals } from "@/components/studio/vocals";
import { useStudio } from "@/lib/studio/store";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const tab = useStudio((s) => s.tab);
  return (
    <StudioShell>
      {tab === "desk" ? <StudioDesk /> : null}
      {tab === "vocals" ? <StudioVocals /> : null}
      {tab === "visuals" ? <StudioVisuals /> : null}
      {tab === "matrix" ? <StudioMatrix /> : null}
      {tab === "monitor" ? <StudioMonitor /> : null}
      {tab === "kernel" ? <StudioKernelBay /> : null}
      {tab === "crew" ? <StudioCrew /> : null}
      {tab === "audit" ? <SteelAudit /> : null}
      {tab === "banks" ? <StudioBanks /> : null}
      {tab === "film" ? <StudioFilm /> : null}
      {tab === "theory" ? <StudioTheory /> : null}
    </StudioShell>
  );
}
