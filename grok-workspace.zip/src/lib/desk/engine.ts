import { makeBoomBap, bufferToWav } from "./boom";
import { useDesk } from "./store";

type Slot = {
  buffer: AudioBuffer | null;
  source: AudioBufferSourceNode | null;
  gain: GainNode;
};

type Handle = {
  ctx: AudioContext;
  beat: Slot;
  vocal: Slot;
  tune: AudioWorkletNode;
  vocalIn: GainNode;
  mix: GainNode;
  duck: GainNode;
  glue: DynamicsCompressorNode;
  dest: MediaStreamAudioDestinationNode;
  analyser: AnalyserNode;
  vocalAn: AnalyserNode;
  mixBuf: Uint8Array;
  vocalBuf: Uint8Array;
  mic: MediaStreamAudioSourceNode | null;
  micStream: MediaStream | null;
};

let handle: Handle | null = null;
let rec: MediaRecorder | null = null;
let recChunks: Blob[] = [];
let meterRaf = 0;

function estimateBpm(buffer: AudioBuffer): number {
  const ch = buffer.getChannelData(0);
  const sr = buffer.sampleRate;
  const hop = Math.max(1, Math.floor(sr / 50));
  const n = Math.min(ch.length, Math.floor(sr * 20));
  const energies: number[] = [];
  for (let i = 0; i + hop < n; i += hop) {
    let e = 0;
    for (let j = 0; j < hop; j += 8) e += ch[i + j] * ch[i + j];
    energies.push(e);
  }
  if (energies.length < 24) return 90;
  const flux = new Float32Array(energies.length - 1);
  for (let i = 1; i < energies.length; i++) flux[i - 1] = Math.max(0, energies[i] - energies[i - 1]);
  const minLag = Math.round((60 / 180) * 50);
  const maxLag = Math.min(flux.length - 2, Math.round((60 / 70) * 50));
  let best = 0;
  let bestLag = minLag;
  for (let lag = minLag; lag <= maxLag; lag++) {
    let s = 0;
    const m = flux.length - lag;
    for (let i = 0; i < m; i++) s += flux[i] * flux[i + lag];
    s /= Math.max(1, m);
    if (s > best) {
      best = s;
      bestLag = lag;
    }
  }
  let bpm = 60 / (bestLag / 50);
  if (bpm < 70) bpm *= 2;
  if (bpm > 180) bpm /= 2;
  return Math.round(Math.min(180, Math.max(70, bpm)));
}

function applyGlue(h: Handle, glue: number) {
  const t = h.ctx.currentTime;
  const g = Math.min(1, Math.max(0, glue));
  h.glue.threshold.setTargetAtTime(-8 - g * 16, t, 0.05);
  h.glue.knee.setTargetAtTime(4 + g * 8, t, 0.05);
  h.glue.ratio.setTargetAtTime(1.4 + g * 4.6, t, 0.05);
  h.glue.attack.setTargetAtTime(0.006, t, 0.02);
  h.glue.release.setTargetAtTime(0.12 + g * 0.16, t, 0.05);
}

function wireGlue(ctx: BaseAudioContext, glueAmt: number) {
  const glue = ctx.createDynamicsCompressor();
  const g = Math.min(1, Math.max(0, glueAmt));
  glue.threshold.value = -8 - g * 16;
  glue.knee.value = 4 + g * 8;
  glue.ratio.value = 1.4 + g * 4.6;
  glue.attack.value = 0.006;
  glue.release.value = 0.12 + g * 0.16;
  return glue;
}

function pumpMixMeter() {
  if (!handle) return;
  const a = handle.analyser;
  const buf = handle.mixBuf;
  a.getByteTimeDomainData(buf as Uint8Array<ArrayBuffer>);
  let peak = 0;
  let rms = 0;
  for (let i = 0; i < buf.length; i++) {
    const x = (buf[i] - 128) / 128;
    const ax = Math.abs(x);
    if (ax > peak) peak = ax;
    rms += x * x;
  }
  rms = Math.sqrt(rms / buf.length);

  const vbuf = handle.vocalBuf;
  handle.vocalAn.getByteTimeDomainData(vbuf as Uint8Array<ArrayBuffer>);
  let vp = 0;
  for (let i = 0; i < vbuf.length; i++) {
    const ax = Math.abs((vbuf[i] - 128) / 128);
    if (ax > vp) vp = ax;
  }
  const duck = vp > 0.1 ? 1 - Math.min(0.38, (vp - 0.1) * 0.9) : 1;
  handle.duck.gain.setTargetAtTime(duck, handle.ctx.currentTime, 0.04);

  const prev = useDesk.getState();
  const smoothRms = rms * 0.2 + prev.rms * 0.8;
  const lufs = smoothRms > 1e-8 ? 20 * Math.log10(smoothRms) - 0.691 : Math.max(-70, prev.lufs - 1.5);
  useDesk.getState().set({
    peak: Math.max(peak, prev.peak * 0.92),
    rms: smoothRms,
    lufs,
    duck,
  });
  meterRaf = requestAnimationFrame(pumpMixMeter);
}

async function ensure(): Promise<Handle> {
  if (handle && handle.ctx.state !== "closed") {
    if (handle.ctx.state === "suspended") await handle.ctx.resume();
    return handle;
  }
  const ctx = new AudioContext({ latencyHint: "interactive", sampleRate: 44100 });
  await ctx.audioWorklet.addModule("/worklets/steel-tune.js");
  const beatGain = ctx.createGain();
  const vocalIn = ctx.createGain();
  const vocalGain = ctx.createGain();
  const duck = ctx.createGain();
  duck.gain.value = 1;
  const tune = new AudioWorkletNode(ctx, "steel-tune", {
    numberOfInputs: 1,
    numberOfOutputs: 1,
    outputChannelCount: [2],
  });
  const mix = ctx.createGain();
  mix.gain.value = 0.95;
  const glue = wireGlue(ctx, useDesk.getState().glue);
  const dest = ctx.createMediaStreamDestination();
  const analyser = ctx.createAnalyser();
  analyser.fftSize = 2048;
  const vocalAn = ctx.createAnalyser();
  vocalAn.fftSize = 1024;
  vocalIn.connect(tune);
  tune.connect(vocalGain);
  vocalGain.connect(mix);
  vocalGain.connect(vocalAn);
  beatGain.connect(duck);
  duck.connect(mix);
  mix.connect(glue);
  glue.connect(analyser);
  analyser.connect(ctx.destination);
  glue.connect(dest);
  tune.port.onmessage = (ev: MessageEvent) => {
    const d = ev.data as { type?: string; pitch?: number; clips?: number };
    if (d?.type !== "meter") return;
    useDesk.getState().set({
      pitch: d.pitch ?? 0,
      clips: d.clips ?? 0,
    });
  };
  handle = {
    ctx,
    beat: { buffer: null, source: null, gain: beatGain },
    vocal: { buffer: null, source: null, gain: vocalGain },
    tune,
    vocalIn,
    mix,
    duck,
    glue,
    dest,
    analyser,
    vocalAn,
    mixBuf: new Uint8Array(analyser.fftSize),
    vocalBuf: new Uint8Array(vocalAn.fftSize),
    mic: null,
    micStream: null,
  };
  pushParams();
  await ctx.resume();
  return handle;
}

export function pushParams() {
  const s = useDesk.getState();
  handle?.tune.port.postMessage({
    type: "params",
    params: {
      amount: s.amount,
      speed: s.speed,
      tonic: s.tonic,
      mode: s.mode,
      drive: s.drive,
      ceiling: s.ceiling,
      hpf: 80,
    },
  });
  if (handle) {
    handle.beat.gain.gain.setTargetAtTime(s.beatGain, handle.ctx.currentTime, 0.02);
    handle.vocal.gain.gain.setTargetAtTime(s.vocalGain, handle.ctx.currentTime, 0.02);
    applyGlue(handle, s.glue);
  }
}

export async function decodeSlot(file: File): Promise<AudioBuffer> {
  const h = await ensure();
  const arr = await file.arrayBuffer();
  try {
    return await h.ctx.decodeAudioData(arr.slice(0));
  } catch {
    throw new Error("decode");
  }
}

export async function setBeatBuffer(buffer: AudioBuffer, name: string) {
  const h = await ensure();
  h.beat.buffer = buffer;
  useDesk.getState().set({ beatName: name, error: null, bpm: estimateBpm(buffer) });
}

export async function setVocalBuffer(buffer: AudioBuffer, name: string) {
  const h = await ensure();
  h.vocal.buffer = buffer;
  useDesk.getState().set({ vocalName: name, error: null, liveMic: false });
}

export async function loadDemoBeat() {
  const h = await ensure();
  const buf = makeBoomBap(h.ctx, 8);
  h.beat.buffer = buf;
  useDesk.getState().set({ beatName: "demo-90bpm.wav", error: null, bpm: 90 });
}

function startLoop(slot: Slot, dest: AudioNode, ctx: AudioContext) {
  if (!slot.buffer) return;
  try {
    slot.source?.stop();
  } catch {
    /* */
  }
  const src = ctx.createBufferSource();
  src.buffer = slot.buffer;
  src.loop = true;
  src.connect(dest);
  src.start();
  slot.source = src;
}

export async function playMix() {
  const h = await ensure();
  const s = useDesk.getState();
  if (!h.beat.buffer && !h.vocal.buffer && !s.liveMic) {
    throw new Error("empty");
  }
  pushParams();
  if (h.beat.buffer) startLoop(h.beat, h.beat.gain, h.ctx);
  if (h.vocal.buffer && !s.liveMic) startLoop(h.vocal, h.vocalIn, h.ctx);
  if (!meterRaf) pumpMixMeter();
  useDesk.getState().set({ playing: true, error: null });
}

export function stopMix() {
  if (meterRaf) {
    cancelAnimationFrame(meterRaf);
    meterRaf = 0;
  }
  if (!handle) {
    useDesk.getState().set({ playing: false, duck: 1 });
    return;
  }
  try {
    handle.beat.source?.stop();
    handle.vocal.source?.stop();
  } catch {
    /* */
  }
  handle.beat.source = null;
  handle.vocal.source = null;
  handle.duck.gain.setTargetAtTime(1, handle.ctx.currentTime, 0.02);
  useDesk.getState().set({ playing: false, duck: 1 });
}

export async function startLiveMic() {
  const h = await ensure();
  try {
    const stream = await navigator.mediaDevices.getUserMedia({
      audio: { echoCancellation: false, noiseSuppression: false, autoGainControl: false },
    });
    h.micStream = stream;
    h.mic = h.ctx.createMediaStreamSource(stream);
    h.mic.connect(h.vocalIn);
    useDesk.getState().set({ liveMic: true, vocalName: "mic", error: null, playing: true });
    pushParams();
    if (h.beat.buffer && !h.beat.source) startLoop(h.beat, h.beat.gain, h.ctx);
    if (!meterRaf) pumpMixMeter();
  } catch {
    throw new Error("mic");
  }
}

export function stopLiveMic() {
  if (!handle) return;
  handle.mic?.disconnect();
  handle.micStream?.getTracks().forEach((t) => t.stop());
  handle.mic = null;
  handle.micStream = null;
  useDesk.getState().set({ liveMic: false });
}

export async function toggleVoiceRec(): Promise<"start" | "stop"> {
  if (rec && rec.state === "recording") {
    const blob = await new Promise<Blob>((resolve) => {
      rec!.onstop = () => resolve(new Blob(recChunks, { type: rec!.mimeType || "audio/webm" }));
      rec!.stop();
    });
    rec = null;
    useDesk.getState().set({ recording: false });
    const file = new File([blob], "voice.webm", { type: blob.type });
    const buf = await decodeSlot(file);
    await setVocalBuffer(buf, "voice.webm");
    return "stop";
  }
  const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
  recChunks = [];
  const mime = MediaRecorder.isTypeSupported("audio/webm") ? "audio/webm" : "audio/mp4";
  rec = new MediaRecorder(stream, { mimeType: mime, audioBitsPerSecond: 192000 });
  rec.ondataavailable = (e) => {
    if (e.data.size) recChunks.push(e.data);
  };
  rec.start(200);
  useDesk.getState().set({ recording: true, error: null });
  return "start";
}

export async function bounceWav(): Promise<Blob> {
  const h = await ensure();
  const beat = h.beat.buffer;
  const vocal = h.vocal.buffer;
  if (!beat && !vocal) throw new Error("empty");
  const sr = 44100;
  const len = Math.max(beat?.length ?? 0, vocal?.length ?? 0);
  const off = new OfflineAudioContext(2, len, sr);
  await off.audioWorklet.addModule("/worklets/steel-tune.js");
  const s = useDesk.getState();
  const mix = off.createGain();
  mix.gain.value = 0.95;
  const glue = wireGlue(off, s.glue);
  mix.connect(glue);
  glue.connect(off.destination);
  if (beat) {
    const src = off.createBufferSource();
    src.buffer = beat;
    const g = off.createGain();
    g.gain.value = s.beatGain;
    src.connect(g);
    g.connect(mix);
    src.start();
  }
  if (vocal) {
    const src = off.createBufferSource();
    src.buffer = vocal;
    const g = off.createGain();
    g.gain.value = s.vocalGain;
    const tune = new AudioWorkletNode(off, "steel-tune", {
      numberOfInputs: 1,
      numberOfOutputs: 1,
      outputChannelCount: [2],
    });
    tune.port.postMessage({
      type: "params",
      params: {
        amount: s.amount,
        speed: s.speed,
        tonic: s.tonic,
        mode: s.mode,
        drive: s.drive,
        ceiling: s.ceiling,
        hpf: 80,
      },
    });
    src.connect(tune);
    tune.connect(g);
    g.connect(mix);
    src.start();
  }
  const rendered = await off.startRendering();
  return bufferToWav(rendered);
}

export function sharpMix() {
  const s = useDesk.getState();
  const vocalQuiet = s.rms > 0 && s.peak > 0 && s.rms < 0.08;
  s.set({
    amount: 0.78,
    speed: 0.55,
    mode: 1,
    drive: 0.22,
    ceiling: 0.86,
    glue: 0.62,
    vocalGain: vocalQuiet ? 1.05 : 0.92,
    beatGain: 0.72,
  });
  pushParams();
}

export async function teardownDesk() {
  stopMix();
  stopLiveMic();
  if (rec) {
    try {
      rec.stop();
    } catch {
      /* */
    }
    rec = null;
  }
  if (handle) {
    try {
      await handle.ctx.close();
    } catch {
      /* */
    }
  }
  handle = null;
}

export function pitchLabel(hz: number) {
  if (hz < 70) return "—";
  const midi = 69 + 12 * Math.log2(hz / 440);
  const q = Math.round(midi);
  const names = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"];
  return `${names[(q + 1200) % 12]}${Math.floor(q / 12) - 1}`;
}
