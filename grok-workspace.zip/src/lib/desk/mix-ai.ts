import { createServerFn } from "@tanstack/react-start";

export type MixSnapshot = {
  peak: number;
  rms: number;
  lufs: number;
  pitch: number;
  hasBeat: boolean;
  hasVocal: boolean;
  lang: "et" | "en";
};

export const suggestMix = createServerFn({ method: "POST" })
  .validator((input: MixSnapshot) => input)
  .handler(async ({ data }) => {
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) return { ok: false as const, error: "offline" };
    const lang = data.lang === "et" ? "Estonian" : "English";
    const prompt = `You are a mixing engineer. Snapshot: peak=${data.peak.toFixed(3)} rms=${data.rms.toFixed(3)} lufs=${data.lufs.toFixed(1)} pitchHz=${data.pitch.toFixed(1)} beat=${data.hasBeat} vocal=${data.hasVocal}. Reply in ${lang}, max 80 words: 1) autotune amount 0-1, 2) vocal vs beat balance, 3) master ceiling. No marketing. No emoji.`;
    const res = await fetch("https://api.x.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "grok-4.5",
        max_tokens: 220,
        messages: [{ role: "user", content: prompt }],
      }),
    });
    if (!res.ok) return { ok: false as const, error: `xAI ${res.status}` };
    const body = (await res.json()) as { choices?: { message?: { content?: string } }[] };
    const text = body.choices?.[0]?.message?.content ?? "";
    return { ok: true as const, text };
  });
