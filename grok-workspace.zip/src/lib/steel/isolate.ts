import { stopSource } from "@/lib/aura/engine";
import { stopLiveMic, stopMix } from "@/lib/desk/engine";
import { disarmKernel, panic } from "@/lib/steel/engine";
import { useSteel } from "@/lib/steel/store";
import type { SteelTab } from "@/lib/steel/types";

/** Stop engines that would overlap when the user leaves a tab. */
export function isolateForTab(next: SteelTab) {
  const cur = useSteel.getState().tab;
  if (cur === next) return;
  stopMix();
  stopLiveMic();
  void stopSource();
  if (next === "desk") {
    panic();
    void disarmKernel();
  } else if (cur === "console" && next !== "kernel" && next !== "pipeline") {
    panic();
  }
}
