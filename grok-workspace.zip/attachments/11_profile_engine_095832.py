# 11_profile_engine.py
from dataclasses import dataclass
from typing import List, Set

from 05_rules_engine import Operation


@dataclass
class ProfileConfig:
    name: str
    allowed_kinds: Set[str]


PROFILE_DEFINITIONS = {
    "dev": ProfileConfig(
        name="dev",
        allowed_kinds={
            "CREATE_DIR",
            "MOVE",
            "DELETE",
            "PY_INSTALL",
            "NODE_INSTALL",
            "GIT_INIT",
            "GIT_COMMIT_INITIAL",
        },
    ),
    "ci": ProfileConfig(
        name="ci",
        allowed_kinds={
            "CREATE_DIR",
            "MOVE",
            "DELETE",
            "PY_INSTALL",
            "NODE_INSTALL",
        },
    ),
    "release": ProfileConfig(
        name="release",
        allowed_kinds={
            "CREATE_DIR",
            "MOVE",
            "DELETE",
        },
    ),
    "archive": ProfileConfig(
        name="archive",
        allowed_kinds={
            "CREATE_DIR",
            "MOVE",
            "DELETE",
        },
    ),
}


class ProfileEngine:
    def __init__(self, profile_name: str = "dev"):
        if profile_name not in PROFILE_DEFINITIONS:
            raise ValueError(f"Unknown profile: {profile_name}")
        self.config = PROFILE_DEFINITIONS[profile_name]

    def filter_operations(self, ops: List[Operation]) -> List[Operation]:
        allowed = []
        for op in ops:
            if op.kind in self.config.allowed_kinds:
                allowed.append(op)
            else:
                print(f"[PROFILE {self.config.name}] Skipping op {op.kind} {op.args}")
        return allowed