//#region node_modules/.nitro/vite/services/ssr/assets/night-Ii85_HfI.js
/** Ten vocal kinds, scream → opera. DSP / TTS stand-in — not a voice-print. */
var VOCAL_KINDS = [
	"scream",
	"growl",
	"belt",
	"rap",
	"chop",
	"speak",
	"whisper",
	"air",
	"choir",
	"opera"
];
var VOCAL_LANGS = [
	"en",
	"ru",
	"es",
	"et",
	"de"
];
var KIND_VOICE = {
	scream: "perseus",
	growl: "atlas",
	belt: "rex",
	rap: "zagan",
	chop: "lux",
	speak: "helix",
	whisper: "luna",
	air: "aurora",
	choir: "orion",
	opera: "helios"
};
var KIND_LABEL = {
	scream: "SCREAM",
	growl: "GROWL",
	belt: "BELT",
	rap: "RAP",
	chop: "CHOP",
	speak: "SPEAK",
	whisper: "WHISP",
	air: "AIR",
	choir: "CHOIR",
	opera: "OPERA"
};
var KIND_DSP = {
	scream: {
		hp: 140,
		presenceHz: 4200,
		presenceDb: 6,
		airDb: 2,
		sat: .72,
		gain: 1.15,
		scoopHz: 280,
		scoopDb: -2,
		grains: false,
		stack: true
	},
	growl: {
		hp: 70,
		presenceHz: 1800,
		presenceDb: 2,
		airDb: -1,
		sat: .64,
		gain: 1.05,
		scoopHz: 420,
		scoopDb: 1.5,
		grains: false,
		stack: true
	},
	belt: {
		hp: 90,
		presenceHz: 2800,
		presenceDb: 5,
		airDb: 1.5,
		sat: .28,
		gain: 1.12,
		scoopHz: 320,
		scoopDb: -1.5,
		grains: false,
		stack: true
	},
	rap: {
		hp: 80,
		presenceHz: 2200,
		presenceDb: 3,
		airDb: .5,
		sat: .22,
		gain: 1,
		scoopHz: 300,
		scoopDb: -2,
		grains: false,
		stack: false
	},
	chop: {
		hp: 100,
		presenceHz: 2600,
		presenceDb: 2,
		airDb: 1,
		sat: .18,
		gain: .95,
		scoopHz: 350,
		scoopDb: -1,
		grains: true,
		stack: false
	},
	speak: {
		hp: 90,
		presenceHz: 1600,
		presenceDb: 1,
		airDb: 0,
		sat: .08,
		gain: .92,
		scoopHz: 280,
		scoopDb: -1,
		grains: false,
		stack: false
	},
	whisper: {
		hp: 380,
		presenceHz: 3600,
		presenceDb: 1.5,
		airDb: 5,
		sat: .04,
		gain: .42,
		scoopHz: 240,
		scoopDb: -3,
		grains: false,
		stack: false
	},
	air: {
		hp: 180,
		presenceHz: 4800,
		presenceDb: 3,
		airDb: 6,
		sat: .1,
		gain: .7,
		scoopHz: 300,
		scoopDb: -2.5,
		grains: false,
		stack: false
	},
	choir: {
		hp: 110,
		presenceHz: 2400,
		presenceDb: 2,
		airDb: 3,
		sat: .12,
		gain: .78,
		scoopHz: 280,
		scoopDb: -1.5,
		grains: false,
		stack: true
	},
	opera: {
		hp: 85,
		presenceHz: 3100,
		presenceDb: 4.5,
		airDb: 3.5,
		sat: .16,
		gain: 1.08,
		scoopHz: 260,
		scoopDb: -1,
		grains: false,
		stack: true
	}
};
var NIGHT_HEAR_FIRST = [
	"TAKT-LOCK",
	"ENERGY-MATCH",
	"STEREO-MX"
];
var NIGHT_STANDIN_URL = "/night_backvox_standin.mp3";
var HOOK_PLACEHOLDER = {
	et: "Kirjuta suund või jäta tühjaks…",
	en: "Write a direction, or leave blank…",
	ru: "Направление или пусто…",
	es: "Dirección, o déjalo vacío…",
	de: "Richtung, oder leer lassen…"
};
function isVocalLang(v) {
	return v === "en" || v === "ru" || v === "es" || v === "et" || v === "de";
}
function isVocalKind(v) {
	return typeof v === "string" && VOCAL_KINDS.includes(v);
}
//#endregion
export { NIGHT_HEAR_FIRST as a, VOCAL_LANGS as c, KIND_VOICE as i, isVocalKind as l, KIND_DSP as n, NIGHT_STANDIN_URL as o, KIND_LABEL as r, VOCAL_KINDS as s, HOOK_PLACEHOLDER as t, isVocalLang as u };
