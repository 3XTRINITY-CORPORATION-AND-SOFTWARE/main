import { t as createServerFn } from "./ssr.mjs";
import { t as createServerRpc } from "./createServerRpc-A6pJPYTF.mjs";
import { i as KIND_VOICE } from "./night-Ii85_HfI.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ai-BxIF0glD.js
var writeHook_createServerFn_handler = createServerRpc({
	id: "5e9d181f18f88538dd562a585a605b3513846dbf7cfed09452e8f0a567d0da5d",
	name: "writeHook",
	filename: "src/lib/studio/ai.ts"
}, (opts) => writeHook.__executeServer(opts));
var writeHook = createServerFn({ method: "POST" }).validator((input) => input).handler(writeHook_createServerFn_handler, async ({ data }) => {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		error: "offline"
	};
	const langName = data.lang === "et" ? "Estonian" : data.lang === "ru" ? "Russian" : data.lang === "es" ? "Spanish" : data.lang === "de" ? "German" : "English";
	const res = await fetch("https://api.x.ai/v1/chat/completions", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${apiKey}`
		},
		signal: AbortSignal.timeout(12e3),
		body: JSON.stringify({
			model: "grok-4.5",
			max_tokens: 220,
			messages: [{
				role: "system",
				content: "You write short vocal hooks for electronic music and rap. Stay in the requested language. If a seed is given, keep that diction — do not rewrite locked lines into another speaker. Night lane: quiet lead, louder stack. No emoji. No quotes around the whole answer. No celebrity names. Return lyrics only."
			}, {
				role: "user",
				content: `Language: ${langName}. Genre: ${data.genre}. Direction: ${data.seed.slice(0, 280) || "dark steel club, precise cadence"}. Write a 4-line hook with natural phonetic flow for singing/rapping. Keep it under 80 words. If the seed already holds bars, continue in that speaker.`
			}]
		})
	});
	if (!res.ok) return {
		ok: false,
		error: `xAI ${res.status}`
	};
	return {
		ok: true,
		text: (await res.json()).choices?.[0]?.message?.content?.trim() ?? ""
	};
});
var speakHook_createServerFn_handler = createServerRpc({
	id: "9a1b68d71c937e4539d4123efdcdf02834147108e7690e8669ef06f68247f3dc",
	name: "speakHook",
	filename: "src/lib/studio/ai.ts"
}, (opts) => speakHook.__executeServer(opts));
var speakHook = createServerFn({ method: "POST" }).validator((input) => input).handler(speakHook_createServerFn_handler, async ({ data }) => {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		error: "offline"
	};
	const text = data.text.slice(0, 180);
	if (!text) return {
		ok: false,
		error: "empty"
	};
	const voice = data.kind && KIND_VOICE[data.kind] || (data.bank === "harmony" ? "eve" : data.bank === "adlib" ? "helix" : data.bank === "choir" ? "orion" : "zagan");
	const langHint = data.lang === "et" ? "et" : data.lang === "ru" ? "ru" : data.lang === "es" ? "es" : data.lang === "de" ? "de" : "en";
	const res = await fetch("https://api.x.ai/v1/tts", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${apiKey}`
		},
		signal: AbortSignal.timeout(15e3),
		body: JSON.stringify({
			text,
			voice_id: voice,
			language: langHint
		})
	});
	if (!res.ok) {
		const alt = await fetch("https://api.x.ai/v1/audio/speech", {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${apiKey}`
			},
			signal: AbortSignal.timeout(15e3),
			body: JSON.stringify({
				model: "grok-voice-latest",
				voice,
				input: text,
				language: langHint
			})
		});
		if (!alt.ok) return {
			ok: false,
			error: `xAI ${alt.status}`
		};
		return {
			ok: true,
			audio: bufferToB64(await alt.arrayBuffer()),
			mime: alt.headers.get("content-type") || "audio/mpeg"
		};
	}
	return {
		ok: true,
		audio: bufferToB64(await res.arrayBuffer()),
		mime: res.headers.get("content-type") || "audio/mpeg"
	};
});
var detectLyrics_createServerFn_handler = createServerRpc({
	id: "a35ba60b943647906b56c0515dd54ba5479da050701d6249467c7c310e72e572",
	name: "detectLyrics",
	filename: "src/lib/studio/ai.ts"
}, (opts) => detectLyrics.__executeServer(opts));
var detectLyrics = createServerFn({ method: "POST" }).validator((input) => input).handler(detectLyrics_createServerFn_handler, async ({ data }) => {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		error: "offline"
	};
	const lang = data.lang === "et" ? "Estonian" : "English";
	const res = await fetch("https://api.x.ai/v1/chat/completions", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${apiKey}`
		},
		signal: AbortSignal.timeout(12e3),
		body: JSON.stringify({
			model: "grok-4.5",
			max_tokens: 180,
			messages: [{
				role: "user",
				content: `Infer a short ${lang} lyric caption (max 40 words) for a ${data.genre} visualizer. Direction: ${data.hint.slice(0, 200) || "steel club night"}. No emoji. Lyrics only.`
			}]
		})
	});
	if (!res.ok) return {
		ok: false,
		error: `xAI ${res.status}`
	};
	return {
		ok: true,
		text: (await res.json()).choices?.[0]?.message?.content?.trim() ?? ""
	};
});
var visualParams_createServerFn_handler = createServerRpc({
	id: "19af9131710b37ec6a7f52059a4c1b1a4665452e8c7237f674cdea3d73c1359f",
	name: "visualParams",
	filename: "src/lib/studio/ai.ts"
}, (opts) => visualParams.__executeServer(opts));
var visualParams = createServerFn({ method: "POST" }).validator((input) => input).handler(visualParams_createServerFn_handler, async ({ data }) => {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		error: "offline"
	};
	const prompt = data.prompt.trim().slice(0, 500);
	if (!prompt) return {
		ok: false,
		error: "empty"
	};
	const res = await fetch("https://api.x.ai/v1/images/generations", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${apiKey}`
		},
		signal: AbortSignal.timeout(2e4),
		body: JSON.stringify({
			model: "grok-imagine-image",
			prompt: `${prompt}. Industrial steel mixing desk atmosphere, graphite, cream paper light, no neon, no purple, photoreal editorial still.`,
			n: 1,
			response_format: "url"
		})
	});
	if (!res.ok) return {
		ok: false,
		error: `xAI ${res.status}`
	};
	const url = (await res.json()).data?.[0]?.url;
	if (!url) return {
		ok: false,
		error: "empty"
	};
	return {
		ok: true,
		url
	};
});
var scaleRadar_createServerFn_handler = createServerRpc({
	id: "6da032ae7970813ffe388ea83db1935c8bcb2c7ade50e7a658c16e6a70beccac",
	name: "scaleRadar",
	filename: "src/lib/studio/ai.ts"
}, (opts) => scaleRadar.__executeServer(opts));
var scaleRadar = createServerFn({ method: "POST" }).validator((input) => input).handler(scaleRadar_createServerFn_handler, async ({ data }) => {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		error: "offline"
	};
	const lang = data.lang === "et" ? "Estonian" : "English";
	const res = await fetch("https://api.x.ai/v1/chat/completions", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${apiKey}`
		},
		signal: AbortSignal.timeout(12e3),
		body: JSON.stringify({
			model: "grok-4.5",
			max_tokens: 160,
			messages: [{
				role: "user",
				content: `A DAW shipped this: "${data.title}". ${data.note.slice(0, 280)}. In ${lang}, 50 words: how STEEL STUDIO should scale it for Hardstyle/Rap production. No emoji. No marketing fluff.`
			}]
		})
	});
	if (!res.ok) return {
		ok: false,
		error: `xAI ${res.status}`
	};
	return {
		ok: true,
		text: (await res.json()).choices?.[0]?.message?.content?.trim() ?? ""
	};
});
function bufferToB64(buf) {
	const bytes = new Uint8Array(buf);
	let binary = "";
	const chunk = 32768;
	for (let i = 0; i < bytes.length; i += chunk) binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
	return btoa(binary);
}
//#endregion
export { detectLyrics_createServerFn_handler, scaleRadar_createServerFn_handler, speakHook_createServerFn_handler, visualParams_createServerFn_handler, writeHook_createServerFn_handler };
