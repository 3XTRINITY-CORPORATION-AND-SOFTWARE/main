import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { a as NIGHT_HEAR_FIRST, c as VOCAL_LANGS, l as isVocalKind, n as KIND_DSP, o as NIGHT_STANDIN_URL, r as KIND_LABEL, s as VOCAL_KINDS, t as HOOK_PLACEHOLDER, u as isVocalLang } from "./night-Ii85_HfI.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { a as Play, c as Download, i as Presentation, l as Circle, n as Square, o as FileText, r as ScrollText, s as FileSpreadsheet } from "../_libs/lucide-react.mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import { t as require_dist } from "../_libs/yaml.mjs";
import { t as create } from "../_libs/zustand.mjs";
import { i as SignJWT, n as importPKCS8, r as exportPKCS8, t as generateKeyPair } from "../_libs/jose.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-XIYJgfQR.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var import_dist = require_dist();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function downloadBlob(blob, filename) {
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = filename;
	a.rel = "noopener";
	document.body.appendChild(a);
	a.click();
	a.remove();
	window.setTimeout(() => URL.revokeObjectURL(url), 1500);
}
function slugify(value) {
	return value.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "").slice(0, 48) || "workflow";
}
function formatStampDate(date = /* @__PURE__ */ new Date()) {
	return date.toISOString().slice(0, 10);
}
var PLUGIN_IDS = [
	"edge-cut",
	"mud-void",
	"presence-iron",
	"sat-plate",
	"air-well"
];
var REC_IDS = [
	"r1",
	"r2",
	"r3",
	"r4",
	"r5",
	"r6"
];
var r = (id, name, lane, noteEt, noteEn, curve) => ({
	id,
	name,
	lane,
	noteEt,
	noteEn,
	curve
});
/** Original STEEL banks — style recipes, not artist clones. */
var BANKS$1 = [
	r("glasswire", "GLASSWIRE", "rap", "Õhuline auto, kõrge sosin, digiruum.", "Airy auto, high whisper, digital space.", {
		hp: 90,
		scoopHz: 280,
		scoopDb: -3.5,
		presenceHz: 3400,
		presenceDb: 4.2,
		airHz: 9e3,
		airDb: 2.4,
		sat: .12,
		delay: .22,
		space: .38,
		retune: .018,
		amount: .86,
		formant: 1.12,
		width: .62,
		dirt: .22,
		clear: .7,
		key: 9,
		scale: "minor",
		genre: "trap"
	}),
	r("graveink", "GRAVEINK", "rap", "Tume lõuna, tükeldatud 808, porine vokaal.", "Dark south, chopped 808, grimy vocal.", {
		hp: 70,
		scoopHz: 320,
		scoopDb: -1.5,
		presenceHz: 2200,
		presenceDb: 2.2,
		airHz: 7e3,
		airDb: -.8,
		sat: .42,
		delay: .08,
		space: .22,
		retune: .08,
		amount: .45,
		formant: .92,
		width: .38,
		dirt: .78,
		clear: .28,
		key: 4,
		scale: "minor",
		genre: "trap"
	}),
	r("blockiron", "BLOCKIRON", "rap", "Kõva 808, tänava takt, kuiv kesk.", "Hard 808, street takt, dry mid.", {
		hp: 80,
		scoopHz: 250,
		scoopDb: -2.8,
		presenceHz: 2800,
		presenceDb: 3.6,
		airHz: 8200,
		airDb: .6,
		sat: .28,
		delay: .12,
		space: .16,
		retune: .05,
		amount: .58,
		formant: 1,
		width: .44,
		dirt: .55,
		clear: .48,
		key: 7,
		scale: "minor",
		genre: "rap"
	}),
	r("nightvein", "NIGHTVEIN", "rap", "Öine moll, märg ruum, pikk saba.", "Night minor, wet space, long tail.", {
		hp: 85,
		scoopHz: 360,
		scoopDb: -2.2,
		presenceHz: 3100,
		presenceDb: 3,
		airHz: 1e4,
		airDb: 3.2,
		sat: .16,
		delay: .34,
		space: .55,
		retune: .06,
		amount: .72,
		formant: 1.08,
		width: .7,
		dirt: .32,
		clear: .62,
		key: 2,
		scale: "minor",
		genre: "trap"
	}),
	r("razorlung", "RAZORLUNG", "rap", "Moonutatud kops, lai, metalliline serv.", "Distorted lung, wide, metallic edge.", {
		hp: 110,
		scoopHz: 400,
		scoopDb: -4,
		presenceHz: 3800,
		presenceDb: 5.5,
		airHz: 11e3,
		airDb: 1.8,
		sat: .72,
		delay: .1,
		space: .28,
		retune: .03,
		amount: .64,
		formant: .84,
		width: .78,
		dirt: .88,
		clear: .22,
		key: 11,
		scale: "phrygian",
		genre: "trap"
	}),
	r("rapidlock", "RAPIDLOCK", "rap", "Tihe siseriim, kuiv ette, lühike delay.", "Dense internal rhyme, dry-forward, short delay.", {
		hp: 95,
		scoopHz: 300,
		scoopDb: -3.2,
		presenceHz: 3600,
		presenceDb: 4.8,
		airHz: 8500,
		airDb: 1.1,
		sat: .14,
		delay: .14,
		space: .12,
		retune: .04,
		amount: .38,
		formant: 1,
		width: .32,
		dirt: .18,
		clear: .82,
		key: 0,
		scale: "minor",
		genre: "rap"
	}),
	r("queenscold", "QUEENSCOLD", "rap", "Boom bap, tolmune, napp ruum.", "Boom bap, dusty, sparse room.", {
		hp: 75,
		scoopHz: 270,
		scoopDb: -1.8,
		presenceHz: 2400,
		presenceDb: 2.8,
		airHz: 6500,
		airDb: -.4,
		sat: .24,
		delay: .06,
		space: .18,
		retune: .14,
		amount: .22,
		formant: .96,
		width: .28,
		dirt: .6,
		clear: .4,
		key: 5,
		scale: "minor",
		genre: "rap"
	}),
	r("westgrid", "WESTGRID", "rap", "Rääkiv-laul, terav kohalolu, ründav.", "Talk-sung, sharp presence, aggressive.", {
		hp: 88,
		scoopHz: 310,
		scoopDb: -2.4,
		presenceHz: 3e3,
		presenceDb: 4,
		airHz: 7800,
		airDb: .8,
		sat: .22,
		delay: .1,
		space: .14,
		retune: .07,
		amount: .34,
		formant: 1.04,
		width: .4,
		dirt: .48,
		clear: .55,
		key: 7,
		scale: "minor",
		genre: "rap"
	}),
	r("highwire", "HIGHWIRE", "rap", "Kõrge nina, bounce, lühike noot.", "High nasal, bounce, short notes.", {
		hp: 120,
		scoopHz: 340,
		scoopDb: -3.8,
		presenceHz: 4200,
		presenceDb: 5,
		airHz: 9200,
		airDb: 1.6,
		sat: .18,
		delay: .16,
		space: .2,
		retune: .035,
		amount: .5,
		formant: 1.18,
		width: .48,
		dirt: .35,
		clear: .6,
		key: 9,
		scale: "major",
		genre: "rap"
	}),
	r("vowfire", "VOWFIRE", "rap", "Pikk noot, soe kesk, õhuline saba.", "Long notes, warm mid, airy tail.", {
		hp: 70,
		scoopHz: 240,
		scoopDb: -2,
		presenceHz: 2600,
		presenceDb: 3.4,
		airHz: 8800,
		airDb: 2.8,
		sat: .2,
		delay: .2,
		space: .42,
		retune: .16,
		amount: .4,
		formant: .98,
		width: .52,
		dirt: .3,
		clear: .68,
		key: 2,
		scale: "minor",
		genre: "rap"
	}),
	r("eastmirror", "EASTMIRROR", "rap", "Mellic moll, raske auto, peegelruum.", "Melodic minor, heavy auto, mirror space.", {
		hp: 92,
		scoopHz: 300,
		scoopDb: -2.6,
		presenceHz: 3300,
		presenceDb: 3.8,
		airHz: 9600,
		airDb: 2.6,
		sat: .15,
		delay: .28,
		space: .48,
		retune: .022,
		amount: .9,
		formant: 1.06,
		width: .66,
		dirt: .26,
		clear: .74,
		key: 4,
		scale: "minor",
		genre: "trap"
	}),
	r("punchgale", "PUNCHGALE", "hard", "Euforiline reverse, lai vokaal, 150.", "Euphoric reverse, wide vocal, 150.", {
		hp: 100,
		scoopHz: 380,
		scoopDb: -3,
		presenceHz: 3500,
		presenceDb: 4.4,
		airHz: 10500,
		airDb: 3,
		sat: .26,
		delay: .18,
		space: .4,
		retune: .05,
		amount: .7,
		formant: 1.1,
		width: .72,
		dirt: .28,
		clear: .72,
		key: 7,
		scale: "major",
		genre: "hardstyle"
	}),
	r("ironcrest", "IRONCREST", "hard", "Screech-anthem, pitch-üles, raud.", "Screech anthem, pitch-up, iron.", {
		hp: 105,
		scoopHz: 400,
		scoopDb: -3.4,
		presenceHz: 3700,
		presenceDb: 5,
		airHz: 11200,
		airDb: 2.2,
		sat: .34,
		delay: .14,
		space: .32,
		retune: .04,
		amount: .76,
		formant: 1.14,
		width: .68,
		dirt: .4,
		clear: .6,
		key: 11,
		scale: "minor",
		genre: "hardstyle"
	}),
	r("icefound", "ICEFOUND", "hard", "Toores/euforiline hübriid, formant.", "Raw/euphoric hybrid, formant.", {
		hp: 108,
		scoopHz: 360,
		scoopDb: -3.6,
		presenceHz: 3900,
		presenceDb: 4.6,
		airHz: 10800,
		airDb: 1.8,
		sat: .4,
		delay: .12,
		space: .3,
		retune: .03,
		amount: .8,
		formant: .9,
		width: .6,
		dirt: .52,
		clear: .5,
		key: 9,
		scale: "minor",
		genre: "rawstyle"
	}),
	r("warplate", "WARPLATE", "hard", "Toored kickid, tööstuslik plaat.", "Raw kicks, industrial plate.", {
		hp: 95,
		scoopHz: 280,
		scoopDb: -2,
		presenceHz: 2500,
		presenceDb: 3.2,
		airHz: 8e3,
		airDb: .4,
		sat: .55,
		delay: .08,
		space: .18,
		retune: .09,
		amount: .42,
		formant: .88,
		width: .36,
		dirt: .82,
		clear: .24,
		key: 4,
		scale: "phrygian",
		genre: "rawstyle"
	}),
	r("fistcore", "FISTCORE", "hard", "Gabber-serv, kõva lagi, lühike.", "Gabber edge, hard ceiling, short.", {
		hp: 115,
		scoopHz: 420,
		scoopDb: -4.2,
		presenceHz: 4100,
		presenceDb: 5.2,
		airHz: 9e3,
		airDb: .2,
		sat: .68,
		delay: .05,
		space: .1,
		retune: .06,
		amount: .48,
		formant: .86,
		width: .3,
		dirt: .9,
		clear: .18,
		key: 0,
		scale: "chromatic",
		genre: "rawstyle"
	}),
	r("rawhive", "RAWHIVE", "hard", "Rawstyle drive, kärg, kitsas kick.", "Rawstyle drive, hive, tight kick.", {
		hp: 102,
		scoopHz: 340,
		scoopDb: -3.1,
		presenceHz: 3600,
		presenceDb: 4,
		airHz: 9800,
		airDb: 1.2,
		sat: .48,
		delay: .1,
		space: .22,
		retune: .045,
		amount: .66,
		formant: .94,
		width: .5,
		dirt: .7,
		clear: .38,
		key: 7,
		scale: "minor",
		genre: "rawstyle"
	}),
	r("altarraw", "ALTARRAW", "hard", "Tume raw, altar, madal õhk.", "Dark raw, altar, low air.", {
		hp: 90,
		scoopHz: 260,
		scoopDb: -2.2,
		presenceHz: 2700,
		presenceDb: 3.5,
		airHz: 7400,
		airDb: -.6,
		sat: .5,
		delay: .16,
		space: .26,
		retune: .055,
		amount: .6,
		formant: .91,
		width: .46,
		dirt: .76,
		clear: .3,
		key: 3,
		scale: "phrygian",
		genre: "rawstyle"
	}),
	r("zancut", "ZANCUT", "hard", "Klassikaline hardstyle lead, lõige.", "Classic hardstyle lead, cut.", {
		hp: 98,
		scoopHz: 370,
		scoopDb: -2.8,
		presenceHz: 3400,
		presenceDb: 4.3,
		airHz: 10200,
		airDb: 2,
		sat: .3,
		delay: .15,
		space: .28,
		retune: .05,
		amount: .68,
		formant: 1.05,
		width: .58,
		dirt: .36,
		clear: .64,
		key: 5,
		scale: "major",
		genre: "hardstyle"
	}),
	r("nightpeak", "NIGHTPEAK", "hard", "Peak-time techno, öine lagi.", "Peak-time techno, night ceiling.", {
		hp: 85,
		scoopHz: 300,
		scoopDb: -2.5,
		presenceHz: 2900,
		presenceDb: 3.3,
		airHz: 8600,
		airDb: 1.4,
		sat: .38,
		delay: .09,
		space: .2,
		retune: .1,
		amount: .3,
		formant: .97,
		width: .42,
		dirt: .58,
		clear: .46,
		key: 2,
		scale: "minor",
		genre: "techno"
	})
];
var BANK_BY_ID = Object.fromEntries(BANKS$1.map((b) => [b.id, b]));
function emptyRecs() {
	const out = {};
	for (const id of REC_IDS) out[id] = {
		id,
		bankId: null,
		loaded: false,
		armed: id === "r1",
		gain: .86,
		edit: {}
	};
	return out;
}
function resolvedCurve(lane) {
	if (!lane.bankId || !lane.loaded) return null;
	const bank = BANK_BY_ID[lane.bankId];
	if (!bank) return null;
	return {
		...bank.curve,
		...lane.edit
	};
}
function armedCurve(recs) {
	const armed = REC_IDS.map((id) => recs[id]).find((r) => r.armed && r.loaded);
	if (armed) return resolvedCurve(armed);
	const any = REC_IDS.map((id) => recs[id]).find((r) => r.loaded);
	return any ? resolvedCurve(any) : null;
}
var PLUGIN_META = {
	"edge-cut": {
		et: "EDGE-CUT · kõrgpääs",
		en: "EDGE-CUT · high-pass"
	},
	"mud-void": {
		et: "MUD-VOID · mudaauk",
		en: "MUD-VOID · mud scoop"
	},
	"presence-iron": {
		et: "PRESENCE-IRON · kohalolu",
		en: "PRESENCE-IRON · presence"
	},
	"sat-plate": {
		et: "SAT-PLATE · küllastus",
		en: "SAT-PLATE · saturation"
	},
	"air-well": {
		et: "AIR-WELL · ruum",
		en: "AIR-WELL · space"
	}
};
var EXTRA_IDS = [
	"MI44OR-5GEM",
	"WHISP3RER",
	"DIRT-COL",
	"CLEAR-COL",
	"THEORY-SPINE",
	"ENERGY-MATCH",
	"TAKT-LOCK",
	"GYRATOR-AIR",
	"PRESHAPE-SAT",
	"STEREO-MX"
];
function clamp10(n) {
	return Math.max(0, Math.min(10, Math.round(n * 10) / 10));
}
function buildSpine(opts) {
	const curve = opts.curve;
	const dirt = curve ? curve.dirt * (.5 + opts.dirtBias * .5) : .4;
	const clear = curve ? curve.clear * (1.2 - opts.dirtBias * .4) : .55;
	const bpm = opts.bpm;
	const genre = opts.genre;
	const paste = opts.paste.trim();
	const night = Boolean(opts.nightLane);
	const extras = [
		{
			id: "MI44OR-5GEM",
			action: "Five-generation analog mirror on the same container.",
			on: true,
			intensity: clamp10(night ? 6.5 : 6 + (curve?.sat ?? 0) * 4),
			why: night ? "VEC-WDF · keep / even body / odd edge / rounded HF / mid stability." : "Target 5x body vs a free EQ dump."
		},
		{
			id: "WHISP3RER",
			action: "Bit-aware dither in unused slack. No format change.",
			on: true,
			intensity: night ? 4 : clamp10(4 + clear * 3),
			why: night ? "TPDF-DECORR · intensity 4. No payload." : "Keeps the source bit depth honest."
		},
		{
			id: "DIRT-COL",
			action: "Saturation topology from the dirt score.",
			on: dirt > .12,
			intensity: night ? clamp10(Math.max(1, Math.min(4, dirt * 10))) : clamp10(dirt * 10),
			why: night ? "CHEBY · dirt 1–4 on the loud stack." : paste || "Rulebreaker dirt kept as a target."
		},
		{
			id: "CLEAR-COL",
			action: "Subtractive mud/harsh cuts before any boost.",
			on: clear > .35 || night,
			intensity: clamp10(night ? Math.max(5, clear * 10) : clear * 10),
			why: night ? "ERB-CUT · quiet-lead pocket 2.5–5 kHz." : "Cut before boost — analog-mirror law."
		},
		{
			id: "THEORY-SPINE",
			action: "Reusable recipe from pulse, takt, chroma.",
			on: true,
			intensity: 8,
			why: night ? `${genre} @ ${bpm} · quiet lead / loud stack` : `${genre} @ ${bpm}`
		},
		{
			id: "ENERGY-MATCH",
			action: "Crest and transient density aimed at the bank.",
			on: true,
			intensity: clamp10(5 + (curve?.sat ?? .3) * 5),
			why: night ? "SHAPE-GAIN · loudness does not restyle the house." : opts.bank?.name ?? "desk energy"
		},
		{
			id: "TAKT-LOCK",
			action: genre === "rap" || genre === "trap" ? "Trap/boom bar grid for rhyme-lock." : "Four-on-the-floor grid.",
			on: true,
			intensity: night ? 8 : 7,
			why: night ? `${bpm} BPM · PD-MAG. JND-ASYNC only if stack sits off the kit.` : `${bpm} BPM`
		},
		{
			id: "GYRATOR-AIR",
			action: "Circuit-like high shelf, not a drawn curve.",
			on: (curve?.airDb ?? 0) > 0 || night,
			intensity: clamp10(night ? 3.5 : 4 + (curve?.airDb ?? 0)),
			why: night ? "SVF-GYR · air on the lead." : "Air well plugin."
		},
		{
			id: "PRESHAPE-SAT",
			action: "Pull harsh bands out before the saturator.",
			on: true,
			intensity: clamp10(night ? 6.5 : 5 + (curve?.presenceDb ?? 3) * .4),
			why: night ? "PRE-POST · 2.5–5 kHz out of sat on the quiet lead." : "Stops hash on SAT-PLATE."
		},
		{
			id: "STEREO-MX",
			action: night ? "EQUAL on the quiet lead. MODERN on the louder stack." : (curve?.width ?? .5) > .55 ? "MODERN L/R matrix." : "EQUAL L/R matrix.",
			on: true,
			intensity: clamp10(night ? 6 : (curve?.width ?? .5) * 10),
			why: night ? "IACC-SAFE · EQUAL lead / MODERN stack." : "4D width after the melt."
		}
	];
	const hearFirst = night ? [...NIGHT_HEAR_FIRST] : extras.slice().sort((a, b) => Number(b.on) - Number(a.on) || b.intensity - a.intensity).slice(0, 3).map((e) => e.id);
	return {
		pulse: `${bpm} BPM · ${genre === "rap" ? "4/4 boom-trap" : "4/4 floor"}`,
		takt: genre === "rap" || genre === "trap" ? "stress 1+3, 808 on 1" : "kick every quarter",
		pitchHouse: curve ? `key ${curve.key} ${curve.scale}` : "unknown — no bank loaded",
		fn: genre === "hardstyle" ? "drop-dominant loop" : "no-cadence loop",
		tension: dirt > .6 ? "held dissonance, late release" : "short release",
		chroma: clear > dirt ? "bright / mid-forward" : "dark / low-forward",
		crest: dirt > .7 ? "low crest, dense body" : "higher crest, clicky transients",
		transient: genre.includes("style") || genre === "techno" ? "clicky / gated" : "rounded",
		harmonicDirt: dirt > .5 ? "odd harmonics, tape smear" : "clean odd, light sat",
		form: "intro / hook gravity / drop / outro",
		dirt: Math.max(0, Math.min(1, dirt)),
		clear: Math.max(0, Math.min(1, clear)),
		extras,
		hearFirst
	};
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap font-medium select-none transition-[opacity,transform,background-color,color,border-color] duration-[var(--motion-quick)] ease-[var(--ease-out)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-steel/50 focus-visible:ring-offset-2 focus-visible:ring-offset-paper disabled:pointer-events-none disabled:opacity-40 active:not-disabled:scale-[0.96]", {
	variants: {
		variant: {
			primary: "bg-ink text-paper hover:bg-ink/90",
			secondary: "border border-rule bg-transparent text-ink hover:bg-ink/[0.06]",
			ghost: "text-ink/80 hover:bg-ink/[0.06] hover:text-ink",
			stamp: "bg-clip text-paper hover:bg-clip/90",
			live: "bg-live text-paper hover:bg-live/90",
			paper: "bg-raised text-ink border border-rule hover:bg-rule/40"
		},
		size: {
			sm: "h-9 px-3 text-sm rounded-[var(--radius-sm)]",
			md: "h-11 px-4 text-sm rounded-[var(--radius-md)]",
			lg: "h-12 px-5 text-base rounded-[var(--radius-md)]",
			icon: "size-11 rounded-[var(--radius-md)]"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "md"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		ref,
		...props
	});
});
Button.displayName = "Button";
var FORMATS = [
	{
		id: "pdf",
		label: "PDF",
		icon: ScrollText
	},
	{
		id: "docx",
		label: "Word",
		icon: FileText
	},
	{
		id: "xlsx",
		label: "Excel",
		icon: FileSpreadsheet
	},
	{
		id: "pptx",
		label: "Slides",
		icon: Presentation
	}
];
async function runExport(id, report) {
	switch (id) {
		case "pdf": return (await import("./pdf-C_nbPQcS.mjs")).exportPdf(report);
		case "docx": return (await import("./docx-CjlndW4C.mjs")).exportDocx(report);
		case "xlsx": return (await import("./xlsx-St5fzBCX.mjs")).exportXlsx(report);
		case "pptx": return (await import("./pptx-CoErC2U3.mjs")).exportPptx(report);
		default: throw new Error("Unknown export");
	}
}
function ExportMenu({ report }) {
	const [busy, setBusy] = (0, import_react.useState)(null);
	async function handle(id, label) {
		setBusy(id);
		try {
			await runExport(id, report);
			toast.success(`${label} report downloaded`);
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Export failed");
		} finally {
			setBusy(null);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex flex-wrap gap-2",
		children: FORMATS.map((fmt) => {
			const Icon = fmt.icon;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				type: "button",
				variant: "secondary",
				size: "sm",
				disabled: busy !== null,
				onClick: () => void handle(fmt.id, fmt.label),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
					className: "size-3.5",
					strokeWidth: 1.75
				}), busy === fmt.id ? "Preparing" : fmt.label]
			}, fmt.id);
		})
	});
}
var ORDER = [
	"critical",
	"high",
	"medium",
	"low",
	"info",
	"pass"
];
function tone(s) {
	if (s === "pass") return "text-sage";
	if (s === "info") return "text-muted";
	return "text-stamp";
}
function FindingsPanel({ findings }) {
	const grouped = ORDER.map((sev) => ({
		sev,
		items: findings.filter((f) => f.severity === sev)
	})).filter((g) => g.items.length);
	let n = 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
		className: "flex flex-col gap-5",
		children: grouped.map((group) => group.items.map((f) => {
			n += 1;
			const id = `F-${String(n).padStart(3, "0")}`;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "find-enter border-t border-rule pt-4",
				style: { animationDelay: `${Math.min(n, 8) * 40}ms` },
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-baseline justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: cn("font-mono text-2xs tracking-wider uppercase", tone(f.severity)),
							children: [
								id,
								" · ",
								f.severity
							]
						}), f.location ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "max-w-full truncate font-mono text-2xs text-faint",
							children: f.location
						}) : null]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mt-1 text-xl text-ink",
						children: f.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-[0.98rem] leading-relaxed text-ink/90",
						children: f.detail
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 text-sm leading-relaxed text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium text-ink",
							children: "Fix. "
						}), f.remediation]
					})
				]
			}, f.id);
		}))
	});
}
function ScoreMark({ grade, score, className }) {
	const failed = grade === "D" || grade === "F";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("relative flex size-28 shrink-0 items-center justify-center sm:size-32", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			viewBox: "0 0 120 120",
			className: "absolute inset-0",
			"aria-hidden": "true",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "60",
				cy: "60",
				r: "56",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1.25",
				className: failed ? "text-stamp" : "text-rule"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "60",
				cy: "60",
				r: "50",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "0.6",
				className: "text-rule"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative text-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: cn("stamp-grade text-5xl leading-none sm:text-6xl", failed ? "text-stamp" : "text-ink"),
				children: grade
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-1 font-mono text-2xs tracking-wider text-muted tabular-nums",
				children: score
			})]
		})]
	});
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var NAME = /^[A-Za-z0-9_.-]+$/;
function parseRepoSpec(raw) {
	const parts = raw.trim().replace(/^https?:\/\/(www\.)?github\.com\//i, "").replace(/\.git$/i, "").split("/").filter(Boolean);
	if (parts.length < 2) return null;
	const owner = parts[0];
	const repo = parts[1];
	if (!NAME.test(owner) || !NAME.test(repo)) return null;
	return {
		owner,
		repo
	};
}
function isWorkflowPath(path) {
	return /^\.github\/workflows\/[A-Za-z0-9_.-]+\.(ya?ml)$/.test(path);
}
var scanGithubRepo = createServerFn({ method: "POST" }).validator((input) => {
	const parsed = parseRepoSpec(String(input?.spec ?? ""));
	if (!parsed) throw new Error("repo");
	return parsed;
}).handler(createSsrRpc("082801aca6fbe6a118b65506c472e207df501c662e24e54ff63623116b01efed"));
var fetchGithubWorkflow = createServerFn({ method: "POST" }).validator((input) => {
	const owner = String(input?.owner ?? "");
	const repo = String(input?.repo ?? "");
	const path = String(input?.path ?? "");
	if (!NAME.test(owner) || !NAME.test(repo) || !isWorkflowPath(path)) throw new Error("path");
	return {
		owner,
		repo,
		path
	};
}).handler(createSsrRpc("1a2e004726a3f77617da1daeefc2d368bd47a30778785a09346320bfb9d51f4e"));
var SEVERITY_WEIGHT = {
	critical: 28,
	high: 16,
	medium: 8,
	low: 3,
	info: 0,
	pass: 0
};
var INJECTION_RE = /\$\{\{\s*(github\.(event\.|head_ref|ref\b|actor\b)|inputs\.|matrix\.)/i;
var TOKEN_RE = /secrets\.GITHUB_TOKEN|github\.token|GH_TOKEN|GITHUB_TOKEN/i;
var APP_TOKEN_RE = /create-github-app-token|APP_PRIVATE_KEY|APP_CLIENT_ID/i;
var ACTION_USE_RE = /^([^@]+)@(.+)$/;
var SHA_RE = /^[0-9a-f]{40}$/i;
function asRecord(value) {
	if (value && typeof value === "object" && !Array.isArray(value)) return value;
	return null;
}
function asString(value) {
	return typeof value === "string" ? value : void 0;
}
function runsOn(value) {
	if (typeof value === "string") return value;
	if (Array.isArray(value)) return value.map(String).join(", ");
}
function triggerNames(on) {
	if (!on) return [];
	if (typeof on === "string") return [on];
	if (Array.isArray(on)) return on.map(String);
	const rec = asRecord(on);
	if (!rec) return [];
	return Object.keys(rec);
}
function permissionMap(value) {
	if (typeof value === "string") return { "*": value };
	const rec = asRecord(value);
	if (!rec) return null;
	const out = {};
	for (const [k, v] of Object.entries(rec)) out[k] = String(v);
	return out;
}
function parseSteps(raw) {
	if (!Array.isArray(raw)) return [];
	return raw.map((item) => {
		const rec = asRecord(item) ?? {};
		return {
			name: asString(rec.name),
			uses: asString(rec.uses),
			run: asString(rec.run),
			with: asRecord(rec.with) ?? void 0,
			env: asRecord(rec.env) ?? void 0,
			id: asString(rec.id)
		};
	});
}
function parseWorkflow(yamlText) {
	try {
		const rec = asRecord((0, import_dist.parse)(yamlText));
		if (!rec) return {
			on: void 0,
			jobs: [],
			parseError: "Workflow is not a mapping."
		};
		const jobsRec = asRecord(rec.jobs) ?? {};
		const jobs = Object.entries(jobsRec).map(([id, job]) => {
			const j = asRecord(job) ?? {};
			return {
				id,
				name: asString(j.name),
				runsOn: runsOn(j["runs-on"]),
				permissions: j.permissions,
				steps: parseSteps(j.steps),
				if: asString(j.if)
			};
		});
		return {
			name: asString(rec.name),
			on: rec.on,
			permissions: rec.permissions,
			jobs
		};
	} catch (err) {
		return {
			on: void 0,
			jobs: [],
			parseError: err instanceof Error ? err.message : "YAML parse failed."
		};
	}
}
function finding(id, severity, title, detail, remediation, rule, location) {
	return {
		id,
		severity,
		title,
		detail,
		remediation,
		rule,
		location
	};
}
function flattenUses(jobs) {
	const out = [];
	for (const job of jobs) job.steps.forEach((step, index) => out.push({
		job: job.id,
		step,
		index
	}));
	return out;
}
function auditWorkflow(yamlText) {
	const parsed = parseWorkflow(yamlText);
	const findings = [];
	const triggers = triggerNames(parsed.on);
	const allSteps = flattenUses(parsed.jobs);
	const usesToken = TOKEN_RE.test(yamlText);
	const usesApp = APP_TOKEN_RE.test(yamlText);
	const topPerms = permissionMap(parsed.permissions);
	const anyJobPerms = parsed.jobs.some((j) => j.permissions != null);
	const hasPermissions = Boolean(topPerms) || anyJobPerms;
	if (parsed.parseError) findings.push(finding("parse", "high", "YAML did not parse", parsed.parseError, "Fix the workflow syntax, then re-run the audit. Tabs, unquoted colons, and `on:` boolean coercion are common traps.", "yaml-parse"));
	if (!parsed.parseError && parsed.jobs.length === 0) findings.push(finding("no-jobs", "high", "No jobs found", "A workflow without jobs cannot run, so it cannot be privilege-reviewed.", "Add at least one job with steps.", "structure"));
	if (!hasPermissions && parsed.jobs.length > 0) findings.push(finding("no-permissions", "high", "No permissions block", "Without an explicit permissions key, GITHUB_TOKEN inherits the repository default (permissive or restricted). That default is not visible in the YAML, so reviewers cannot attest least privilege.", "Set workflow-level `permissions:` to the minimum, then raise per job. Start with `contents: read` and add write scopes only where a step needs them.", "permissions-missing"));
	else if (topPerms && (topPerms["*"] === "write-all" || Object.values(topPerms).includes("write-all"))) findings.push(finding("write-all", "critical", "permissions: write-all", "write-all grants every GITHUB_TOKEN scope, including contents, actions, packages, and id-token.", "Replace write-all with an explicit map of the two or three scopes this workflow actually uses.", "permissions-write-all"));
	if (topPerms && topPerms["*"] === "read-all") findings.push(finding("read-all", "medium", "permissions: read-all", "read-all is safer than write-all but still broader than a typical lint or test job needs.", "Prefer `contents: read` (and `pull-requests: read` if required) instead of a blanket read-all.", "permissions-read-all"));
	const writeScopes = /* @__PURE__ */ new Set();
	const collectWrites = (perms, loc) => {
		if (!perms) return;
		for (const [scope, level] of Object.entries(perms)) if (level === "write" || level === "write-all") {
			writeScopes.add(scope);
			if (scope === "contents" && level === "write") {
				if (!(/deploy|release|tag|commit|push|pages/i.test(yamlText) || /peaceiris\/actions-gh-pages|stefanzweifel\/git-auto-commit|softprops\/action-gh-release/i.test(yamlText))) findings.push(finding(`contents-write-${loc}`, "medium", "contents: write may be unnecessary", `Job or workflow '${loc}' grants contents: write. Most issue, comment, and check workflows only need contents: read.`, "Drop contents: write unless a step commits, tags, or publishes to the repo. The Open Issue example only needs contents: read + issues: write.", "permissions-contents-write", loc));
			}
		}
	};
	collectWrites(topPerms, "workflow");
	for (const job of parsed.jobs) collectWrites(permissionMap(job.permissions), job.id);
	if (triggers.includes("pull_request_target")) {
		const checksOutPr = allSteps.some((s) => {
			const ref = s.step.with ? String(s.step.with.ref ?? "") : "";
			return Boolean(s.step.uses?.startsWith("actions/checkout")) && /pull_request\.head|github\.event\.pull_request/i.test(ref);
		});
		findings.push(finding("pr-target", checksOutPr ? "critical" : "high", "pull_request_target runs in the base repo context", checksOutPr ? "This workflow both uses pull_request_target (so GITHUB_TOKEN can write to the base repo) and checks out the pull request head. A fork PR can execute untrusted code with a write token." : "pull_request_target grants a write-capable token from the base repository. Any later checkout of PR code, or interpolation of PR titles into run:, is a privilege escalation.", "Use `pull_request` for CI. If you must label or comment from the base repo, do it in a separate job that does not check out PR code and does not interpolate untrusted fields into run:.", "pull-request-target", "on.pull_request_target"));
	}
	allSteps.forEach(({ job, step, index }) => {
		const loc = `${job} / step ${index + 1}${step.name ? ` (${step.name})` : ""}`;
		if (step.run && INJECTION_RE.test(step.run)) findings.push(finding(`inject-${job}-${index}`, "critical", "Possible script injection in run:", "The script interpolates a GitHub context value directly into bash. Attackers who control a PR title, branch name, or issue body can inject `; evil; #` into the shell.", "Pass untrusted values through `env:` and read `$TITLE` (quoted) inside the script. Never splice `${{ github.event.* }}` into run:.", "script-injection", loc));
		if (step.uses) {
			const match = ACTION_USE_RE.exec(step.uses.trim());
			if (match) {
				const ref = match[2];
				if (!SHA_RE.test(ref.split("#")[0].trim()) && (ref === "main" || ref === "master" || ref.startsWith("v") || ref.includes("."))) {
					const severity = ref === "main" || ref === "master" ? "high" : "medium";
					findings.push(finding(`pin-${job}-${index}`, severity, `Action is not pinned to a SHA`, `${step.uses} follows a moving tag or branch. A compromised publisher can change what your workflow executes without a diff in this file.`, "Pin to a 40-character commit SHA and leave the version in a trailing comment, e.g. `actions/checkout@11bd7190… # v4.2.2`.", "unpinned-action", loc));
				}
			}
		}
		if (step.run && /curl /.test(step.run) && !/--fail\b/.test(step.run)) findings.push(finding(`curl-fail-${job}-${index}`, "low", "curl without --fail", "A 4xx/5xx from the GitHub API would still exit 0, so a failed issue create looks like success.", "Add `--fail` (or `-f`) to curl, as in GitHub's REST example.", "curl-fail", loc));
	});
	if (usesToken && /secrets\.GITHUB_TOKEN/.test(yamlText) && !/github\.token/.test(yamlText)) findings.push(finding("secrets-github-token", "info", "Using secrets.GITHUB_TOKEN", "The automatic token is also available as github.token. Both work. Prefer github.token so it is obvious this is not a stored PAT.", "Set `GH_TOKEN: ${{ github.token }}` (or the authorization header) instead of secrets.GITHUB_TOKEN.", "token-alias"));
	if (triggers.includes("push") && writeScopes.has("issues")) findings.push(finding("issue-on-push", "medium", "Opens issues on every push", "A push trigger plus issues: write will file a new issue for each commit, including force-pushes and bot commits. The GitHub docs example does this to demonstrate the REST call — it is rarely what you want in production.", "Gate on workflow_dispatch, a label, a path filter, or `if: github.event.head_commit.committer.username != 'github-actions[bot]'`.", "noisy-trigger", "on.push"));
	if (usesApp) {
		const appStep = allSteps.find((s) => s.step.uses?.includes("create-github-app-token"));
		if (appStep && /@v\d/.test(appStep.step.uses ?? "")) findings.push(finding("app-token-pin", "medium", "GitHub App token action is tag-pinned", `${appStep.step.uses} mints an installation token from a private key. Treat this like production auth — pin the SHA.`, "Pin `actions/create-github-app-token` to a commit SHA. Keep APP_PRIVATE_KEY in Actions secrets; never echo it. JWTs must expire within 10 minutes.", "app-token", `${appStep.job} / ${appStep.step.name ?? "generate-token"}`));
		if (!/permissions:/.test(yamlText)) findings.push(finding("app-token-no-perms", "info", "App token bypasses GITHUB_TOKEN permissions", "An installation token has the GitHub App's permissions, not the workflow permissions: map. Tight YAML permissions will not shrink what the app can do.", "Review the App's installation permissions in GitHub settings. Mint the token only in jobs that need it, and never pass it to untrusted checkout.", "app-token-scope"));
	}
	if (/Authorization: token /.test(yamlText) && /JWT|YOUR_JWT/.test(yamlText)) findings.push(finding("jwt-bearer", "info", "JWTs must use Bearer", "GitHub accepts `Authorization: token` for installation tokens and PATs, but a GitHub App JWT must be `Authorization: Bearer`.", "Use Bearer for JWTs. Keep iat 60 seconds in the past for clock drift and exp no more than 10 minutes ahead. Sign with RS256.", "jwt-header"));
	const persist = allSteps.find((s) => {
		if (!s.step.uses?.startsWith("actions/checkout")) return false;
		const persistCreds = s.step.with?.["persist-credentials"];
		return persistCreds !== false && persistCreds !== "false";
	});
	if (persist && triggers.includes("pull_request_target")) findings.push(finding("persist-creds", "high", "checkout persist-credentials on untrusted PR", "The default checkout persists GITHUB_TOKEN into local git config. Combined with PR code, later steps can push as the token.", "Set `persist-credentials: false` on checkout, or do not check out PR head in this job.", "persist-credentials", persist.job));
	if (!parsed.parseError && parsed.jobs.length > 0 && findings.every((f) => f.severity === "info" || f.severity === "pass")) findings.push(finding("lean", "pass", "Lean already. Ship.", "No over-privilege or injection findings on this pass. Keep the permissions map explicit when you add jobs.", "Re-run Attest whenever the workflow or the App's permissions change.", "clean"));
	if (hasPermissions && !findings.some((f) => f.rule === "permissions-missing" || f.rule === "permissions-write-all")) findings.push(finding("explicit-permissions", "pass", "Explicit permissions map", "This workflow declares GITHUB_TOKEN scopes in YAML, which is what reviewers (and Attest) can actually attest.", "Keep raising or dropping scopes per job instead of widening the workflow default.", "permissions-present"));
	const penalty = findings.reduce((sum, f) => sum + SEVERITY_WEIGHT[f.severity], 0);
	const score = Math.max(0, Math.min(100, 100 - penalty));
	const grade = score >= 90 ? "A" : score >= 75 ? "B" : score >= 60 ? "C" : score >= 40 ? "D" : "F";
	const criticals = findings.filter((f) => f.severity === "critical").length;
	const highs = findings.filter((f) => f.severity === "high").length;
	const summary = criticals > 0 ? `${criticals} critical finding${criticals === 1 ? "" : "s"}. Do not ship this token as-is.` : highs > 0 ? `${highs} high-severity finding${highs === 1 ? "" : "s"} on GITHUB_TOKEN or untrusted code.` : score >= 90 ? "Least privilege holds. Permissions are explicit and the run: scripts look clean." : "No critical issues, but the token still has room to shrink.";
	const ordered = [...findings].sort((a, b) => SEVERITY_WEIGHT[b.severity] - SEVERITY_WEIGHT[a.severity]);
	return {
		name: parsed.name || "untitled workflow",
		score,
		grade,
		summary,
		findings: ordered,
		stats: {
			jobs: parsed.jobs.length,
			steps: allSteps.length,
			triggers: triggers.length ? triggers : ["(none)"],
			hasPermissions,
			usesGithubToken: usesToken,
			usesAppToken: usesApp
		},
		yaml: yamlText,
		auditedAt: (/* @__PURE__ */ new Date()).toISOString()
	};
}
var SAMPLE_WORKFLOWS = [
	{
		id: "open-issue",
		title: "Open issue (workflow_dispatch)",
		blurb: "GitHub CLI + GITHUB_TOKEN. Least privilege is close — pin it.",
		yaml: `name: Open new issue
on: workflow_dispatch

jobs:
  open-issue:
    runs-on: ubuntu-latest
    permissions:
      contents: read
      issues: write
    steps:
      - run: |
          gh issue --repo \${{ github.repository }} \\
            create --title "Issue title" --body "Issue body"
        env:
          GH_TOKEN: \${{ secrets.GITHUB_TOKEN }}
`
	},
	{
		id: "issue-on-push",
		title: "Create issue on every push",
		blurb: "REST call with Bearer token. Noisy trigger, unpinned defaults.",
		yaml: `name: Create issue on commit

on: [ push ]

jobs:
  create_issue:
    runs-on: ubuntu-latest
    permissions:
      issues: write
    steps:
      - name: Create issue using REST API
        run: |
          curl --request POST \\
          --url https://api.github.com/repos/\${{ github.repository }}/issues \\
          --header 'authorization: Bearer \${{ secrets.GITHUB_TOKEN }}' \\
          --header 'content-type: application/json' \\
          --data '{
            "title": "Automated issue for commit: \${{ github.sha }}",
            "body": "This issue was automatically created by the GitHub Action workflow **\${{ github.workflow }}**. \\n\\n The commit hash was: _\${{ github.sha }}_."
            }' \\
          --fail
`
	},
	{
		id: "app-token",
		title: "GitHub App installation token",
		blurb: "create-github-app-token. Prefer SHA pins and short-lived JWTs.",
		yaml: `on:
  workflow_dispatch:
jobs:
  demo_app_authentication:
    runs-on: ubuntu-latest
    steps:
      - name: Generate a token
        id: generate-token
        uses: actions/create-github-app-token@v3
        with:
          client-id: \${{ vars.APP_CLIENT_ID }}
          private-key: \${{ secrets.APP_PRIVATE_KEY }}

      - name: Use the token
        env:
          GH_TOKEN: \${{ steps.generate-token.outputs.token }}
        run: |
          gh api octocat
`
	},
	{
		id: "pr-target",
		title: "Dangerous pull_request_target",
		blurb: "Untrusted checkout + script injection. Expect a failing grade.",
		yaml: `name: PR comments
on: pull_request_target

jobs:
  greet:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
        with:
          ref: \${{ github.event.pull_request.head.sha }}
      - name: Comment
        run: |
          echo "Title: \${{ github.event.pull_request.title }}"
          npm test
        env:
          GITHUB_TOKEN: \${{ secrets.GITHUB_TOKEN }}
`
	},
	{
		id: "hardened",
		title: "Hardened least privilege",
		blurb: "Pinned action, explicit read-only token, no interpolation in run.",
		yaml: `name: Lint
on:
  pull_request:
    branches: [main]

permissions:
  contents: read

jobs:
  lint:
    runs-on: ubuntu-latest
    permissions:
      contents: read
    steps:
      - uses: actions/checkout@11bd71901bbe5b1630ceea73d27597364c9af683 # v4.2.2
      - uses: actions/setup-node@39370e3970a6d050c480ffad4ff0ed4d3fdee5af # v4.1.0
        with:
          node-version: "22"
          cache: npm
      - name: Install and lint
        run: |
          npm ci
          npm run lint
`
	}
];
var first = SAMPLE_WORKFLOWS[0];
var useAudit = create((set, get) => ({
	yaml: first.yaml,
	sampleId: first.id,
	report: auditWorkflow(first.yaml),
	tab: "audit",
	setYaml: (yaml) => set({
		yaml,
		sampleId: "custom"
	}),
	run: () => set({ report: auditWorkflow(get().yaml) }),
	loadSample: (id) => {
		const sample = SAMPLE_WORKFLOWS.find((s) => s.id === id);
		if (!sample) return;
		set({
			yaml: sample.yaml,
			sampleId: id,
			report: auditWorkflow(sample.yaml)
		});
	},
	setTab: (tab) => set({ tab })
}));
var STR = {
	et: {
		skip: "Liigu sisu juurde",
		console: "Konsool",
		desk: "Pult",
		aura: "Aura",
		pipeline: "Ahel",
		hosts: "Hostid",
		kernel: "Tuum",
		ready: "valmis",
		deskKicker: "Moodul 03 · Pult",
		deskTitle: "Biit ühes pesas, hääl teises.",
		deskLead: "Laadi hiphop-biit, pane vokaal teise pessa, haagi autotune ja master. See leht on veebituum — õige ASIO/VST jääb masinasse, mitte brauserisse.",
		slotBeat: "Pesa A · Biit",
		slotVocal: "Pesa B · Vokaal",
		loadBeat: "Laadi biit",
		demoBeat: "Demo-biit (90 BPM)",
		loadVocal: "Laadi vokaal",
		recVoice: "Salvesta hääl",
		liveMic: "Elav mikrofon",
		emptySlot: "Tühi",
		playMix: "Mängi mix",
		stopMix: "Peata",
		autotune: "Autotune",
		amount: "Tugevus",
		speed: "Kiirus",
		key: "Helistik",
		chromatic: "Kromaatiline",
		minor: "Moll",
		major: "Duur",
		master: "Master",
		ceiling: "Lagi",
		drive: "Drive",
		width: "Laius",
		glue: "Liim",
		duck: "Duck",
		analytics: "Analüütika",
		peak: "Tipp",
		loud: "Valjus",
		crest: "Crest",
		bpm: "BPM",
		detected: "Tuvastatud",
		clips: "Klipp",
		aiMix: "AI mix",
		aiBusy: "Kuulan…",
		bounce: "Bounce WAV",
		saveRow: "Salvesta rida",
		rows: "Read",
		rowSaved: "Rida salvestatud",
		rowFail: "Rida ei õnnestunud kirjutada.",
		noRows: "Ridu pole veel.",
		loadRow: "Laadi",
		clear: "Tühjenda",
		spaceHint: "Tühik: mängi / peata",
		micBlocked: "Mikrofon on selles vaates blokeeritud. Laadi vokaal failina või kasuta „Salvesta hääl“.",
		decodeFail: "Seda faili ei õnnestunud avada. Proovi WAV, MP3 või M4A.",
		needSlots: "Laadi biit või vokaal — või vajuta demo-biit.",
		mixOn: "Mix käib",
		footer: "ASIO4ALL 2.22 · Win 8/10/11 · FL Studio 21+ · veebituum ei asenda VST-d",
		tuumNote: "ASIO 5.9 ei ole avalik draiver. Lauatugi on ASIO4ALL 2.22 ja tootja ASIO 2.3. FL Studio alates 20.8 MIDI-mootorist (nimetatud kui 17+) kuni praeguseni. VST3 ei tööta selles lehes — kasuta Hostid-sakki ja loopMIDI / PipeASIO.",
		heuristicApplied: "Rakendatud terav mix (kohalik mootor).",
		recDone: "Hääl salvestatud",
		recStart: "Salvestan… vajuta uuesti, et lõpetada",
		audit: "Audit",
		auditKicker: "Moodul 04 · Attest",
		auditTitle: "GITHUB_TOKEN ja JWT, siin brauseris.",
		auditLead: "Skaneeri avalik GitHubi repo või kleebi YAML. Auditeerime õigused, pull_request_target, kinnitamata actionid ja App JWT.",
		ghScan: "Skaneeri GitHub",
		ghSpec: "omanik/repo",
		ghBusy: "Loen GitHubi…",
		ghEmpty: "Selles repos .github/workflows puudub.",
		ghMiss: "Repot ei leitud või see on privaatne.",
		ghRate: "GitHubi limiit. Proovi hetke pärast.",
		ghFail: "GitHubi päring ebaõnnestus.",
		ghFiles: "Töövoogude failid",
		jwtKicker: "GitHub App JWT",
		jwtTitle: "Kümme minutit, RS256, Bearer",
		jwtLead: "GitHub App autentib ennast JWT-ga, siis vahetab selle installation-tokeni vastu. JWT ei kuulu GITHUB_TOKEN-isse. Võtmed jäävad sellesse sakki.",
		jwtMint: "Loo demo-võti",
		jwtSign: "Allkirjasta JWT",
		jwtCopy: "Kopeeri JWT",
		jwtIss: "Client ID (iss)",
		jwtPem: "PKCS#8 PEM",
		jwtSignIn: "Allkirjasta siin brauseris",
		jwtCompact: "Compact serialization",
		jwtBearerNote: "Saada kui Authorization: Bearer. GitHub lükkab JWTide puhul tagasi Authorization: token. Vaheta installation-tokeni vastu; ära kasuta JWT-d kui GH_TOKEN.",
		jwtDemoNote: "Demo-võtmed ei ole GitHubis registreeritud. Kasuta neid claimide vaatamiseks. Päris Appi jaoks kleebi GitHubi antud privaatvõti — see ei lähe üles.",
		jwtMinted: "Demo RSA võti loodi selles brauseris",
		jwtSigned: "JWT allkirjastatud RS256-ga",
		jwtNeedKey: "Loo või kleebi esmalt PKCS#8 privaatvõti",
		jwtSignFail: "Allkiri ebaõnnestus — kontrolli PEM-i",
		jwtCopied: "JWT kopeeritud",
		jwtKeyFail: "Võtit ei õnnestunud luua",
		permKicker: "Õiguste kaart",
		permTitle: "Väikseim token, mis ikka töötab",
		permLead: "GITHUB_TOKEN skoobid määratakse YAML-is. Alusta tühjast, tõsta skoopi ainult siis, kui samm seda vajab, ja kinnita kaart nii töövool kui jobil.",
		permName: "Töövoo nimi",
		permTrigger: "Trigger",
		permJob: "Job id",
		permScope: "Skoop",
		permNone: "Puudub",
		permRead: "Lugemine",
		permWrite: "Kirjutamine",
		permUnlock: "Mida avab",
		permYaml: "Genereeritud töövoog",
		permAttest: "Auditeeri see YAML",
		permCopyBtn: "Kopeeri",
		permSent: "Töövoog saadeti audiitorile",
		permCopied: "YAML kopeeritud",
		auraKicker: "Moodul 02 · Aura",
		auraTitle: "Heli, joonistatud.",
		auraPlay: "Mängi",
		auraPause: "Paus",
		auraDemo: "Demo",
		auraOpen: "Ava lugu",
		auraSteelTap: "Steel tap",
		auraRecord: "Salvesta MP4",
		auraStopRec: "Peata",
		auraMute: "Vaigista",
		auraUnmute: "Heli sisse",
		auraFs: "Täisekraan",
		auraSens: "Tundlikkus",
		auraVol: "Helitugevus",
		auraInc: "Buffer inc",
		auraArms: "Armid",
		auraKeys: "Tühik mängi · F täisekraan · M vaigista · 1–4 režiimid · lohista fail",
		consoleKicker: "Reaalajas pult",
		consoleTitle: "ASIO veebi, sessioonist lahkumata.",
		consoleLead: "STEEL jooksutatab AudioWorklet tuuma selles lehes. ASIO4ALL 2.22 hoiab Windowsi seadet; PipeWire/JACK hoiab Linuxit. MIDI FL Studio 21+ või Live 12-st jõuab siia. Brauser ei laadi kernel-draiverit — ta kannab ahelat.",
		armKernel: "Relvasta tuum",
		disarm: "Relvasta maha",
		panic: "Panic",
		armHint: "Relvasta, siis mängi A–K või klahve all",
		runningLive: "Käib · pulti sisend elus",
		runningKeys: "Käib · klahvid ja MIDI",
		armOk: "Tuum relvastatud — interaktiivne latentsus",
		armFail: "Audio relvastamine ebaõnnestus"
	},
	en: {
		skip: "Skip to content",
		console: "Console",
		desk: "Desk",
		aura: "Aura",
		pipeline: "Pipeline",
		hosts: "Hosts",
		kernel: "Kernel",
		ready: "ready",
		deskKicker: "Module 03 · Desk",
		deskTitle: "Beat in one slot, voice in the other.",
		deskLead: "Load a hip-hop beat, drop the vocal in the second slot, engage autotune and the master. This page is the web kernel — real ASIO/VST stays on the machine.",
		slotBeat: "Slot A · Beat",
		slotVocal: "Slot B · Vocal",
		loadBeat: "Load beat",
		demoBeat: "Demo beat (90 BPM)",
		loadVocal: "Load vocal",
		recVoice: "Record voice",
		liveMic: "Live mic",
		emptySlot: "Empty",
		playMix: "Play mix",
		stopMix: "Stop",
		autotune: "Autotune",
		amount: "Amount",
		speed: "Speed",
		key: "Key",
		chromatic: "Chromatic",
		minor: "Minor",
		major: "Major",
		master: "Master",
		ceiling: "Ceiling",
		drive: "Drive",
		width: "Width",
		glue: "Glue",
		duck: "Duck",
		analytics: "Analytics",
		peak: "Peak",
		loud: "Loudness",
		crest: "Crest",
		bpm: "BPM",
		detected: "Detected",
		clips: "Clip",
		aiMix: "AI mix",
		aiBusy: "Listening…",
		bounce: "Bounce WAV",
		saveRow: "Save row",
		rows: "Rows",
		rowSaved: "Row saved",
		rowFail: "Could not write the row.",
		noRows: "No rows yet.",
		loadRow: "Load",
		clear: "Clear",
		spaceHint: "Space: play / stop",
		micBlocked: "Microphone is blocked in this view. Load a vocal file or use Record voice.",
		decodeFail: "Could not open that file. Try WAV, MP3 or M4A.",
		needSlots: "Load a beat or vocal — or tap the demo beat.",
		mixOn: "Mix running",
		footer: "ASIO4ALL 2.22 · Win 8/10/11 · FL Studio 21+ · web kernel is not a VST host",
		tuumNote: "ASIO 5.9 is not a public driver. Desktop path is ASIO4ALL 2.22 and vendor ASIO 2.3. FL Studio from the 20.8 MIDI engine (what you named as 17+) through current. VST3 does not run in this page — use the Hosts tab and loopMIDI / PipeASIO.",
		heuristicApplied: "Sharp mix applied (local engine).",
		recDone: "Voice captured",
		recStart: "Recording… tap again to stop",
		audit: "Audit",
		auditKicker: "Module 04 · Attest",
		auditTitle: "GITHUB_TOKEN and JWT, in this browser.",
		auditLead: "Scan a public GitHub repo or paste YAML. We score permissions, pull_request_target, unpinned actions, and App JWTs.",
		ghScan: "Scan GitHub",
		ghSpec: "owner/repo",
		ghBusy: "Reading GitHub…",
		ghEmpty: "No .github/workflows in that repo.",
		ghMiss: "Repo not found or private.",
		ghRate: "GitHub rate limit. Try again in a moment.",
		ghFail: "GitHub request failed.",
		ghFiles: "Workflow files",
		jwtKicker: "GitHub App JWT",
		jwtTitle: "Ten minutes, RS256, Bearer",
		jwtLead: "A GitHub App authenticates as itself with a JWT, then exchanges that JWT for an installation token. The JWT never goes in GITHUB_TOKEN. Keys stay in this tab.",
		jwtMint: "Mint demo key",
		jwtSign: "Sign JWT",
		jwtCopy: "Copy JWT",
		jwtIss: "Client ID (iss)",
		jwtPem: "PKCS#8 PEM",
		jwtSignIn: "Sign in-browser",
		jwtCompact: "Compact serialization",
		jwtBearerNote: "Send as Authorization: Bearer. GitHub rejects Authorization: token for JWTs. Exchange it for an installation token; do not use the JWT as GH_TOKEN.",
		jwtDemoNote: "Demo keys are not registered with GitHub. Use them to inspect the claims. For a real App, paste the private key GitHub issued — it never uploads.",
		jwtMinted: "Demo RSA key minted in this browser",
		jwtSigned: "JWT signed with RS256",
		jwtNeedKey: "Generate or paste a PKCS#8 private key first",
		jwtSignFail: "Sign failed — check the PEM",
		jwtCopied: "JWT copied",
		jwtKeyFail: "Could not generate a key",
		permKicker: "Permission map",
		permTitle: "The smallest token that still ships",
		permLead: "GITHUB_TOKEN scopes are declared in YAML. Start at none, raise a scope only when a step needs it, and pin the map on both the workflow and the job.",
		permName: "Workflow name",
		permTrigger: "Trigger",
		permJob: "Job id",
		permScope: "Scope",
		permNone: "None",
		permRead: "Read",
		permWrite: "Write",
		permUnlock: "What it unlocks",
		permYaml: "Generated workflow",
		permAttest: "Attest this YAML",
		permCopyBtn: "Copy",
		permSent: "Workflow sent to the auditor",
		permCopied: "YAML copied",
		auraKicker: "Module 02 · Aura",
		auraTitle: "Sound, drawn.",
		auraPlay: "Play",
		auraPause: "Pause",
		auraDemo: "Demo",
		auraOpen: "Open track",
		auraSteelTap: "Steel tap",
		auraRecord: "Record MP4",
		auraStopRec: "Stop",
		auraMute: "Mute",
		auraUnmute: "Unmute",
		auraFs: "Fullscreen",
		auraSens: "Sensitivity",
		auraVol: "Volume",
		auraInc: "Buffer inc",
		auraArms: "Arms",
		auraKeys: "Space play · F fullscreen · M mute · 1–4 modes · drop an audio file",
		consoleKicker: "Real-time desk",
		consoleTitle: "ASIO to the web, without leaving the session.",
		consoleLead: "STEEL runs an AudioWorklet kernel in this page. ASIO4ALL 2.22 still owns the Windows device; PipeWire/JACK owns Linux. MIDI from FL Studio 21+ or Live 12 lands here. The browser cannot load a kernel driver — it can carry the pipeline.",
		armKernel: "Arm kernel",
		disarm: "Disarm",
		panic: "Panic",
		armHint: "Arm, then play A–K or the keys below",
		runningLive: "Running · desk input live",
		runningKeys: "Running · keys and MIDI",
		armOk: "Kernel armed — interactive latency",
		armFail: "Could not arm audio"
	}
};
function t$1(lang, key) {
	return STR[lang][key];
}
function asKind(v) {
	return v === "mix" || v === "audit" ? v : null;
}
var createSteelRow = createServerFn({ method: "POST" }).validator((input) => {
	const kind = asKind(input?.kind);
	if (!kind) throw new Error("kind");
	const title = String(input?.title ?? "").trim().slice(0, 80);
	if (!title) throw new Error("title");
	const payloadJson = String(input?.payloadJson ?? "");
	if (payloadJson.length < 2 || payloadJson.length > 4e3) throw new Error("payload");
	JSON.parse(payloadJson);
	return {
		kind,
		title,
		payloadJson
	};
}).handler(createSsrRpc("9efa963c2f182ee6f21584d89c6f81032bc17ddd31d9302ecd577178c726ab1f"));
createServerFn({ method: "POST" }).validator((input) => {
	const kind = asKind(input?.kind);
	if (!kind) throw new Error("kind");
	return { kind };
}).handler(createSsrRpc("3e3d216391e68efe5f092daeb6ee0716cdfaa7d016897e547b3d6dd3df1a9416"));
var ADDON_DEFAULTS = {
	hpf: true,
	eq: true,
	sat: true,
	comp: true,
	limit: true,
	synth: true,
	transient: false
};
var PERSIST_KEY$2 = "steel-desk-v1";
function slicePersist$1(s) {
	return {
		host: s.host,
		os: s.os,
		buffer: s.buffer,
		sampleRate: s.sampleRate,
		kernel: s.kernel,
		addons: s.addons,
		inGain: s.inGain,
		outGain: s.outGain,
		master: s.master,
		hpHz: s.hpHz,
		eqLo: s.eqLo,
		eqMid: s.eqMid,
		eqHi: s.eqHi,
		satAmt: s.satAmt,
		thresh: s.thresh,
		transAmt: s.transAmt,
		webOut: s.webOut,
		lang: s.lang
	};
}
var useSteel = create((set) => ({
	tab: "desk",
	lang: "et",
	armed: false,
	running: false,
	host: "fl",
	os: "win10",
	buffer: 128,
	sampleRate: 48e3,
	kernel: "3.4.0",
	latest: null,
	updating: false,
	addons: ADDON_DEFAULTS,
	inGain: 1,
	outGain: .85,
	master: .8,
	hpHz: 80,
	eqLo: 1,
	eqMid: 1,
	eqHi: 1,
	satAmt: .35,
	thresh: .35,
	transAmt: .4,
	peak: 0,
	rms: 0,
	voices: 0,
	cpu: 0,
	midiIn: null,
	midiOut: null,
	midiPorts: [],
	lastNote: "—",
	lastCc: "—",
	webOut: true,
	inputLive: false,
	error: null,
	setTab: (tab) => set({ tab }),
	patch: (partial) => set(partial)
}));
function hydrateSteel() {
	if (typeof localStorage === "undefined") return;
	try {
		const raw = localStorage.getItem(PERSIST_KEY$2);
		if (!raw) return;
		const saved = JSON.parse(raw);
		const next = {};
		if (saved.host) next.host = saved.host;
		if (saved.os) next.os = saved.os;
		if (saved.buffer) next.buffer = saved.buffer;
		if (saved.sampleRate) next.sampleRate = saved.sampleRate;
		if (saved.kernel) next.kernel = saved.kernel;
		if (saved.addons) next.addons = {
			...ADDON_DEFAULTS,
			...saved.addons
		};
		if (typeof saved.inGain === "number") next.inGain = saved.inGain;
		if (typeof saved.outGain === "number") next.outGain = saved.outGain;
		if (typeof saved.master === "number") next.master = saved.master;
		if (typeof saved.hpHz === "number") next.hpHz = saved.hpHz;
		if (typeof saved.eqLo === "number") next.eqLo = saved.eqLo;
		if (typeof saved.eqMid === "number") next.eqMid = saved.eqMid;
		if (typeof saved.eqHi === "number") next.eqHi = saved.eqHi;
		if (typeof saved.satAmt === "number") next.satAmt = saved.satAmt;
		if (typeof saved.thresh === "number") next.thresh = saved.thresh;
		if (typeof saved.transAmt === "number") next.transAmt = saved.transAmt;
		if (typeof saved.webOut === "boolean") next.webOut = saved.webOut;
		if (saved.lang === "et" || saved.lang === "en") next.lang = saved.lang;
		useSteel.getState().patch(next);
	} catch {}
}
function watchSteelPersist() {
	return useSteel.subscribe((s, prev) => {
		if (s.peak !== prev.peak || s.rms !== prev.rms || s.voices !== prev.voices || s.cpu !== prev.cpu || s.lastNote !== prev.lastNote || s.lastCc !== prev.lastCc || s.armed !== prev.armed || s.running !== prev.running || s.tab !== prev.tab) {
			if (s.host === prev.host && s.os === prev.os && s.buffer === prev.buffer && s.sampleRate === prev.sampleRate && s.kernel === prev.kernel && s.addons === prev.addons && s.inGain === prev.inGain && s.outGain === prev.outGain && s.master === prev.master && s.hpHz === prev.hpHz && s.eqLo === prev.eqLo && s.eqMid === prev.eqMid && s.eqHi === prev.eqHi && s.satAmt === prev.satAmt && s.thresh === prev.thresh && s.transAmt === prev.transAmt && s.webOut === prev.webOut && s.lang === prev.lang) return;
		}
		try {
			localStorage.setItem(PERSIST_KEY$2, JSON.stringify(slicePersist$1(s)));
		} catch {}
	});
}
var PRESETS = [
	"actions/cache",
	"actions/checkout",
	"actions/starter-workflows"
];
function AuditWorkspace() {
	const yaml = useAudit((s) => s.yaml);
	const sampleId = useAudit((s) => s.sampleId);
	const report = useAudit((s) => s.report);
	const setYaml = useAudit((s) => s.setYaml);
	const run = useAudit((s) => s.run);
	const loadSample = useAudit((s) => s.loadSample);
	const lang = useSteel((s) => s.lang);
	const et = lang === "et";
	const [spec, setSpec] = (0, import_react.useState)("actions/cache");
	const [scan, setScan] = (0, import_react.useState)(null);
	const [activePath, setActivePath] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [grades, setGrades] = (0, import_react.useState)({});
	async function saveReport() {
		try {
			await createSteelRow({ data: {
				kind: "audit",
				title: `audit ${report.grade} ${report.score}`,
				payloadJson: JSON.stringify({
					grade: report.grade,
					score: report.score,
					name: report.name.slice(0, 80),
					findingCount: report.findings.length,
					rules: report.findings.map((f) => f.rule).slice(0, 24)
				})
			} });
			toast.success(t$1(lang, "rowSaved"));
		} catch {
			toast.error(t$1(lang, "rowFail"));
		}
	}
	function ghError(err) {
		const msg = err instanceof Error ? err.message : "";
		if (msg.includes("not-found")) return t$1(lang, "ghMiss");
		if (msg.includes("rate")) return t$1(lang, "ghRate");
		if (msg.includes("repo")) return t$1(lang, "ghMiss");
		return t$1(lang, "ghFail");
	}
	async function onScan(nextSpec = spec) {
		setBusy(true);
		try {
			const result = await scanGithubRepo({ data: { spec: nextSpec } });
			setScan(result);
			setSpec(`${result.owner}/${result.repo}`);
			setGrades({});
			if (result.files.length === 0) {
				toast.message(t$1(lang, "ghEmpty"));
				return;
			}
			const pick = result.files.find((f) => f.path.includes("pr-opened")) ?? result.files.find((f) => f.path.endsWith(".yml") || f.path.endsWith(".yaml")) ?? result.files[0];
			await loadRemote(result.owner, result.repo, pick.path);
			gradeListed(result);
		} catch (err) {
			setScan(null);
			toast.error(ghError(err));
		} finally {
			setBusy(false);
		}
	}
	async function gradeListed(result) {
		const slice = result.files.slice(0, 8);
		const rows = await Promise.all(slice.map(async (f) => {
			try {
				const file = await fetchGithubWorkflow({ data: {
					owner: result.owner,
					repo: result.repo,
					path: f.path
				} });
				return [f.path, auditWorkflow(file.yaml).grade];
			} catch {
				return [f.path, "–"];
			}
		}));
		setGrades(Object.fromEntries(rows));
	}
	async function loadRemote(owner, repo, path) {
		setBusy(true);
		try {
			const file = await fetchGithubWorkflow({ data: {
				owner,
				repo,
				path
			} });
			setYaml(file.yaml);
			setActivePath(path);
			useAudit.getState().run();
			toast.success(file.name);
		} catch (err) {
			toast.error(ghError(err));
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-8 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.05fr)] lg:gap-10",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "min-w-0",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-4 rounded-[var(--radius-md)] border border-rule bg-raised/50 p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-2xs tracking-[0.18em] text-muted uppercase",
							children: t$1(lang, "ghScan")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							className: "mt-3 flex flex-col gap-2 sm:flex-row",
							onSubmit: (e) => {
								e.preventDefault();
								onScan();
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "sr-only",
									htmlFor: "gh-spec",
									children: t$1(lang, "ghSpec")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									id: "gh-spec",
									value: spec,
									onChange: (e) => setSpec(e.target.value),
									placeholder: t$1(lang, "ghSpec"),
									autoComplete: "off",
									className: "min-h-11 min-w-0 flex-1 rounded-[var(--radius-sm)] border border-rule bg-paper px-3 font-mono text-sm text-ink"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "submit",
									variant: "live",
									disabled: busy,
									children: busy ? t$1(lang, "ghBusy") : t$1(lang, "ghScan")
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 flex flex-wrap gap-2",
							children: PRESETS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									setSpec(p);
									onScan(p);
								},
								className: "min-h-11 rounded-[var(--radius-sm)] border border-rule px-3 font-mono text-2xs text-muted hover:text-ink",
								children: p
							}, p))
						}),
						scan ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-mono text-2xs tracking-wider text-muted uppercase",
								children: [
									t$1(lang, "ghFiles"),
									" · ",
									scan.owner,
									"/",
									scan.repo
								]
							}), scan.files.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-faint",
								children: t$1(lang, "ghEmpty")
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-2 max-h-48 overflow-y-auto divide-y divide-rule",
								children: scan.files.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => void loadRemote(scan.owner, scan.repo, f.path),
									className: "flex min-h-11 w-full items-center justify-between gap-2 px-1 text-left text-sm " + (activePath === f.path ? "text-ink" : "text-muted hover:text-ink"),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "truncate font-mono text-2xs",
										children: f.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "shrink-0 font-mono text-2xs tabular-nums text-faint",
										children: grades[f.path] ?? (activePath === f.path ? et ? "avatud" : "open" : "")
									})]
								}) }, f.path))
							})]
						}) : null
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 flex items-end justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-2xs tracking-[0.18em] text-muted uppercase",
						children: et ? "Töövoo YAML" : "Workflow YAML"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-1 text-2xl",
						children: et ? "Kleebi, siis attest" : "Paste, then attest"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						onClick: run,
						size: "sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {
							className: "size-3.5",
							strokeWidth: 2
						}), et ? "Auditeeri" : "Run audit"]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mb-3 flex flex-wrap gap-2",
					children: SAMPLE_WORKFLOWS.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => {
							setActivePath(null);
							loadSample(s.id);
						},
						className: "shrink-0 rounded-[var(--radius-md)] border px-3 py-2 text-left transition-colors duration-[var(--motion-quick)] " + (sampleId === s.id && !activePath ? "border-ink bg-ink text-paper" : "border-rule bg-transparent text-ink hover:bg-ink/[0.04]"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-sm font-medium",
							children: s.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-0.5 block max-w-52 text-2xs leading-snug " + (sampleId === s.id && !activePath ? "text-paper/70" : "text-muted"),
							children: s.blurb
						})]
					}, s.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "sr-only",
					htmlFor: "workflow-yaml",
					children: "GitHub Actions workflow YAML"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					id: "workflow-yaml",
					value: yaml,
					onChange: (e) => {
						setActivePath(null);
						setYaml(e.target.value);
					},
					onKeyDown: (e) => {
						if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) {
							e.preventDefault();
							run();
						}
					},
					spellCheck: false,
					className: "min-h-72 w-full resize-y rounded-[var(--radius-md)] border border-rule bg-raised p-4 font-mono text-[0.8rem] leading-relaxed text-ink"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-xs text-muted",
					children: et ? "Ctrl/⌘ + Enter käivitab. YAML ei lahku sellest brauserist — GitHubi skann loeb ainult avalikke faile." : "Ctrl/⌘ + Enter runs the audit. Pasted YAML stays here. GitHub scan reads public files only."
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "min-w-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-start justify-between gap-4 border-b border-rule pb-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-2xs tracking-[0.18em] text-muted uppercase",
							children: "Verdict"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-1 text-2xl sm:text-3xl",
							children: report.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 max-w-prose text-sm leading-relaxed text-muted",
							children: report.summary
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
							className: "mt-4 flex flex-wrap gap-x-5 gap-y-1 font-mono text-2xs tracking-wide text-faint uppercase",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "inline",
									children: "Jobs "
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "inline text-ink tabular-nums",
									children: report.stats.jobs
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "inline",
									children: "Steps "
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "inline text-ink tabular-nums",
									children: report.stats.steps
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "inline",
									children: "On "
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "inline text-ink",
									children: report.stats.triggers.join(", ")
								})] })
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScoreMark, {
					grade: report.grade,
					score: report.score
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-4 flex flex-wrap items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-mono text-2xs tracking-[0.18em] text-muted uppercase",
						children: [report.findings.length, " findings · export"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "secondary",
							size: "sm",
							onClick: () => void saveReport(),
							children: t$1(lang, "saveRow")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportMenu, { report })]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FindingsPanel, { findings: report.findings })]
			})]
		})]
	});
}
var JWT_CLAIMS = [
	{
		claim: "iat",
		name: {
			et: "Väljastatud",
			en: "Issued at"
		},
		detail: {
			et: "Unix-aeg, millal JWT loodi. GitHub soovitab 60 sekundit minevikku kella triivi jaoks. Hoia host NTP-ga sünkroonis.",
			en: "Unix time the JWT was created. GitHub recommends 60 seconds in the past to absorb clock drift. Keep the host NTP-synced."
		}
	},
	{
		claim: "exp",
		name: {
			et: "Aegub",
			en: "Expires"
		},
		detail: {
			et: "Unix-aeg, pärast mida JWT ei saa installation-tokenit. Kuni 10 minutit pärast iat.",
			en: "Unix time after which the JWT cannot mint an installation token. Must be no more than 10 minutes after iat."
		}
	},
	{
		claim: "iss",
		name: {
			et: "Väljastaja",
			en: "Issuer"
		},
		detail: {
			et: "GitHub App client ID (eelistatud) või numbriline app ID. Selle järgi valitakse allkirja kontrolliv avalik võti.",
			en: "The GitHub App client ID (preferred) or numeric app ID. Used to pick the public key that verifies the signature."
		}
	},
	{
		claim: "alg",
		name: {
			et: "Algoritm",
			en: "Algorithm"
		},
		detail: {
			et: "Peab olema RS256. HMAC algoritmid lükatakse tagasi.",
			en: "Must be RS256. HMAC algorithms are rejected."
		}
	}
];
var SNIPPETS = {
	ruby: `require "openssl"
require "jwt"

private_pem = File.read("YOUR_PATH_TO_PEM")
private_key = OpenSSL::PKey::RSA.new(private_pem)

payload = {
  iat: Time.now.to_i - 60,
  exp: Time.now.to_i + (10 * 60),
  iss: "YOUR_CLIENT_ID"
}

jwt = JWT.encode(payload, private_key, "RS256")
puts jwt`,
	python: `#!/usr/bin/env python3
import sys, time, jwt

pem = sys.argv[1]
client_id = sys.argv[2]
signing_key = open(pem, "rb").read()

payload = {
    "iat": int(time.time()) - 60,
    "exp": int(time.time()) + 600,
    "iss": client_id,
}
print("JWT:", jwt.encode(payload, signing_key, algorithm="RS256"))`,
	bash: `#!/usr/bin/env bash
client_id=$1
pem=$(cat "$2")
now=$(date +%s)
iat=$((now - 60))
exp=$((now + 600))
b64enc() { openssl base64 | tr -d '=' | tr '/+' '_-' | tr -d '\\n'; }
header=$(printf '%s' '{"typ":"JWT","alg":"RS256"}' | b64enc)
payload=$(printf '%s' "{\\"iat\\":$iat,\\"exp\\":$exp,\\"iss\\":\\"$client_id\\"}" | b64enc)
header_payload="$header.$payload"
signature=$(openssl dgst -sha256 -sign <(printf '%s' "$pem") <(printf '%s' "$header_payload") | b64enc)
printf 'JWT: %s\\n' "$header_payload.$signature"`,
	powershell: `$client_id = "YOUR_CLIENT_ID"
$private_key_path = "YOUR_PATH_TO_PEM"
$header = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes((ConvertTo-Json @{alg="RS256";typ="JWT"}))).TrimEnd("=").Replace("+","-").Replace("/","_")
$payload = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes((ConvertTo-Json @{
  iat = [DateTimeOffset]::UtcNow.AddSeconds(-60).ToUnixTimeSeconds()
  exp = [DateTimeOffset]::UtcNow.AddMinutes(10).ToUnixTimeSeconds()
  iss = $client_id
}))).TrimEnd("=").Replace("+","-").Replace("/","_")
$rsa = [Security.Cryptography.RSA]::Create()
$rsa.ImportFromPem((Get-Content $private_key_path -Raw))
$signature = [Convert]::ToBase64String($rsa.SignData([Text.Encoding]::UTF8.GetBytes("$header.$payload"), "SHA256", [Security.Cryptography.RSASignaturePadding]::Pkcs1)).TrimEnd("=").Replace("+","-").Replace("/","_")
Write-Host "$header.$payload.$signature"`,
	curl: `curl --request GET \\
  --url "https://api.github.com/app" \\
  --header "Accept: application/vnd.github+json" \\
  --header "Authorization: Bearer YOUR_JWT" \\
  --header "X-GitHub-Api-Version: 2026-03-10"`,
	action: ` - name: Generate a token
  id: generate-token
  uses: actions/create-github-app-token@v3
  with:
    client-id: \${{ vars.APP_CLIENT_ID }}
    private-key: \${{ secrets.APP_PRIVATE_KEY }}

- name: Use the token
  env:
    GH_TOKEN: \${{ steps.generate-token.outputs.token }}
  run: gh api octocat`
};
async function mintDemoKey() {
	const { privateKey } = await generateKeyPair("RS256", {
		modulusLength: 2048,
		extractable: true
	});
	return exportPKCS8(privateKey);
}
async function mintGithubAppJwt(opts) {
	const key = await importPKCS8(opts.pkcs8, "RS256");
	const now = Math.floor(Date.now() / 1e3);
	const iat = now - 60;
	const exp = now + 600;
	return {
		jwt: await new SignJWT({}).setProtectedHeader({
			alg: "RS256",
			typ: "JWT"
		}).setIssuedAt(iat).setExpirationTime(exp).setIssuer(opts.clientId).sign(key),
		iat,
		exp
	};
}
function splitJwt(token) {
	const parts = token.split(".");
	if (parts.length !== 3) return null;
	const decode = (part) => {
		const padded = part.replace(/-/g, "+").replace(/_/g, "/") + "===".slice((part.length + 3) % 4);
		try {
			return JSON.parse(atob(padded));
		} catch {
			return part;
		}
	};
	return {
		header: decode(parts[0]),
		payload: decode(parts[1]),
		signature: parts[2]
	};
}
function JwtLab() {
	const uiLang = useSteel((s) => s.lang);
	const [clientId, setClientId] = (0, import_react.useState)("Iv1.attest-demo");
	const [pem, setPem] = (0, import_react.useState)("");
	const [token, setToken] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [snip, setSnip] = (0, import_react.useState)("python");
	const decoded = token ? splitJwt(token) : null;
	async function generateKey() {
		setBusy(true);
		try {
			const next = await mintDemoKey();
			setPem(next);
			toast.success(t$1(uiLang, "jwtMinted"));
		} catch (err) {
			toast.error(err instanceof Error ? err.message : t$1(uiLang, "jwtKeyFail"));
		} finally {
			setBusy(false);
		}
	}
	async function sign() {
		if (!pem.trim()) {
			toast.error(t$1(uiLang, "jwtNeedKey"));
			return;
		}
		setBusy(true);
		try {
			const out = await mintGithubAppJwt({
				clientId: clientId.trim() || "Iv1.attest-demo",
				pkcs8: pem
			});
			setToken(out.jwt);
			toast.success(t$1(uiLang, "jwtSigned"));
		} catch (err) {
			toast.error(err instanceof Error ? err.message : t$1(uiLang, "jwtSignFail"));
		} finally {
			setBusy(false);
		}
	}
	async function copyToken() {
		if (!token) return;
		await navigator.clipboard.writeText(token);
		toast.success(t$1(uiLang, "jwtCopied"));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-10 lg:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "min-w-0",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-2xs tracking-[0.18em] text-muted uppercase",
					children: t$1(uiLang, "jwtKicker")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-1 text-2xl sm:text-3xl",
					children: t$1(uiLang, "jwtTitle")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 max-w-prose text-muted",
					children: t$1(uiLang, "jwtLead")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
					className: "mt-6 divide-y divide-rule border-y border-rule",
					children: JWT_CLAIMS.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-[4.5rem_1fr] gap-4 py-3 sm:grid-cols-[6rem_1fr]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "font-mono text-sm text-stamp",
							children: row.claim
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium",
							children: row.name[uiLang]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: row.detail[uiLang]
						})] })]
					}, row.claim))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "nav-scroll mt-6 flex flex-nowrap gap-2 overflow-x-auto",
					children: Object.keys(SNIPPETS).map((key) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setSnip(key),
						className: "min-h-11 shrink-0 rounded-[var(--radius-sm)] border px-3 py-1.5 font-mono text-2xs uppercase tracking-wide " + (snip === key ? "border-ink bg-ink text-paper" : "border-rule text-muted hover:text-ink"),
						children: key
					}, key))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
					className: "mt-3 overflow-x-auto rounded-[var(--radius-lg)] border border-rule bg-raised/70 p-4 font-mono text-xs leading-relaxed",
					children: SNIPPETS[snip]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "min-w-0",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-2xs tracking-[0.18em] text-muted uppercase",
					children: t$1(uiLang, "jwtSignIn")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "mt-4 block",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-mono text-2xs tracking-wider text-muted uppercase",
						children: t$1(uiLang, "jwtIss")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: clientId,
						onChange: (e) => setClientId(e.target.value),
						className: "mt-1 h-11 w-full rounded-[var(--radius-md)] border border-rule bg-paper px-3 font-mono text-sm outline-none focus:border-ink/40 focus:ring-2 focus:ring-ink/15"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "mt-3 block",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-mono text-2xs tracking-wider text-muted uppercase",
						children: t$1(uiLang, "jwtPem")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						value: pem,
						onChange: (e) => setPem(e.target.value),
						spellCheck: false,
						placeholder: "-----BEGIN PRIVATE KEY-----",
						className: "mt-1 h-36 w-full resize-y rounded-[var(--radius-md)] border border-rule bg-raised/60 p-3 font-mono text-2xs outline-none focus:border-ink/40 focus:ring-2 focus:ring-ink/15"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex flex-wrap gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "secondary",
							disabled: busy,
							onClick: () => void generateKey(),
							children: t$1(uiLang, "jwtMint")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							disabled: busy,
							onClick: () => void sign(),
							children: t$1(uiLang, "jwtSign")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "ghost",
							disabled: !token,
							onClick: () => void copyToken(),
							children: t$1(uiLang, "jwtCopy")
						})
					]
				}),
				token ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-2xs tracking-wider text-muted uppercase",
							children: t$1(uiLang, "jwtCompact")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 break-all font-mono text-2xs leading-relaxed text-ink",
							children: token
						}),
						decoded ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
							className: "mt-4 overflow-x-auto rounded-[var(--radius-md)] border border-rule bg-paper p-3 font-mono text-2xs",
							children: JSON.stringify({
								header: decoded.header,
								payload: decoded.payload
							}, null, 2)
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm text-muted",
							children: t$1(uiLang, "jwtBearerNote")
						})
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-5 text-sm text-muted",
					children: t$1(uiLang, "jwtDemoNote")
				})
			]
		})]
	});
}
var SCOPE_CATALOG = [
	{
		id: "actions",
		label: "actions",
		read: "List and download workflow artifacts and logs.",
		write: "Cancel workflows, delete artifacts."
	},
	{
		id: "attestations",
		label: "attestations",
		read: "Read artifact attestations.",
		write: "Create artifact attestations."
	},
	{
		id: "checks",
		label: "checks",
		read: "Read check runs and suites.",
		write: "Create or update checks."
	},
	{
		id: "contents",
		label: "contents",
		read: "Checkout the repo, read blobs and commits.",
		write: "Push commits, create tags and releases."
	},
	{
		id: "deployments",
		label: "deployments",
		read: "Read deployment statuses.",
		write: "Create deployments."
	},
	{
		id: "discussions",
		label: "discussions",
		read: "Read discussions.",
		write: "Create or edit discussions."
	},
	{
		id: "id-token",
		label: "id-token",
		read: "Not used — id-token is write-only.",
		write: "Mint an OIDC token for cloud federated login."
	},
	{
		id: "issues",
		label: "issues",
		read: "Read issues and comments.",
		write: "Open, close, and comment on issues."
	},
	{
		id: "models",
		label: "models",
		read: "Call GitHub Models.",
		write: "Not applicable."
	},
	{
		id: "packages",
		label: "packages",
		read: "Download packages.",
		write: "Publish packages."
	},
	{
		id: "pages",
		label: "pages",
		read: "Read Pages status.",
		write: "Request a Pages build."
	},
	{
		id: "pull-requests",
		label: "pull-requests",
		read: "Read PRs and reviews.",
		write: "Comment, review, merge, request reviewers."
	},
	{
		id: "repository-projects",
		label: "repository-projects",
		read: "Read classic projects.",
		write: "Create and edit classic projects."
	},
	{
		id: "security-events",
		label: "security-events",
		read: "Read code scanning and Dependabot alerts.",
		write: "Upload SARIF, dismiss alerts."
	},
	{
		id: "statuses",
		label: "statuses",
		read: "Read commit statuses.",
		write: "Set commit statuses."
	}
];
function permissionsToYaml(name, trigger, jobId, map) {
	const entries = Object.entries(map).filter(([, level]) => level && level !== "none");
	return `name: ${name}
on: ${trigger}

permissions:
${entries.map(([scope, level]) => `  ${scope}: ${level}`).join("\n") || "  contents: read"}

jobs:
  ${jobId}:
    runs-on: ubuntu-latest
    permissions:
${entries.map(([scope, level]) => `      ${scope}: ${level}`).join("\n") || "      contents: read"}
    steps:
      - uses: actions/checkout@11bd71901bbe5b1630ceea73d27597364c9af683 # v4.2.2
`;
}
var INITIAL = {
	contents: "read",
	issues: "write"
};
function PermissionBuilder() {
	const lang = useSteel((s) => s.lang);
	const [map, setMap] = (0, import_react.useState)(INITIAL);
	const [name, setName] = (0, import_react.useState)("Open new issue");
	const [trigger, setTrigger] = (0, import_react.useState)("workflow_dispatch");
	const [jobId, setJobId] = (0, import_react.useState)("open-issue");
	const loadCustom = useAudit((s) => s.setYaml);
	const run = useAudit((s) => s.run);
	const setTab = useAudit((s) => s.setTab);
	const yaml = (0, import_react.useMemo)(() => permissionsToYaml(name, trigger, jobId, map), [
		name,
		trigger,
		jobId,
		map
	]);
	function setLevel(scope, level) {
		setMap((prev) => ({
			...prev,
			[scope]: level
		}));
	}
	function attest() {
		loadCustom(yaml);
		run();
		setTab("audit");
		toast.success(t$1(lang, "permSent"));
	}
	async function copy() {
		await navigator.clipboard.writeText(yaml);
		toast.success(t$1(lang, "permCopied"));
	}
	const levelLabel = {
		none: t$1(lang, "permNone"),
		read: t$1(lang, "permRead"),
		write: t$1(lang, "permWrite")
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-8 lg:grid-cols-[minmax(0,1.15fr)_minmax(0,0.9fr)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "min-w-0",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-2xs tracking-[0.18em] text-muted uppercase",
					children: t$1(lang, "permKicker")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-1 text-2xl sm:text-3xl",
					children: t$1(lang, "permTitle")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 max-w-prose text-muted",
					children: t$1(lang, "permLead")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 grid gap-3 sm:grid-cols-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: t$1(lang, "permName"),
							value: name,
							onChange: setName
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: t$1(lang, "permTrigger"),
							value: trigger,
							onChange: setTrigger
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: t$1(lang, "permJob"),
							value: jobId,
							onChange: setJobId
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6 overflow-x-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full min-w-[34rem] border-collapse text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-b border-rule text-left font-mono text-2xs tracking-wider text-muted uppercase",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2 pr-3 font-medium",
									children: t$1(lang, "permScope")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2 pr-3 font-medium",
									children: t$1(lang, "permNone")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2 pr-3 font-medium",
									children: t$1(lang, "permRead")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2 pr-3 font-medium",
									children: t$1(lang, "permWrite")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2 font-medium",
									children: t$1(lang, "permUnlock")
								})
							]
						}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: SCOPE_CATALOG.map((scope) => {
							const level = map[scope.id] ?? "none";
							const hint = level === "write" ? scope.write : scope.read;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-b border-rule/70",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-3 pr-3 text-left font-mono text-sm font-medium",
										children: scope.label
									}),
									[
										"none",
										"read",
										"write"
									].map((opt) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-3 pr-3",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											"aria-pressed": level === opt,
											onClick: () => setLevel(scope.id, opt),
											className: cn("min-h-11 rounded-[var(--radius-sm)] border px-2.5 py-1 font-mono text-2xs uppercase tracking-wide transition-colors duration-[var(--motion-quick)]", level === opt ? "border-ink bg-ink text-paper" : "border-rule text-muted hover:border-ink/40 hover:text-ink"),
											children: levelLabel[opt]
										})
									}, opt)),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-3 text-muted",
										children: hint
									})
								]
							}, scope.id);
						}) })]
					})
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "min-w-0 lg:sticky lg:top-24 lg:self-start",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-2xs tracking-[0.18em] text-muted uppercase",
					children: t$1(lang, "permYaml")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
					className: "mt-3 overflow-x-auto rounded-[var(--radius-lg)] border border-rule bg-raised/70 p-4 font-mono text-xs leading-relaxed text-ink",
					children: yaml
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						onClick: attest,
						children: t$1(lang, "permAttest")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "secondary",
						onClick: () => void copy(),
						children: t$1(lang, "permCopyBtn")
					})]
				})
			]
		})]
	});
}
function Field({ label, value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-mono text-2xs tracking-wider text-muted uppercase",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			value,
			onChange: (e) => onChange(e.target.value),
			className: "mt-1 h-11 w-full rounded-[var(--radius-md)] border border-rule bg-paper px-3 text-sm text-ink outline-none focus:border-ink/40 focus:ring-2 focus:ring-ink/15"
		})]
	});
}
var INNER = [
	{
		id: "audit",
		et: "Töövoog",
		en: "Workflow"
	},
	{
		id: "jwt",
		et: "JWT",
		en: "JWT"
	},
	{
		id: "permissions",
		et: "Õigused",
		en: "Permissions"
	}
];
function SteelAudit() {
	const lang = useSteel((s) => s.lang);
	const tab = useAudit((s) => s.tab);
	const setTab = useAudit((s) => s.setTab);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-mono text-2xs tracking-[0.2em] text-steel uppercase",
			children: t$1(lang, "auditKicker")
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mt-2 text-3xl sm:text-4xl",
			children: t$1(lang, "auditTitle")
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 max-w-prose text-sm leading-relaxed text-muted",
			children: t$1(lang, "auditLead")
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "nav-scroll mt-5 flex flex-nowrap gap-1 overflow-x-auto",
			children: INNER.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setTab(item.id),
				className: cn("min-h-11 shrink-0 rounded-[var(--radius-sm)] px-3 text-sm", tab === item.id ? "bg-ink text-paper" : "text-muted hover:bg-ink/[0.06] hover:text-ink"),
				children: lang === "et" ? item.et : item.en
			}, item.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-8",
			children: [
				tab === "audit" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuditWorkspace, {}) : null,
				tab === "jwt" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(JwtLab, {}) : null,
				tab === "permissions" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PermissionBuilder, {}) : null
			]
		})
	] });
}
var ET = {
	skip: "Liigu sisu juurde",
	studio: "Studio",
	desk: "Pult",
	vocals: "Vokaal",
	visuals: "Pilt",
	matrix: "Maatriks",
	monitor: "Monitor",
	play: "Mängi",
	stop: "Peata",
	rec: "Salvesta",
	arm: "Käivita mootor",
	armed: "Mootor sees",
	bounce: "Bounce WAV",
	master: "Master",
	bpm: "BPM",
	swing: "Swing",
	drive: "Drive",
	glue: "Glue",
	ceiling: "Lagi",
	width: "Laius",
	center: "Keskne lukk",
	mute: "Mute",
	solo: "Solo",
	send: "Send",
	pan: "Pan",
	level: "Tase",
	kick: "Kick",
	bass: "Bass",
	hat: "Hats",
	perc: "Perc",
	lead: "Lead",
	vocal: "Vokaal",
	genre: "Žanr",
	hardstyle: "Hardstyle",
	rawstyle: "Rawstyle",
	techno: "Hard Techno",
	rap: "Rap",
	trap: "Trap",
	loadVocal: "Laadi vokaal",
	loadBeat: "Laadi biit",
	liveMic: "Mikrofon",
	recVoice: "Salvesta hääl",
	quantize: "Kvanti",
	restore: "Taasta",
	harmony: "Harmoonia",
	choir: "Koor",
	adlib: "Ad-lib",
	generate: "Genereeri",
	hook: "Hook",
	lyrics: "Sõnad",
	detectLyrics: "Tuvasta sõnad",
	fx: "FX ahel",
	dry: "Kuiv",
	hardDelay: "Hard delay",
	clubVerb: "Klubi reverb",
	radio: "Raadio fade",
	trapSpace: "Trap space",
	voiceBank: "Häälepank",
	leadVoice: "Lead",
	female: "Harmoonia",
	langVocal: "Keele foneetika",
	micTitle: "Mikrofoni profiil",
	micNone: "Mikrofoni pole veel profiilitud.",
	restoreOn: "Hardware-aware taastus",
	karestik: "Kärestik",
	mirror: "Peegeldus",
	buffer: "Puhver",
	latency: "Latentsus",
	velocity: "Kiirus V",
	signal: "Signaal S",
	need: "Aeg T",
	host: "Host",
	standalone: "Iseseisev",
	fl: "FL Studio",
	ableton: "Ableton Live",
	logic: "Logic Pro",
	translate: "Tõlge",
	phone: "Telefon",
	jbl: "JBL",
	festival: "Festival",
	localBridge: "Kohalik arvutus",
	localBridgeNote: "Web Audio + lõuend kasutab selle seadme GPU/CPU. ASIO4ALL jääb lauaarvuti kaaslaseks.",
	visualStyle: "Stiil",
	auto: "Auto",
	rings: "Rõngad",
	tunnel: "Tunnel",
	scope: "Ostsilloskoop",
	bars: "Tulp",
	prompt: "Visuaali juhis",
	promptHint: "50–70 sõna. Rütm tuleb helilt; sina suunad valguse, ruumi, materjali.",
	still: "Genereeri kaader",
	recordVis: "Salvesta pilt",
	radar: "Stuudio radar",
	radarGo: "Skaala Steelile",
	keys: "Z–M live lead · tühik mängi",
	emptyVocal: "Tühi pesa",
	recStart: "Salvestan… vajuta uuesti",
	recDone: "Hääl salvestatud",
	decodeFail: "Faili ei õnnestunud avada.",
	needArm: "Käivita mootor esimese puudutusega.",
	processing: "Töötlen",
	kernel: "Tuum",
	crew: "Meeskond",
	audit: "Audit",
	crewKicker: "STEEL · meeskond",
	crewTitle: "Seitse vahti, üks signaal.",
	crewLead: "Nõrk masin lükkab töö veebi. Tugev masin hoiab tuuma. Igal vahil on püsikäsk; vahid tiksuvad kuni leht elab.",
	hostSignal: "Hosti signaal",
	pathKernel: "Tuum",
	pathWeb: "Veeb",
	pathHybrid: "Hübriid",
	standingOrder: "Püsikäsk",
	issueOrder: "Anna käsk",
	crewLog: "Vahtide logi",
	watchOn: "Vahid sees",
	watchOff: "Vahid pausil",
	lastTick: "Viimane",
	dutyIdle: "Ootel",
	dutyWork: "Töös",
	dutyBlocked: "Blokeeritud",
	dutyPaused: "Paus",
	coresLabel: "Tuuma",
	memoryLabel: "Mälu",
	connectionLabel: "Ühendus",
	policyLabel: "Poliitika",
	forcePath: "Sunni tee",
	autoPath: "Auto",
	kernelKicker: "STEEL · tuum",
	kernelLead: "Kohalik AudioWorklet kui signaal kannatab; muidu veebitee suurema puhvriga.",
	banks: "Pank",
	film: "Film",
	theory: "Teooria",
	banksKicker: "STEEL · pank",
	banksTitle: "Kuu konteinerit. Viis pluginat pärast valikut.",
	banksLead: "Mass püsib suletud kuni valid panga. Siis laeb EDGE-CUT, MUD-VOID, PRESENCE-IRON, SAT-PLATE, AIR-WELL. Kuus rec-rada, igaüks eraldi.",
	loadBank: "Ava konteiner",
	sealed: "Suletud",
	loaded: "Sees",
	recLane: "Rec rada",
	plugins: "Pluginad",
	melt: "Sula beatiga",
	tune: "Autotune",
	analogMirror: "Analog-peegel",
	filmKicker: "STEEL · film",
	filmTitle: "Tuhat bini. Huul lukus.",
	filmLead: "Lainevonked joonistuvad reaalajas. Viseme tuleb sõnast ja RMS-ist. Kaamera on sinu. Pakk tuleb zipina menüüst.",
	downloadPack: "Laadi FILM zip",
	downloadXlsx: "Laadi pangad xlsx",
	lips: "Huul",
	filmStyle: "Film",
	cam: "Kaamera",
	recordFilm: "Salvesta klipp",
	theoryKicker: "STEEL · teooria",
	theoryTitle: "Kümme lisa. Lukustatud read.",
	theoryLead: "Kleebi suund või lugu. Dirt/clear. Öörada: TAKT-LOCK, ENERGY-MATCH, STEREO-MX. Rhyme-lock ei kirjuta su seemet ümber.",
	pasteTrack: "Kleebi suund",
	dirtClear: "Dirt / clear",
	extras: "Kümme lisa",
	lockSeed: "Lukusta seeme",
	writeHook: "Hook",
	writeVerse: "Salm",
	fixBars: "Paranda takt",
	hostLookup: "Hosti geo",
	pyramid: "Püramiid",
	plusV: "V+",
	minusV: "V−",
	nullTier: "Null",
	footer: "STEEL STUDIO · tuum / veeb · pangad suletud kuni valikuni · V+ / V−",
	et: "ET",
	en: "EN",
	ru: "RU",
	es: "ES",
	de: "DE",
	nightLane: "Öörada",
	nightLead: "Lead jääb vaikseks. Stack on valjem. See ei ole sinu kloon — sellel masinal ei ole voice-printi. MP3 on stand-in back vox, et saaksid jälgida midagi, mis istub peal, kui sina jääd vaikseks.",
	standin: "Laadi stand-in",
	standinOn: "Stand-in sees",
	variant: "Kümme kätt",
	applyKind: "Rakenda variant",
	quietLead: "Vaikne lead",
	loudStack: "Valjem stack",
	capsTitle: "Kolmas põlvkond",
	capsLead: "Kümme kätt sinu vahemikus. Moodul jäljendab ainult kui sa ise rappid. Stand-in on sildid. Voice-printi ei kirjutata.",
	hearKind: "Puuduta kätt — kuulad oma take'il. Rakenda kirjutab pessa. Rhyme-lock ei kirjuta stereotüüpi.",
	rapFirst: "Rapi või räägi esmalt.",
	takeLive: "Take sees. Kümme kätt avatud.",
	tagsOnly: "Sildid. Jäljendus ootab su take'i.",
	measureTake: "Mõõda take",
	gen3: "GEN 3",
	mimicOn: "Jäljendus sees",
	mimicOff: "Jäljendus kinni",
	f0: "F0",
	range: "Vahemik"
};
var EN = {
	skip: "Skip to content",
	studio: "Studio",
	desk: "Desk",
	vocals: "Vocals",
	visuals: "Visuals",
	matrix: "Matrix",
	monitor: "Monitor",
	play: "Play",
	stop: "Stop",
	rec: "Record",
	arm: "Arm engine",
	armed: "Engine live",
	bounce: "Bounce WAV",
	master: "Master",
	bpm: "BPM",
	swing: "Swing",
	drive: "Drive",
	glue: "Glue",
	ceiling: "Ceiling",
	width: "Width",
	center: "Center lock",
	mute: "Mute",
	solo: "Solo",
	send: "Send",
	pan: "Pan",
	level: "Level",
	kick: "Kick",
	bass: "Bass",
	hat: "Hats",
	perc: "Perc",
	lead: "Lead",
	vocal: "Vocal",
	genre: "Genre",
	hardstyle: "Hardstyle",
	rawstyle: "Rawstyle",
	techno: "Hard Techno",
	rap: "Rap",
	trap: "Trap",
	loadVocal: "Load vocal",
	loadBeat: "Load beat",
	liveMic: "Microphone",
	recVoice: "Record voice",
	quantize: "Quantize",
	restore: "Restore",
	harmony: "Harmony",
	choir: "Choir",
	adlib: "Ad-lib",
	generate: "Generate",
	hook: "Hook",
	lyrics: "Lyrics",
	detectLyrics: "Detect lyrics",
	fx: "FX chain",
	dry: "Dry",
	hardDelay: "Hard delay",
	clubVerb: "Club reverb",
	radio: "Radio fade",
	trapSpace: "Trap space",
	voiceBank: "Voice bank",
	leadVoice: "Lead",
	female: "Harmony",
	langVocal: "Phonetics",
	micTitle: "Mic profile",
	micNone: "No microphone profiled yet.",
	restoreOn: "Hardware-aware restore",
	karestik: "Kärestik",
	mirror: "Mirror",
	buffer: "Buffer",
	latency: "Latency",
	velocity: "Velocity V",
	signal: "Signal S",
	need: "Time T",
	host: "Host",
	standalone: "Standalone",
	fl: "FL Studio",
	ableton: "Ableton Live",
	logic: "Logic Pro",
	translate: "Translation",
	phone: "Phone",
	jbl: "JBL",
	festival: "Festival",
	localBridge: "Local compute",
	localBridgeNote: "Web Audio and canvas use this device. ASIO4ALL stays a desktop companion.",
	visualStyle: "Style",
	auto: "Auto",
	rings: "Rings",
	tunnel: "Tunnel",
	scope: "Scope",
	bars: "Bars",
	prompt: "Visual direction",
	promptHint: "50–70 words. Rhythm comes from the audio; you steer light, space, material.",
	still: "Generate still",
	recordVis: "Record picture",
	radar: "Studio radar",
	radarGo: "Scale for Steel",
	keys: "Z–M live lead · space play",
	emptyVocal: "Empty slot",
	recStart: "Recording… tap again to stop",
	recDone: "Voice captured",
	decodeFail: "Could not open that file.",
	needArm: "Arm the engine with the first tap.",
	processing: "Processing",
	kernel: "Kernel",
	crew: "Crew",
	audit: "Audit",
	crewKicker: "STEEL · crew",
	crewTitle: "Seven watches, one signal.",
	crewLead: "A weak host shifts load onto the web path. A strong host keeps the kernel. Each watch holds a standing order and ticks while the page lives.",
	hostSignal: "Host signal",
	pathKernel: "Kernel",
	pathWeb: "Web",
	pathHybrid: "Hybrid",
	standingOrder: "Standing order",
	issueOrder: "Issue order",
	crewLog: "Watch log",
	watchOn: "Watch on",
	watchOff: "Watch paused",
	lastTick: "Last",
	dutyIdle: "Idle",
	dutyWork: "Working",
	dutyBlocked: "Blocked",
	dutyPaused: "Paused",
	coresLabel: "Cores",
	memoryLabel: "Memory",
	connectionLabel: "Link",
	policyLabel: "Policy",
	forcePath: "Force path",
	autoPath: "Auto",
	kernelKicker: "STEEL · kernel",
	kernelLead: "Local AudioWorklet when the signal holds; otherwise the web path with a larger buffer.",
	banks: "Banks",
	film: "Film",
	theory: "Theory",
	banksKicker: "STEEL · banks",
	banksTitle: "Six containers. Five plugins after the pick.",
	banksLead: "Mass stays sealed until you pick a bank. Then EDGE-CUT, MUD-VOID, PRESENCE-IRON, SAT-PLATE, AIR-WELL load. Six rec lanes, each editable.",
	loadBank: "Open container",
	sealed: "Sealed",
	loaded: "Live",
	recLane: "Rec lane",
	plugins: "Plugins",
	melt: "Melt into beat",
	tune: "Autotune",
	analogMirror: "Analog mirror",
	filmKicker: "STEEL · film",
	filmTitle: "A thousand bins. Lip locked.",
	filmLead: "The wave draws live. Visemes come from the lyric and RMS. The camera is yours. The pack leaves as a zip from the menu.",
	downloadPack: "Download FILM zip",
	downloadXlsx: "Download banks xlsx",
	lips: "Lips",
	filmStyle: "Film",
	cam: "Camera",
	recordFilm: "Record clip",
	theoryKicker: "STEEL · theory",
	theoryTitle: "Ten extras. Locked bars.",
	theoryLead: "Paste a direction or a track. Dirt/clear. Night lane: TAKT-LOCK, ENERGY-MATCH, STEREO-MX. Rhyme-lock will not rewrite your seed.",
	pasteTrack: "Paste direction",
	dirtClear: "Dirt / clear",
	extras: "Ten extras",
	lockSeed: "Lock seed",
	writeHook: "Hook",
	writeVerse: "Verse",
	fixBars: "Fix takt",
	hostLookup: "Host geo",
	pyramid: "Pyramid",
	plusV: "V+",
	minusV: "V−",
	nullTier: "Null",
	footer: "STEEL STUDIO · kernel / web · banks sealed until pick · V+ / V−",
	et: "ET",
	en: "EN",
	ru: "RU",
	es: "ES",
	de: "DE",
	nightLane: "Night lane",
	nightLead: "You whisper the lead. Stack is louder. That is not a clone of you — there is no voice-print on this machine. The MP3 is a stand-in back vox so you can track against something that sits up while you stay quiet.",
	standin: "Load stand-in",
	standinOn: "Stand-in live",
	variant: "Ten kinds",
	applyKind: "Apply kind",
	quietLead: "Quiet lead",
	loudStack: "Loud stack",
	capsTitle: "Third generation",
	capsLead: "Ten kinds on your range. The module mimics only after you rap. The stand-in is tags. No voice-print is written.",
	hearKind: "Tap a kind to hear it on your take. Apply writes the slot. Rhyme-lock keeps diction — no stock reaction.",
	rapFirst: "Rap or speak first.",
	takeLive: "Take live. Ten kinds open.",
	tagsOnly: "Tags only. Mimic waits for your take.",
	measureTake: "Measure take",
	gen3: "GEN 3",
	mimicOn: "Mimic on",
	mimicOff: "Mimic off",
	f0: "F0",
	range: "Range"
};
function t(lang, key) {
	return (lang === "en" ? EN : ET)[key];
}
function channelLabel(lang, id) {
	return t(lang, id);
}
function genreLabel(lang, id) {
	return t(lang, id);
}
var CHANNELS = [
	"kick",
	"bass",
	"hat",
	"perc",
	"lead",
	"vocal"
];
var GENRE_META = {
	hardstyle: {
		bpm: 150,
		label: "Hardstyle",
		drive: .52
	},
	rawstyle: {
		bpm: 160,
		label: "Rawstyle",
		drive: .78
	},
	techno: {
		bpm: 145,
		label: "Hard Techno",
		drive: .4
	},
	rap: {
		bpm: 90,
		label: "Rap",
		drive: .22
	},
	trap: {
		bpm: 140,
		label: "Trap",
		drive: .36
	}
};
function row(on) {
	const out = Array.from({ length: 16 }, () => 0);
	for (const item of on) if (typeof item === "number") out[item] = 1;
	else out[item[0]] = item[1];
	return out;
}
function midi(values) {
	const out = Array.from({ length: 16 }, () => 0);
	for (let i = 0; i < 16; i++) out[i] = values[i % values.length] ?? 0;
	return out;
}
var silent = () => Array.from({ length: 16 }, () => 0);
var PATTERNS = {
	hardstyle: {
		genre: "hardstyle",
		bpm: 150,
		swing: 0,
		steps: {
			kick: row([
				0,
				4,
				8,
				12
			]),
			bass: row([
				[2, .85],
				[6, .85],
				[10, .85],
				[14, .85]
			]),
			hat: row([
				0,
				[1, .35],
				2,
				[3, .3],
				4,
				[5, .35],
				6,
				[7, .3],
				8,
				[9, .4],
				10,
				[11, .3],
				12,
				[13, .35],
				14,
				[15, .45]
			]),
			perc: row([[4, .7], [12, .78]]),
			lead: row([
				[8, .9],
				[9, .7],
				[10, .85],
				[11, .6],
				[12, .95],
				[13, .7],
				[14, .8],
				[15, .55]
			]),
			vocal: silent()
		},
		bassMidi: midi([
			36,
			36,
			36,
			36,
			36,
			36,
			36,
			36,
			39,
			39,
			39,
			39,
			34,
			34,
			36,
			36
		]),
		leadMidi: midi([
			79,
			79,
			81,
			79,
			76,
			76,
			79,
			81,
			84,
			84,
			83,
			81,
			79,
			76,
			79,
			81
		])
	},
	rawstyle: {
		genre: "rawstyle",
		bpm: 160,
		swing: 0,
		steps: {
			kick: row([
				0,
				[3, .55],
				4,
				8,
				[11, .5],
				12
			]),
			bass: row([
				[2, .9],
				[6, .9],
				[10, .9],
				[14, .9]
			]),
			hat: row([
				0,
				2,
				4,
				6,
				8,
				10,
				12,
				14
			]),
			perc: row([
				[4, .8],
				[7, .4],
				[12, .85]
			]),
			lead: row([
				[0, .4],
				[8, 1],
				[9, .8],
				[10, .95],
				[12, 1],
				[14, .7]
			]),
			vocal: silent()
		},
		bassMidi: midi([
			35,
			35,
			35,
			35,
			35,
			35,
			38,
			38,
			31,
			31,
			35,
			35,
			38,
			38,
			35,
			35
		]),
		leadMidi: midi([
			88,
			88,
			86,
			84,
			81,
			81,
			84,
			86,
			91,
			91,
			88,
			86,
			84,
			81,
			84,
			86
		])
	},
	techno: {
		genre: "techno",
		bpm: 145,
		swing: .08,
		steps: {
			kick: row([
				0,
				4,
				8,
				12
			]),
			bass: row([
				0,
				[2, .7],
				4,
				[6, .65],
				8,
				[10, .7],
				12,
				[14, .6]
			]),
			hat: row([
				[2, .7],
				[6, .7],
				[10, .75],
				[14, .7]
			]),
			perc: row([
				[4, .55],
				[6, .35],
				[12, .6],
				[15, .4]
			]),
			lead: row([
				[0, .35],
				[8, .55],
				[12, .4]
			]),
			vocal: silent()
		},
		bassMidi: midi([
			36,
			36,
			36,
			36,
			39,
			39,
			36,
			36,
			34,
			34,
			36,
			36,
			41,
			41,
			36,
			36
		]),
		leadMidi: midi([
			72,
			72,
			75,
			72,
			67,
			67,
			72,
			75,
			79,
			79,
			75,
			72,
			67,
			67,
			72,
			72
		])
	},
	rap: {
		genre: "rap",
		bpm: 90,
		swing: .18,
		steps: {
			kick: row([
				0,
				[7, .7],
				8,
				[10, .55]
			]),
			bass: row([
				0,
				[3, .5],
				8,
				[11, .45]
			]),
			hat: row([
				0,
				[1, .4],
				2,
				[3, .35],
				4,
				[5, .45],
				6,
				[7, .3],
				8,
				[9, .4],
				10,
				[11, .35],
				12,
				[13, .5],
				14,
				[15, .3]
			]),
			perc: row([[4, .85], [12, .9]]),
			lead: row([[14, .4]]),
			vocal: silent()
		},
		bassMidi: midi([
			49,
			49,
			49,
			49,
			49,
			49,
			49,
			49,
			36,
			36,
			41,
			41,
			49,
			49,
			36,
			36
		]),
		leadMidi: midi([
			64,
			64,
			67,
			64,
			60,
			60,
			64,
			67,
			69,
			69,
			67,
			64,
			60,
			60,
			64,
			64
		])
	},
	trap: {
		genre: "trap",
		bpm: 140,
		swing: .06,
		steps: {
			kick: row([0, [10, .85]]),
			bass: row([0, [8, .7]]),
			hat: row([
				0,
				1,
				2,
				3,
				4,
				5,
				6,
				7,
				8,
				9,
				10,
				[11, .7],
				[12, 1],
				[13, .55],
				[14, .85],
				[15, .4]
			]),
			perc: row([
				[4, .8],
				[12, .88],
				[14, .35]
			]),
			lead: row([[8, .45], [12, .35]]),
			vocal: silent()
		},
		bassMidi: midi([
			33,
			33,
			33,
			33,
			33,
			33,
			33,
			33,
			28,
			28,
			28,
			28,
			33,
			33,
			36,
			31
		]),
		leadMidi: midi([
			76,
			76,
			79,
			76,
			72,
			72,
			76,
			79,
			81,
			81,
			79,
			76,
			72,
			72,
			76,
			76
		])
	}
};
function flattenPattern(p) {
	const pattern = /* @__PURE__ */ new Float32Array(96);
	[
		"kick",
		"bass",
		"hat",
		"perc",
		"lead",
		"vocal"
	].forEach((id, t) => {
		for (let s = 0; s < 16; s++) pattern[t * 16 + s] = p.steps[id][s] ?? 0;
	});
	return {
		pattern,
		bassMidi: Float32Array.from(p.bassMidi),
		leadMidi: Float32Array.from(p.leadMidi)
	};
}
function emptyMix() {
	return {
		kick: {
			gain: .92,
			pan: 0,
			mute: false,
			solo: false,
			send: .04
		},
		bass: {
			gain: .8,
			pan: 0,
			mute: false,
			solo: false,
			send: .02
		},
		hat: {
			gain: .42,
			pan: .18,
			mute: false,
			solo: false,
			send: .12
		},
		perc: {
			gain: .48,
			pan: -.22,
			mute: false,
			solo: false,
			send: .1
		},
		lead: {
			gain: .55,
			pan: .08,
			mute: false,
			solo: false,
			send: .24
		},
		vocal: {
			gain: .88,
			pan: 0,
			mute: false,
			solo: false,
			send: .32
		}
	};
}
var KIND_RANGE = {
	scream: {
		f0: [280, 800],
		cent: [2800, 6e3],
		rms: [.1, .45],
		flux: [3, 18],
		hnr: [.15, .55]
	},
	growl: {
		f0: [70, 160],
		cent: [600, 2e3],
		rms: [.08, .4],
		flux: [2, 10],
		hnr: [.1, .45]
	},
	belt: {
		f0: [180, 500],
		cent: [1800, 4e3],
		rms: [.1, .4],
		flux: [1, 8],
		hnr: [.4, .85]
	},
	rap: {
		f0: [80, 220],
		cent: [1200, 3200],
		rms: [.04, .25],
		flux: [3, 16],
		hnr: [.25, .7]
	},
	chop: {
		f0: [90, 260],
		cent: [1600, 4e3],
		rms: [.04, .22],
		flux: [6, 22],
		hnr: [.2, .6]
	},
	speak: {
		f0: [85, 220],
		cent: [1e3, 2800],
		rms: [.03, .18],
		flux: [2, 10],
		hnr: [.3, .75]
	},
	whisper: {
		f0: [120, 280],
		cent: [2500, 5500],
		rms: [.008, .06],
		flux: [1, 6],
		hnr: [.05, .35]
	},
	air: {
		f0: [140, 320],
		cent: [3e3, 7e3],
		rms: [.01, .08],
		flux: [.5, 5],
		hnr: [.1, .4]
	},
	choir: {
		f0: [140, 400],
		cent: [1400, 3600],
		rms: [.04, .2],
		flux: [.5, 4],
		hnr: [.45, .9]
	},
	opera: {
		f0: [220, 700],
		cent: [1800, 4200],
		rms: [.08, .35],
		flux: [.4, 4],
		hnr: [.5, .95]
	}
};
var ZERO_SCORES = Object.fromEntries(VOCAL_KINDS.map((k) => [k, 0]));
var EMPTY_CAP = {
	gen: 3,
	hasTake: false,
	rapped: false,
	durationS: 0,
	f0Hz: 0,
	f0Min: 0,
	f0Max: 0,
	rms: 0,
	peak: 0,
	crestDb: 0,
	centroidHz: 0,
	flux: 0,
	hnr: 0,
	scores: { ...ZERO_SCORES }
};
function clamp(n, a, b) {
	return Math.max(a, Math.min(b, n));
}
function inRangeScore(v, lo, hi) {
	if (v >= lo && v <= hi) return 1;
	const span = hi - lo || 1;
	return clamp(1 - (v < lo ? lo - v : v - hi) / span, 0, 1);
}
function coverScore(lo, hi, tLo, tHi) {
	const overlap = Math.max(0, Math.min(hi, tHi) - Math.max(lo, tLo));
	const span = tHi - tLo || 1;
	const hit = hi >= tLo && lo <= tHi ? .2 : 0;
	return clamp(overlap / span + hit, 0, 1);
}
function detectHz(buf, start, n, sr) {
	let e = 0;
	for (let i = 0; i < n; i++) e += buf[start + i] * buf[start + i];
	if (Math.sqrt(e / n) < .01) return 0;
	const minP = Math.floor(sr / 620);
	const maxP = Math.floor(sr / 70);
	let best = 1e9;
	let bestP = minP;
	for (let p = minP; p < maxP; p += 3) {
		let s = 0;
		const m = n - p;
		for (let i = 0; i < m; i += 4) {
			const d = buf[start + i] - buf[start + i + p];
			s += d * d;
		}
		if (s < best) {
			best = s;
			bestP = p;
		}
	}
	return sr / bestP;
}
function kindScores(cap) {
	const out = { ...ZERO_SCORES };
	const fLo = cap.f0Min || cap.f0Hz * .85;
	const fHi = cap.f0Max || cap.f0Hz * 1.15;
	for (const id of VOCAL_KINDS) {
		const r = KIND_RANGE[id];
		const s = .32 * coverScore(fLo, fHi, r.f0[0], r.f0[1]) + .22 * inRangeScore(cap.centroidHz, r.cent[0], r.cent[1]) + .18 * inRangeScore(cap.rms, r.rms[0], r.rms[1]) + .16 * inRangeScore(cap.flux, r.flux[0], r.flux[1]) + .12 * inRangeScore(cap.hnr, r.hnr[0], r.hnr[1]);
		out[id] = Math.round(s * 100) / 10;
	}
	return out;
}
/**
* Measure a take. Returns scalars for the 10-kind map.
* Call only on a buffer the user recorded or loaded — never to build a print.
*/
function measureVoice(buffer) {
	const sr = buffer.sampleRate;
	const ch = buffer.getChannelData(0);
	const durationS = ch.length / sr;
	if (ch.length < sr * .25) return {
		...EMPTY_CAP,
		durationS
	};
	const hop = 2048;
	const win = 1024;
	const maxN = Math.min(ch.length, Math.floor(sr * 6));
	let peak = 0;
	let sumSq = 0;
	let centNum = 0;
	let centDen = 0;
	let harm = 0;
	let noise = 0;
	const pitches = [];
	const energies = [];
	for (let i = 0; i + win < maxN; i += hop) {
		let e = 0;
		let mag = 0;
		for (let j = 0; j < win; j++) {
			const x = ch[i + j];
			e += x * x;
			const ax = Math.abs(x);
			if (ax > peak) peak = ax;
			mag += ax;
		}
		sumSq += e;
		energies.push(e);
		if (Math.sqrt(e / win) > .01) {
			const hz = detectHz(ch, i, win, sr);
			if (hz > 70 && hz < 700) pitches.push(hz);
		}
		let hi = 0;
		for (let j = 1; j < win; j += 2) hi += Math.abs(ch[i + j] - ch[i + j - 1]);
		centNum += hi * (sr / 2);
		centDen += mag + 1e-8;
		const odd = hi;
		const even = mag - hi;
		harm += even;
		noise += odd;
	}
	const rms = Math.sqrt(sumSq / Math.max(1, Math.floor(maxN)));
	const crestDb = peak > 1e-6 && rms > 1e-6 ? 20 * Math.log10(peak / rms) : 0;
	const centroidHz = clamp(centDen > 0 ? centNum / centDen / win : 1800, 200, 8e3);
	const hnr = clamp(harm / (harm + noise + 1e-8), 0, 1);
	let fluxHits = 0;
	for (let i = 1; i < energies.length; i++) if (energies[i] - energies[i - 1] > .002 && energies[i] > 8e-4) fluxHits += 1;
	const flux = fluxHits / Math.max(.4, durationS);
	const voiced = pitches.slice().sort((a, b) => a - b);
	const f0Hz = voiced.length ? voiced[Math.floor(voiced.length / 2)] : 0;
	const f0Min = voiced.length ? voiced[Math.floor(voiced.length * .1)] : 0;
	const f0Max = voiced.length ? voiced[Math.floor(voiced.length * .9)] : 0;
	const hasTake = durationS >= .4 && rms >= .008;
	const base = {
		hasTake,
		rapped: hasTake && durationS >= 1.15 && (flux >= 1.35 || f0Hz >= 70 && f0Hz <= 420 && rms >= .016),
		durationS: Math.round(durationS * 100) / 100,
		f0Hz: Math.round(f0Hz),
		f0Min: Math.round(f0Min),
		f0Max: Math.round(f0Max),
		rms: Math.round(rms * 1e3) / 1e3,
		peak: Math.round(peak * 1e3) / 1e3,
		crestDb: Math.round(crestDb * 10) / 10,
		centroidHz: Math.round(centroidHz),
		flux: Math.round(flux * 10) / 10,
		hnr: Math.round(hnr * 100) / 100
	};
	return {
		gen: 3,
		...base,
		scores: kindScores(base)
	};
}
function mimicAllowed(cap) {
	return Boolean(cap?.rapped && cap.hasTake);
}
function pitchRatioToward(fromHz, toHz) {
	if (fromHz < 70 || toHz < 70) return 1;
	return clamp(toHz / fromHz, .72, 1.35);
}
var PERSIST_KEY$1 = "steel-studio-v1";
var HARD = PATTERNS.hardstyle;
var useStudio = create((set) => ({
	tab: "desk",
	lang: "et",
	genre: "hardstyle",
	bpm: HARD.bpm,
	swing: HARD.swing,
	playing: false,
	armed: false,
	recording: false,
	bufferSize: 128,
	sampleRate: 48e3,
	host: "standalone",
	channels: emptyMix(),
	master: .82,
	width: .55,
	centerLock: true,
	drive: .52,
	glue: .5,
	ceiling: .92,
	translate: "festival",
	fxChain: "hard-delay",
	tuneAmount: .7,
	restoreOn: true,
	visualStyle: "auto",
	visualPrompt: "",
	lyrics: "",
	stillUrl: null,
	peak: 0,
	rms: 0,
	voices: 0,
	cpu: 0,
	step: 0,
	latency: 2.7,
	signal: 0,
	need: 0,
	velocity: 0,
	mid: 0,
	side: 0,
	pitch: 0,
	mic: null,
	inputLive: false,
	vocalName: null,
	beatName: null,
	processing: false,
	processNote: null,
	error: null,
	lastNote: "—",
	vocalLang: "et",
	vocalKind: "whisper",
	nightLane: false,
	voiceBank: "lead",
	hook: "",
	radarNote: null,
	path: "hybrid",
	signalScore: .5,
	visFps: 60,
	visQuality: 1,
	cores: 4,
	memoryGb: null,
	connection: "unknown",
	steps: HARD.steps,
	bassMidi: HARD.bassMidi,
	leadMidi: HARD.leadMidi,
	recs: emptyRecs(),
	activeRec: "r1",
	dirtBias: .45,
	theoryPaste: "",
	rhymeSeed: "",
	rhymeOut: "",
	geoLine: null,
	geoBusy: false,
	voiceCap: EMPTY_CAP,
	takeOwned: false,
	kindBusy: false,
	setTab: (tab) => set({ tab }),
	patch: (partial) => set(partial),
	setChannel: (id, mix) => set((s) => ({ channels: {
		...s.channels,
		[id]: {
			...s.channels[id],
			...mix
		}
	} })),
	toggleStep: (id, step) => set((s) => {
		const next = s.steps[id].slice();
		next[step] = next[step] > .2 ? 0 : 1;
		return { steps: {
			...s.steps,
			[id]: next
		} };
	}),
	setRec: (id, lane) => set((s) => ({ recs: {
		...s.recs,
		[id]: {
			...s.recs[id],
			...lane
		}
	} }))
}));
function slicePersist(s) {
	return {
		lang: s.lang,
		genre: s.genre,
		bpm: s.bpm,
		swing: s.swing,
		bufferSize: s.bufferSize,
		host: s.host,
		channels: s.channels,
		master: s.master,
		width: s.width,
		centerLock: s.centerLock,
		drive: s.drive,
		glue: s.glue,
		ceiling: s.ceiling,
		translate: s.translate,
		fxChain: s.fxChain,
		tuneAmount: s.tuneAmount,
		restoreOn: s.restoreOn,
		visualStyle: s.visualStyle,
		visualPrompt: s.visualPrompt,
		vocalLang: s.vocalLang,
		vocalKind: s.vocalKind,
		nightLane: s.nightLane,
		voiceBank: s.voiceBank,
		recs: s.recs,
		activeRec: s.activeRec,
		dirtBias: s.dirtBias,
		theoryPaste: s.theoryPaste,
		rhymeSeed: s.rhymeSeed,
		lyrics: s.lyrics,
		hook: s.hook
	};
}
function hydrateStudio() {
	if (typeof localStorage === "undefined") return;
	try {
		const raw = localStorage.getItem(PERSIST_KEY$1);
		if (!raw) return;
		const saved = JSON.parse(raw);
		const next = {};
		if (saved.lang === "et" || saved.lang === "en") next.lang = saved.lang;
		if (saved.genre) next.genre = saved.genre;
		if (typeof saved.bpm === "number") next.bpm = saved.bpm;
		if (typeof saved.swing === "number") next.swing = saved.swing;
		if (saved.bufferSize) next.bufferSize = saved.bufferSize;
		if (saved.host) next.host = saved.host;
		if (saved.channels) next.channels = {
			...emptyMix(),
			...saved.channels
		};
		if (typeof saved.master === "number") next.master = saved.master;
		if (typeof saved.width === "number") next.width = saved.width;
		if (typeof saved.centerLock === "boolean") next.centerLock = saved.centerLock;
		if (typeof saved.drive === "number") next.drive = saved.drive;
		if (typeof saved.glue === "number") next.glue = saved.glue;
		if (typeof saved.ceiling === "number") next.ceiling = saved.ceiling;
		if (saved.translate) next.translate = saved.translate;
		if (saved.fxChain) next.fxChain = saved.fxChain;
		if (typeof saved.tuneAmount === "number") next.tuneAmount = saved.tuneAmount;
		if (typeof saved.restoreOn === "boolean") next.restoreOn = saved.restoreOn;
		if (saved.visualStyle) next.visualStyle = saved.visualStyle;
		if (typeof saved.visualPrompt === "string") next.visualPrompt = saved.visualPrompt;
		if (isVocalLang(saved.vocalLang)) next.vocalLang = saved.vocalLang;
		if (isVocalKind(saved.vocalKind)) next.vocalKind = saved.vocalKind;
		if (typeof saved.nightLane === "boolean") next.nightLane = saved.nightLane;
		if (saved.voiceBank) next.voiceBank = saved.voiceBank;
		if (saved.recs) {
			const recs = emptyRecs();
			for (const id of REC_IDS) {
				const row = saved.recs[id];
				if (row) recs[id] = {
					...recs[id],
					...row,
					id
				};
			}
			next.recs = recs;
		}
		if (saved.activeRec) next.activeRec = saved.activeRec;
		if (typeof saved.dirtBias === "number") next.dirtBias = saved.dirtBias;
		if (typeof saved.theoryPaste === "string") next.theoryPaste = saved.theoryPaste;
		if (typeof saved.rhymeSeed === "string") next.rhymeSeed = saved.rhymeSeed;
		if (typeof saved.lyrics === "string") next.lyrics = saved.lyrics;
		if (typeof saved.hook === "string") next.hook = saved.hook;
		useStudio.getState().patch(next);
	} catch {}
}
function watchStudioPersist() {
	return useStudio.subscribe((s, prev) => {
		if (s.peak !== prev.peak || s.rms !== prev.rms || s.voices !== prev.voices || s.cpu !== prev.cpu || s.step !== prev.step || s.playing !== prev.playing || s.armed !== prev.armed || s.tab !== prev.tab || s.latency !== prev.latency || s.velocity !== prev.velocity || s.path !== prev.path || s.signalScore !== prev.signalScore || s.visFps !== prev.visFps || s.cores !== prev.cores || s.processing !== prev.processing || s.processNote !== prev.processNote || s.rhymeOut !== prev.rhymeOut || s.geoLine !== prev.geoLine || s.geoBusy !== prev.geoBusy || s.kindBusy !== prev.kindBusy || s.takeOwned !== prev.takeOwned || s.voiceCap !== prev.voiceCap || s.error !== prev.error || s.pitch !== prev.pitch) return;
		try {
			localStorage.setItem(PERSIST_KEY$1, JSON.stringify(slicePersist(s)));
		} catch {}
	});
}
function bufferToWav(buffer) {
	const ch = buffer.numberOfChannels;
	const sr = buffer.sampleRate;
	const len = buffer.length;
	const bytes = len * ch * 2;
	const ab = new ArrayBuffer(44 + bytes);
	const v = new DataView(ab);
	const w = (o, s) => {
		for (let i = 0; i < s.length; i++) v.setUint8(o + i, s.charCodeAt(i));
	};
	w(0, "RIFF");
	v.setUint32(4, 36 + bytes, true);
	w(8, "WAVE");
	w(12, "fmt ");
	v.setUint32(16, 16, true);
	v.setUint16(20, 1, true);
	v.setUint16(22, ch, true);
	v.setUint32(24, sr, true);
	v.setUint32(28, sr * ch * 2, true);
	v.setUint16(32, ch * 2, true);
	v.setUint16(34, 16, true);
	w(36, "data");
	v.setUint32(40, bytes, true);
	let o = 44;
	for (let i = 0; i < len; i++) for (let c = 0; c < ch; c++) {
		let s = buffer.getChannelData(c)[i];
		if (s > 1) s = 1;
		if (s < -1) s = -1;
		v.setInt16(o, s < 0 ? s * 32768 : s * 32767, true);
		o += 2;
	}
	return new Blob([ab], { type: "audio/wav" });
}
async function decodeAudio(file, ctx) {
	const ab = await file.arrayBuffer();
	return ctx.decodeAudioData(ab.slice(0));
}
var CACHE_MS = 8e3;
var cached = null;
function conn() {
	return navigator.connection ?? {};
}
function gpuKind() {
	if (navigator.gpu) return "webgpu";
	try {
		const c = document.createElement("canvas");
		if (c.getContext("webgl2") || c.getContext("webgl")) return "webgl";
	} catch {}
	return "none";
}
function clamp01(n) {
	return Math.max(0, Math.min(1, n));
}
function probeSignal(force = false) {
	if (!force && cached && performance.now() - cached.probedAt < CACHE_MS) return cached;
	const cores = navigator.hardwareConcurrency || 2;
	const memoryGb = typeof navigator.deviceMemory === "number" ? navigator.deviceMemory ?? null : null;
	const c = conn();
	const effective = (c.effectiveType || "unknown").toLowerCase();
	const downlink = typeof c.downlink === "number" ? c.downlink : null;
	const saveData = Boolean(c.saveData);
	const reducedMotion = typeof matchMedia === "function" && matchMedia("(prefers-reduced-motion: reduce)").matches;
	const worklet = typeof AudioWorkletNode === "function";
	const gpu = gpuKind();
	let score = 0;
	const notes = [];
	if (cores >= 8) score += .24;
	else if (cores >= 4) score += .16;
	else if (cores >= 2) score += .08;
	else score += .03;
	if (memoryGb == null) score += .1;
	else if (memoryGb >= 8) score += .24;
	else if (memoryGb >= 4) score += .16;
	else if (memoryGb >= 2) score += .08;
	else {
		score += .03;
		notes.push("low-memory");
	}
	if (effective === "4g" || effective === "5g") score += .14;
	else if (effective === "3g") {
		score += .06;
		notes.push("slow-link");
	} else if (effective === "2g" || effective === "slow-2g") {
		score += .02;
		notes.push("very-slow-link");
	} else score += .1;
	if (worklet) score += .14;
	else notes.push("no-worklet");
	if (gpu === "webgpu") score += .14;
	else if (gpu === "webgl") score += .1;
	else {
		score += .02;
		notes.push("no-gpu");
	}
	if (saveData) {
		score -= .08;
		notes.push("save-data");
	}
	if (reducedMotion) {
		score -= .05;
		notes.push("reduced-motion");
	}
	score = clamp01(score);
	let path = "hybrid";
	if (score < .38 || !worklet) path = "web";
	else if (score >= .7) path = "kernel";
	if (path === "web") notes.push("web-heavy");
	if (path === "kernel") notes.push("kernel-heavy");
	cached = {
		score,
		path,
		cores,
		memoryGb,
		connection: effective,
		downlink,
		worklet,
		gpu,
		reducedMotion,
		saveData,
		notes,
		probedAt: performance.now()
	};
	return cached;
}
function policyFor(path, force) {
	const p = force ?? path;
	if (p === "web") return {
		path: p,
		bufferSize: 512,
		latencyHint: "playback",
		fftSize: 512,
		visFps: 30,
		visQuality: .45
	};
	if (p === "hybrid") return {
		path: p,
		bufferSize: 256,
		latencyHint: "interactive",
		fftSize: 1024,
		visFps: 45,
		visQuality: .72
	};
	return {
		path: p,
		bufferSize: 128,
		latencyHint: "interactive",
		fftSize: 2048,
		visFps: 60,
		visQuality: 1
	};
}
function formatScore(n) {
	return `${Math.round(n * 100)}`;
}
var handle$1 = null;
var vocalBuffer = null;
var beatBuffer = null;
var rec = null;
var recChunks = [];
var previewSrc = null;
var GENRE_IDX = {
	hardstyle: 0,
	rawstyle: 1,
	techno: 2,
	rap: 3,
	trap: 4
};
var TRANSLATE_IDX = {
	phone: 1,
	jbl: 2,
	festival: 0
};
function fxParams(chain) {
	switch (chain) {
		case "hard-delay": return {
			fxMix: .32,
			fxFb: .38
		};
		case "club-verb": return {
			fxMix: .42,
			fxFb: .55
		};
		case "radio": return {
			fxMix: .12,
			fxFb: .18
		};
		case "trap-space": return {
			fxMix: .36,
			fxFb: .48
		};
		default: return {
			fxMix: .08,
			fxFb: .12
		};
	}
}
function mixArrays() {
	const s = useStudio.getState();
	const anySolo = CHANNELS.some((id) => s.channels[id].solo);
	const gain = /* @__PURE__ */ new Float32Array(6);
	const pan = /* @__PURE__ */ new Float32Array(6);
	const mute = /* @__PURE__ */ new Float32Array(6);
	const send = /* @__PURE__ */ new Float32Array(6);
	CHANNELS.forEach((id, i) => {
		const ch = s.channels[id];
		const silenced = ch.mute || anySolo && !ch.solo;
		gain[i] = silenced ? 0 : ch.gain;
		pan[i] = ch.pan;
		mute[i] = silenced ? 1 : 0;
		send[i] = ch.send;
	});
	return {
		gain,
		pan,
		mute,
		send
	};
}
function patternArrays() {
	const s = useStudio.getState();
	const pattern = /* @__PURE__ */ new Float32Array(96);
	CHANNELS.forEach((id, t) => {
		for (let i = 0; i < 16; i++) pattern[t * 16 + i] = s.steps[id][i] ?? 0;
	});
	return {
		pattern,
		bassMidi: Float32Array.from(s.bassMidi),
		leadMidi: Float32Array.from(s.leadMidi)
	};
}
function meltGain() {
	const s = useStudio.getState();
	return Object.values(s.recs).find((r) => r.armed && r.loaded)?.gain ?? .86;
}
function currentParams$1() {
	const s = useStudio.getState();
	const fx = fxParams(s.fxChain);
	const curve = armedCurve(s.recs);
	const scaleIdx = curve?.scale === "major" ? 1 : curve?.scale === "chromatic" ? 2 : curve?.scale === "phrygian" ? 3 : 0;
	return {
		bpm: s.bpm,
		swing: s.swing,
		genre: GENRE_IDX[s.genre],
		master: s.master,
		drive: s.drive,
		glue: s.glue,
		ceiling: s.ceiling,
		width: s.width,
		centerLock: s.centerLock ? 1 : 0,
		translate: TRANSLATE_IDX[s.translate],
		tuneAmt: s.tuneAmount,
		restore: s.restoreOn ? 1 : 0,
		inGain: 1,
		vocalHpf: curve?.hp ?? 80,
		formant: curve?.formant ?? 1,
		retune: curve?.retune ?? .05,
		scoopHz: curve?.scoopHz ?? 320,
		scoopDb: curve?.scoopDb ?? -2,
		presenceHz: curve?.presenceHz ?? 3200,
		presenceDb: curve?.presenceDb ?? 3,
		airHz: curve?.airHz ?? 8e3,
		airDb: curve?.airDb ?? 1.2,
		bankSat: curve?.sat ?? .2,
		bankDelay: curve?.delay ?? .12,
		bankSpace: curve?.space ?? .2,
		melt: meltGain(),
		key: curve?.key ?? 0,
		scaleIdx,
		...fx
	};
}
function pushAll() {
	if (!handle$1) return;
	handle$1.node.port.postMessage({
		type: "params",
		params: currentParams$1()
	});
	handle$1.node.port.postMessage({
		type: "mix",
		...mixArrays()
	});
	handle$1.node.port.postMessage({
		type: "pattern",
		...patternArrays()
	});
}
function getAnalyser() {
	if (!handle$1) return null;
	return {
		analyser: handle$1.analyser,
		freq: handle$1.freq,
		wave: handle$1.wave
	};
}
function getContext() {
	return handle$1?.ctx ?? null;
}
function applyMeter(data) {
	useStudio.getState().patch({
		peak: data.peak,
		rms: data.rms,
		voices: data.voices,
		step: data.step,
		cpu: data.cpu,
		latency: data.latency,
		signal: data.signal,
		need: data.need,
		velocity: data.velocity,
		mid: data.mid,
		side: data.side,
		pitch: data.pitch
	});
}
var AudioEngine = class {
	async arm() {
		return armEngine();
	}
	async disarm() {
		return disarmEngine();
	}
	play() {
		return play();
	}
	stop() {
		return stop();
	}
	note(on, midi, vel) {
		return sendNote$1(on, midi, vel);
	}
};
new AudioEngine();
async function armEngine() {
	if (handle$1 && handle$1.ctx.state !== "closed") {
		if (handle$1.ctx.state === "suspended") await handle$1.ctx.resume();
		useStudio.getState().patch({
			armed: true,
			error: null
		});
		return;
	}
	if (handle$1) await disarmEngine();
	const sampleRate = 48e3;
	const policy = policyFor(useStudio.getState().path);
	const ctx = new AudioContext({
		latencyHint: policy.latencyHint,
		sampleRate
	});
	ctx.resume();
	await ctx.audioWorklet.addModule(`/worklets/steel-studio.js?v=3`);
	const node = new AudioWorkletNode(ctx, "steel-studio", {
		numberOfInputs: 1,
		numberOfOutputs: 1,
		outputChannelCount: [2]
	});
	const vocalIn = ctx.createGain();
	vocalIn.gain.value = 1;
	vocalIn.connect(node);
	const beatGain = ctx.createGain();
	beatGain.gain.value = .72;
	const master = ctx.createGain();
	master.gain.value = 1;
	const dest = ctx.createMediaStreamDestination();
	const analyser = ctx.createAnalyser();
	analyser.fftSize = policy.fftSize;
	analyser.smoothingTimeConstant = .62;
	node.connect(master);
	beatGain.connect(master);
	master.connect(ctx.destination);
	master.connect(analyser);
	master.connect(dest);
	node.port.onmessage = (ev) => {
		const data = ev.data;
		if (data?.type !== "meter") return;
		applyMeter(data);
	};
	handle$1 = {
		ctx,
		node,
		master,
		vocalIn,
		beatGain,
		dest,
		analyser,
		freq: new Uint8Array(analyser.frequencyBinCount),
		wave: new Uint8Array(analyser.fftSize),
		mic: null,
		micStream: null,
		vocalSource: null,
		beatSource: null,
		recDestOn: true
	};
	useStudio.getState().patch({
		armed: true,
		sampleRate: ctx.sampleRate,
		error: null
	});
	pushAll();
	await ctx.resume();
}
async function disarmEngine() {
	stop();
	await stopMic();
	if (!handle$1) {
		useStudio.getState().patch({
			armed: false,
			playing: false
		});
		return;
	}
	try {
		handle$1.node.port.postMessage({ type: "panic" });
		handle$1.node.disconnect();
		handle$1.master.disconnect();
		await handle$1.ctx.close();
	} catch {}
	handle$1 = null;
	useStudio.getState().patch({
		armed: false,
		playing: false,
		inputLive: false,
		peak: 0,
		rms: 0
	});
}
async function play() {
	if (!useStudio.getState().armed) try {
		useStudio.getState().patch({ processNote: "arm" });
		await armEngine();
	} catch (err) {
		const message = err instanceof Error ? err.message : "engine";
		useStudio.getState().patch({
			error: message,
			processNote: null
		});
		throw err;
	}
	if (!handle$1) return;
	if (handle$1.ctx.state === "suspended") await handle$1.ctx.resume();
	pushAll();
	handle$1.node.port.postMessage({
		type: "play",
		on: true
	});
	restartBuffers(true);
	useStudio.getState().patch({
		playing: true,
		error: null,
		processNote: null
	});
}
function stop() {
	handle$1?.node.port.postMessage({
		type: "play",
		on: false
	});
	if (handle$1?.vocalSource) {
		try {
			handle$1.vocalSource.stop();
		} catch {}
		handle$1.vocalSource = null;
	}
	if (handle$1?.beatSource) {
		try {
			handle$1.beatSource.stop();
		} catch {}
		handle$1.beatSource = null;
	}
	useStudio.getState().patch({ playing: false });
}
async function togglePlay() {
	if (useStudio.getState().playing) stop();
	else await play();
}
function sendNote$1(on, note, vel = .85) {
	const run = async () => {
		if (!useStudio.getState().armed) {
			if (!on) return;
			await armEngine();
		}
		handle$1?.node.port.postMessage({
			type: on ? "noteOn" : "noteOff",
			note,
			vel
		});
		if (on) useStudio.getState().patch({ lastNote: `${[
			"C",
			"C#",
			"D",
			"D#",
			"E",
			"F",
			"F#",
			"G",
			"G#",
			"A",
			"A#",
			"B"
		][note % 12]}${Math.floor(note / 12) - 1}` });
	};
	run();
}
function loadGenre(genre) {
	const p = PATTERNS[genre];
	const meta = GENRE_META[genre];
	useStudio.getState().patch({
		genre,
		bpm: p.bpm,
		swing: p.swing,
		drive: meta.drive,
		steps: p.steps,
		bassMidi: p.bassMidi,
		leadMidi: p.leadMidi
	});
	const flat = flattenPattern(p);
	handle$1?.node.port.postMessage({
		type: "pattern",
		...flat
	});
	pushAll();
}
function restartBuffers(loop) {
	if (!handle$1) return;
	if (handle$1.vocalSource) {
		try {
			handle$1.vocalSource.stop();
		} catch {}
		handle$1.vocalSource = null;
	}
	if (handle$1.beatSource) {
		try {
			handle$1.beatSource.stop();
		} catch {}
		handle$1.beatSource = null;
	}
	if (vocalBuffer) {
		const src = handle$1.ctx.createBufferSource();
		src.buffer = vocalBuffer;
		src.loop = loop;
		src.connect(handle$1.vocalIn);
		src.start();
		handle$1.vocalSource = src;
	}
	if (beatBuffer) {
		const src = handle$1.ctx.createBufferSource();
		src.buffer = beatBuffer;
		src.loop = loop;
		src.connect(handle$1.beatGain);
		src.start();
		handle$1.beatSource = src;
	}
}
async function setVocalBuffer(buf, name, opts) {
	vocalBuffer = buf;
	if (opts?.measure !== false && !name.endsWith("-tts") && !name.endsWith("-kind")) {
		const cap = measureVoice(buf);
		useStudio.getState().patch({
			vocalName: name,
			voiceCap: cap,
			takeOwned: cap.hasTake
		});
	} else useStudio.getState().patch({ vocalName: name });
	if (useStudio.getState().playing) restartBuffers(true);
}
async function setBeatBuffer(buf, name) {
	beatBuffer = buf;
	useStudio.getState().patch({ beatName: name });
	if (useStudio.getState().playing) restartBuffers(true);
}
async function loadNightStandin() {
	if (!handle$1) await armEngine();
	if (!handle$1) throw new Error("engine");
	const res = await fetch(NIGHT_STANDIN_URL);
	if (!res.ok) throw new Error("standin");
	const ab = await res.arrayBuffer();
	await setBeatBuffer(await handle$1.ctx.decodeAudioData(ab.slice(0)), "night_backvox_standin");
	const s = useStudio.getState();
	const whisper = KIND_DSP.whisper.gain;
	s.setChannel("vocal", { gain: Math.min(s.channels.vocal.gain, whisper) });
	s.patch({
		nightLane: true,
		vocalKind: "whisper",
		dirtBias: Math.min(s.dirtBias, .35),
		width: .48
	});
	pushAll();
}
async function loadVocalFile(file) {
	if (!handle$1) await armEngine();
	if (!handle$1) throw new Error("engine");
	await setVocalBuffer(await decodeAudio(file, handle$1.ctx), file.name, { measure: true });
}
async function loadBeatFile(file) {
	if (!handle$1) await armEngine();
	if (!handle$1) throw new Error("engine");
	await setBeatBuffer(await decodeAudio(file, handle$1.ctx), file.name);
}
async function startMic() {
	if (!handle$1) await armEngine();
	if (!handle$1) return;
	if (handle$1.mic) return;
	try {
		const stream = await navigator.mediaDevices.getUserMedia({ audio: {
			echoCancellation: false,
			noiseSuppression: false,
			autoGainControl: false,
			channelCount: 1
		} });
		const mic = handle$1.ctx.createMediaStreamSource(stream);
		mic.connect(handle$1.vocalIn);
		handle$1.mic = mic;
		handle$1.micStream = stream;
		const track = stream.getAudioTracks()[0];
		const settings = track?.getSettings() ?? {};
		const noiseFloor = await estimateNoise(stream);
		const restore = noiseFloor > .02 || (settings.sampleRate ?? 48e3) < 44100;
		useStudio.getState().patch({
			inputLive: true,
			restoreOn: restore || useStudio.getState().restoreOn,
			mic: {
				label: track?.label || "Microphone",
				noiseFloor,
				sampleRate: settings.sampleRate ?? handle$1.ctx.sampleRate,
				channels: settings.channelCount ?? 1,
				restore
			}
		});
		pushAll();
	} catch {
		useStudio.getState().patch({
			inputLive: false,
			error: "mic"
		});
	}
}
async function stopMic() {
	if (!handle$1) return;
	if (handle$1.mic) {
		try {
			handle$1.mic.disconnect();
		} catch {}
		handle$1.mic = null;
	}
	handle$1.micStream?.getTracks().forEach((t) => t.stop());
	handle$1.micStream = null;
	useStudio.getState().patch({ inputLive: false });
}
async function estimateNoise(stream) {
	try {
		const ctx = new AudioContext();
		const src = ctx.createMediaStreamSource(stream);
		const an = ctx.createAnalyser();
		an.fftSize = 512;
		src.connect(an);
		await new Promise((r) => setTimeout(r, 180));
		const data = new Float32Array(an.fftSize);
		an.getFloatTimeDomainData(data);
		let e = 0;
		for (let i = 0; i < data.length; i++) e += data[i] * data[i];
		src.disconnect();
		await ctx.close();
		return Math.sqrt(e / data.length);
	} catch {
		return .03;
	}
}
async function toggleVoiceRec() {
	if (!handle$1) await armEngine();
	if (!handle$1) return "idle";
	if (rec && rec.state === "recording") {
		rec.stop();
		return "stop";
	}
	const dest = handle$1.ctx.createMediaStreamDestination();
	handle$1.vocalIn.connect(dest);
	const mime = MediaRecorder.isTypeSupported("audio/webm;codecs=opus") ? "audio/webm;codecs=opus" : MediaRecorder.isTypeSupported("audio/webm") ? "audio/webm" : "";
	recChunks = [];
	rec = new MediaRecorder(dest.stream, mime ? { mimeType: mime } : void 0);
	rec.ondataavailable = (e) => {
		if (e.data.size) recChunks.push(e.data);
	};
	rec.onstop = async () => {
		try {
			handle$1?.vocalIn.disconnect(dest);
		} catch {}
		const blob = new Blob(recChunks, { type: rec?.mimeType || "audio/webm" });
		rec = null;
		if (!handle$1 || blob.size < 64) {
			useStudio.getState().patch({ recording: false });
			return;
		}
		await setVocalBuffer(await handle$1.ctx.decodeAudioData(await blob.arrayBuffer()), "take", { measure: true });
		useStudio.getState().patch({ recording: false });
	};
	rec.start();
	useStudio.getState().patch({ recording: true });
	return "start";
}
async function bounceWav(seconds = 8) {
	try {
		useStudio.getState();
		const sr = handle$1?.ctx.sampleRate ?? 48e3;
		const offline = new OfflineAudioContext(2, Math.floor(sr * seconds), sr);
		await offline.audioWorklet.addModule(`/worklets/steel-studio.js?v=3`);
		const node = new AudioWorkletNode(offline, "steel-studio", {
			numberOfInputs: 1,
			numberOfOutputs: 1,
			outputChannelCount: [2]
		});
		node.connect(offline.destination);
		node.port.postMessage({
			type: "params",
			params: currentParams$1()
		});
		node.port.postMessage({
			type: "mix",
			...mixArrays()
		});
		node.port.postMessage({
			type: "pattern",
			...patternArrays()
		});
		node.port.postMessage({
			type: "play",
			on: true
		});
		if (vocalBuffer) {
			const src = offline.createBufferSource();
			src.buffer = vocalBuffer;
			src.connect(node);
			src.start(0);
		}
		if (beatBuffer) {
			const src = offline.createBufferSource();
			src.buffer = beatBuffer;
			src.connect(offline.destination);
			src.start(0);
		}
		return bufferToWav(await offline.startRendering());
	} catch {
		return null;
	}
}
function getVocalBuffer() {
	return vocalBuffer;
}
/** Play a styled copy through master. Does not replace the take. Not a print. */
async function previewOnce(buf, seconds = 3.2) {
	if (!handle$1) await armEngine();
	if (!handle$1) return;
	if (handle$1.ctx.state === "suspended") await handle$1.ctx.resume();
	try {
		previewSrc?.stop();
	} catch {}
	const src = handle$1.ctx.createBufferSource();
	src.buffer = buf;
	const g = handle$1.ctx.createGain();
	g.gain.value = .92;
	src.connect(g);
	g.connect(handle$1.master);
	const dur = Math.min(seconds, buf.duration);
	src.start();
	src.stop(handle$1.ctx.currentTime + dur);
	previewSrc = src;
}
function captureVoiceCap() {
	if (!vocalBuffer) {
		useStudio.getState().patch({
			voiceCap: EMPTY_CAP,
			takeOwned: false
		});
		return EMPTY_CAP;
	}
	const cap = measureVoice(vocalBuffer);
	useStudio.getState().patch({
		voiceCap: cap,
		takeOwned: cap.hasTake
	});
	return cap;
}
async function applyProcessedVocal(buf, name) {
	await setVocalBuffer(buf, name, { measure: false });
}
function onVisibility() {
	if (document.visibilityState === "visible" && handle$1?.ctx.state === "suspended") handle$1.ctx.resume();
}
var KEY = "steel-connectors-v1";
var DEFAULT_PATTERNS = [
	{
		id: "rings",
		src: "drawRings — concentric kick rings, sage phosphor"
	},
	{
		id: "tunnel",
		src: "drawTunnel — Kärestik tunnel, no gravity lock"
	},
	{
		id: "scope",
		src: "drawScope — 1000-bin wave, cream ink"
	},
	{
		id: "bars",
		src: "drawBars — spectrum plates"
	},
	{
		id: "lips",
		src: "drawLips — viseme lock from lyrics + rms"
	},
	{
		id: "film",
		src: "drawFilm — still + wave + mouth, recordable"
	}
];
function loadVault() {
	if (typeof localStorage === "undefined") return freshVault();
	try {
		const raw = localStorage.getItem(KEY);
		if (!raw) return freshVault();
		const v = JSON.parse(raw);
		if (v?.version !== 1) return freshVault();
		return v;
	} catch {
		return freshVault();
	}
}
function saveVault(partial) {
	const next = {
		...loadVault(),
		...partial,
		version: 1,
		savedAt: Date.now()
	};
	try {
		localStorage.setItem(KEY, JSON.stringify(next));
	} catch {}
	return next;
}
function freshVault() {
	return {
		version: 1,
		savedAt: Date.now(),
		banks: [],
		extras: [],
		visemes: [
			"rest",
			"closed",
			"wide",
			"round",
			"teeth",
			"open"
		],
		patterns: DEFAULT_PATTERNS
	};
}
function vaultJson(v) {
	return JSON.stringify(v, null, 2);
}
/** Store-method ZIP so the film pack downloads as one file. */
function crc32(buf) {
	let c = -1 >>> 0;
	for (let i = 0; i < buf.length; i++) {
		c ^= buf[i];
		for (let k = 0; k < 8; k++) c = c & 1 ? c >>> 1 ^ 3988292384 : c >>> 1;
	}
	return ~c >>> 0;
}
function u16(n) {
	const b = /* @__PURE__ */ new Uint8Array(2);
	new DataView(b.buffer).setUint16(0, n, true);
	return b;
}
function u32(n) {
	const b = /* @__PURE__ */ new Uint8Array(4);
	new DataView(b.buffer).setUint32(0, n, true);
	return b;
}
function concat(parts) {
	const len = parts.reduce((s, p) => s + p.length, 0);
	const out = new Uint8Array(len);
	let o = 0;
	for (const p of parts) {
		out.set(p, o);
		o += p.length;
	}
	return out;
}
function zipStore(files) {
	const locals = [];
	const centrals = [];
	let offset = 0;
	for (const file of files) {
		const name = new TextEncoder().encode(file.name);
		const data = new TextEncoder().encode(file.text);
		const crc = crc32(data);
		const local = concat([
			u32(67324752),
			u16(20),
			u16(0),
			u16(0),
			u16(0),
			u16(0),
			u32(crc),
			u32(data.length),
			u32(data.length),
			u16(name.length),
			u16(0),
			name,
			data
		]);
		const central = concat([
			u32(33639248),
			u16(20),
			u16(20),
			u16(0),
			u16(0),
			u16(0),
			u16(0),
			u32(crc),
			u32(data.length),
			u32(data.length),
			u16(name.length),
			u16(0),
			u16(0),
			u16(0),
			u16(0),
			u32(0),
			u32(offset),
			name
		]);
		locals.push(local);
		centrals.push(central);
		offset += local.length;
	}
	const body = concat(locals);
	const dir = concat(centrals);
	const end = concat([
		u32(101010256),
		u16(0),
		u16(0),
		u16(files.length),
		u16(files.length),
		u32(dir.length),
		u32(body.length),
		u16(0)
	]);
	return new Blob([concat([
		body,
		dir,
		end
	])], { type: "application/zip" });
}
function filmIndexHtml(vault) {
	return `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>STEEL FILM</title>
  <style>
    html,body{margin:0;background:#0c0d0b;color:#e6e1d4;font-family:"IBM Plex Sans",system-ui,sans-serif;overflow:hidden;height:100%}
    canvas{display:block;width:100%;height:100%;background:#0c0d0b}
    .hud{position:fixed;left:16px;top:16px;font:11px/1.4 ui-monospace,Menlo,monospace;letter-spacing:.18em;text-transform:uppercase;color:#8a877c;pointer-events:none}
  </style>
</head>
<body>
  <canvas id="c"></canvas>
  <div class="hud">STEEL FILM · 1000-BIN · LIP LOCK</div>
  <script id="vault" type="application/json">${vaultJson(vault).replace(/</g, "\\u003c")}<\/script>
  <script>
  const vault = JSON.parse(document.getElementById("vault").textContent);
  const canvas = document.getElementById("c");
  const ctx = canvas.getContext("2d");
  const ac = new (window.AudioContext || window.webkitAudioContext)();
  const an = ac.createAnalyser();
  an.fftSize = 2048;
  const wave = new Uint8Array(an.fftSize);
  const freq = new Uint8Array(an.frequencyBinCount);
  navigator.mediaDevices.getUserMedia({audio:true}).then((s) => {
    ac.createMediaStreamSource(s).connect(an);
    ac.resume();
  }).catch(() => {});
  const N = 1000;
  const bins = new Float32Array(N);
  const visemes = vault.visemes || ["rest","closed","wide","round","teeth","open"];
  function resize(){
    const dpr = Math.min(2, devicePixelRatio||1);
    canvas.width = innerWidth * dpr; canvas.height = innerHeight * dpr;
    ctx.setTransform(dpr,0,0,dpr,0,0);
  }
  addEventListener("resize", resize); resize();
  function lerp(a,b,t){return a+(b-a)*t}
  function loop(){
    an.getByteTimeDomainData(wave);
    an.getByteFrequencyData(freq);
    const w = innerWidth, h = innerHeight;
    ctx.fillStyle = "#0c0d0b"; ctx.fillRect(0,0,w,h);
    for (let i=0;i<N;i++){
      const x = i / (N-1) * (wave.length-1);
      const i0 = x|0, i1 = Math.min(wave.length-1, i0+1);
      bins[i] = lerp(wave[i0], wave[i1], x-i0) / 128 - 1;
    }
    ctx.beginPath();
    ctx.strokeStyle = "#e6e1d4";
    ctx.lineWidth = 1.25;
    for (let i=0;i<N;i++){
      const x = (i/(N-1))*w;
      const y = h*0.52 + bins[i]*h*0.22;
      i?ctx.lineTo(x,y):ctx.moveTo(x,y);
    }
    ctx.stroke();
    let rms=0; for (let i=0;i<N;i++) rms += bins[i]*bins[i];
    rms = Math.sqrt(rms/N);
    const shape = visemes[Math.min(visemes.length-1, Math.floor(rms * visemes.length))] || "open";
    const cx=w*0.5, cy=h*0.34;
    const mw = shape==="closed"?28:shape==="round"?24:40+rms*90;
    const mh = shape==="closed"?6:shape==="round"?24:8+rms*48;
    ctx.strokeStyle = "#6aa56f";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.ellipse(cx, cy, mw, mh, 0, 0, Math.PI*2);
    ctx.stroke();
    requestAnimationFrame(loop);
  }
  loop();
  <\/script>
</body>
</html>`;
}
function filmReadme() {
	return `STEEL FILM
Standalone wave + lip lock. Drop on any machine; it talks to the STEEL connector vault (connectors.json) that was sealed when you downloaded this pack.

Mic permission draws a 1000-bin waveform and a mouth from RMS + visemes.json. banks.json lists the containers that were open.

No cloud. No artist clones. Camera is yours.
`;
}
function filmZipBlob() {
	const vault = saveVault(loadVault());
	return zipStore([
		{
			name: "STEEL-FILM/index.html",
			text: filmIndexHtml(vault)
		},
		{
			name: "STEEL-FILM/README.txt",
			text: filmReadme()
		},
		{
			name: "STEEL-FILM/connectors.json",
			text: JSON.stringify(vault, null, 2)
		},
		{
			name: "STEEL-FILM/visemes.json",
			text: JSON.stringify(vault.visemes, null, 2)
		},
		{
			name: "STEEL-FILM/banks.json",
			text: JSON.stringify(vault.banks, null, 2)
		}
	]);
}
function downloadFilmPack() {
	downloadBlob(filmZipBlob(), "steel-film.zip");
}
var MINOR = [
	0,
	2,
	3,
	5,
	7,
	8,
	10
];
var MAJOR = [
	0,
	2,
	4,
	5,
	7,
	9,
	11
];
var PHRYG = [
	0,
	1,
	3,
	5,
	7,
	8,
	10
];
function scaleSet(scale) {
	if (scale === "major") return MAJOR;
	if (scale === "phrygian") return PHRYG;
	if (scale === "chromatic") return [
		0,
		1,
		2,
		3,
		4,
		5,
		6,
		7,
		8,
		9,
		10,
		11
	];
	return MINOR;
}
function snapHz(hz, key, scale) {
	if (hz < 70 || hz > 900) return hz;
	const midi = 69 + 12 * Math.log2(hz / 440);
	const set = scaleSet(scale);
	let best = midi;
	let bestD = 99;
	const base = Math.round(midi);
	for (let d = -12; d <= 12; d++) {
		const n = base + d;
		const pc = ((n - key) % 12 + 12) % 12;
		if (!set.includes(pc)) continue;
		const dist = Math.abs(n - midi);
		if (dist < bestD) {
			bestD = dist;
			best = n;
		}
	}
	return 440 * Math.pow(2, (best - 69) / 12);
}
/**
* AIVocalProcessor — dual-buffer vocal chain.
* Autotune snaps to the armed bank scale; analog-mirror keeps the container.
* Gen 3 mimic is DSP toward measured scalars, never a stored print.
*/
var AIVocalProcessor = class {
	async quantize(buffer, bpm, grid = 16) {
		const ctx = getContext() ?? new AudioContext();
		const sr = buffer.sampleRate;
		const step = 60 / bpm / (grid / 4);
		const hop = Math.max(64, Math.floor(sr * .01));
		const ch = buffer.getChannelData(0);
		const energies = [];
		for (let i = 0; i + hop < ch.length; i += hop) {
			let e = 0;
			for (let j = 0; j < hop; j += 4) e += ch[i + j] * ch[i + j];
			energies.push(e);
		}
		const onsets = [];
		for (let i = 1; i < energies.length; i++) if (energies[i] - energies[i - 1] > .002 && energies[i] > .001) onsets.push(i * hop / sr);
		const snapped = [];
		for (const t of onsets) {
			const q = Math.round(t / step) * step;
			snapped.push({
				t: Math.max(0, q),
				src: t
			});
		}
		const out = ctx.createBuffer(buffer.numberOfChannels, buffer.length, sr);
		const grain = Math.floor(sr * step);
		for (const hit of snapped) {
			const dst = Math.floor(hit.t * sr);
			const src = Math.floor(hit.src * sr);
			for (let c = 0; c < buffer.numberOfChannels; c++) {
				const a = buffer.getChannelData(c);
				const b = out.getChannelData(c);
				for (let i = 0; i < grain; i++) {
					if (dst + i >= b.length || src + i >= a.length) break;
					const w = .5 - .5 * Math.cos(Math.PI * i / grain);
					b[dst + i] += a[src + i] * w;
				}
			}
		}
		return out;
	}
	async restore(buffer) {
		return this.analogMirror(buffer, null);
	}
	async analogMirror(buffer, curve) {
		const offline = new OfflineAudioContext(buffer.numberOfChannels, buffer.length, buffer.sampleRate);
		const src = offline.createBufferSource();
		src.buffer = buffer;
		const hp = offline.createBiquadFilter();
		hp.type = "highpass";
		hp.frequency.value = curve?.hp ?? 90;
		const scoop = offline.createBiquadFilter();
		scoop.type = "peaking";
		scoop.frequency.value = curve?.scoopHz ?? 320;
		scoop.Q.value = .9;
		scoop.gain.value = curve?.scoopDb ?? -2.5;
		const presence = offline.createBiquadFilter();
		presence.type = "peaking";
		presence.frequency.value = curve?.presenceHz ?? 3200;
		presence.Q.value = 1.1;
		presence.gain.value = curve?.presenceDb ?? 3.5;
		const air = offline.createBiquadFilter();
		air.type = "highshelf";
		air.frequency.value = curve?.airHz ?? 8e3;
		air.gain.value = curve?.airDb ?? 1.5;
		const shaper = offline.createWaveShaper();
		const sat = curve?.sat ?? .2;
		const curveArr = /* @__PURE__ */ new Float32Array(1024);
		for (let i = 0; i < 1024; i++) {
			const x = i / 1023 * 2 - 1;
			curveArr[i] = Math.tanh(x * (1 + sat * 3.2)) / Math.tanh(1 + sat * 3.2);
		}
		shaper.curve = curveArr;
		const comp = offline.createDynamicsCompressor();
		comp.threshold.value = -18;
		comp.ratio.value = 3.2;
		comp.attack.value = .008;
		comp.release.value = .12;
		src.connect(hp);
		hp.connect(scoop);
		scoop.connect(presence);
		presence.connect(air);
		air.connect(shaper);
		shaper.connect(comp);
		comp.connect(offline.destination);
		src.start(0);
		return offline.startRendering();
	}
	async autotune(buffer, curve, amount) {
		const sr = buffer.sampleRate;
		const src = buffer.getChannelData(0);
		const hop = 512;
		const win = 1024;
		const pitches = [];
		for (let i = 0; i + win < src.length; i += hop) pitches.push(this.detectHz(src, i, win, sr));
		const key = curve?.key ?? 0;
		const scale = curve?.scale ?? "minor";
		const out = (getContext() ?? new AudioContext()).createBuffer(buffer.numberOfChannels, buffer.length, sr);
		for (let c = 0; c < buffer.numberOfChannels; c++) {
			const a = buffer.getChannelData(c);
			const b = out.getChannelData(c);
			for (let i = 0; i < a.length; i++) {
				const frame = Math.min(pitches.length - 1, Math.floor(i / hop));
				const hz = pitches[Math.max(0, frame)] ?? 0;
				const target = hz > 0 ? snapHz(hz, key, scale) : hz;
				const ratio = hz > 0 && target > 0 ? 1 + (target / hz - 1) * amount : 1;
				const srcI = i * ratio;
				const i0 = Math.floor(srcI);
				const i1 = Math.min(a.length - 1, i0 + 1);
				const t = srcI - i0;
				const dry = a[i];
				const wet = i0 >= 0 && i0 < a.length ? a[i0] * (1 - t) + a[i1] * t : dry;
				b[i] = dry * (1 - amount) + wet * amount;
			}
		}
		return out;
	}
	detectHz(buf, start, n, sr) {
		let e = 0;
		for (let i = 0; i < n; i++) e += buf[start + i] * buf[start + i];
		if (Math.sqrt(e / n) < .012) return 0;
		const minP = Math.floor(sr / 720);
		const maxP = Math.floor(sr / 80);
		let best = 1e9;
		let bestP = minP;
		for (let p = minP; p < maxP; p += 2) {
			let s = 0;
			const m = n - p;
			for (let i = 0; i < m; i += 3) {
				const d = buf[start + i] - buf[start + i + p];
				s += d * d;
			}
			if (s < best) {
				best = s;
				bestP = p;
			}
		}
		return sr / bestP;
	}
	async harmony(buffer, semitones = [3, 7]) {
		const sr = buffer.sampleRate;
		const offline = new OfflineAudioContext(2, buffer.length, sr);
		const dry = offline.createBufferSource();
		dry.buffer = buffer;
		const dryG = offline.createGain();
		dryG.gain.value = .85;
		dry.connect(dryG);
		dryG.connect(offline.destination);
		dry.start(0);
		for (const st of semitones) {
			const rate = Math.pow(2, st / 12);
			const src = offline.createBufferSource();
			src.buffer = buffer;
			src.playbackRate.value = rate;
			const g = offline.createGain();
			g.gain.value = .38;
			const pan = offline.createStereoPanner();
			pan.pan.value = st > 5 ? .35 : -.35;
			src.connect(g);
			g.connect(pan);
			pan.connect(offline.destination);
			src.start(0);
		}
		return offline.startRendering();
	}
	async choir(buffer) {
		return this.harmony(buffer, [
			-5,
			3,
			7,
			12
		]);
	}
	async applyChain(buffer, chain) {
		const sr = buffer.sampleRate;
		const offline = new OfflineAudioContext(2, buffer.length + Math.floor(sr * 1.2), sr);
		const src = offline.createBufferSource();
		src.buffer = buffer;
		const input = offline.createGain();
		src.connect(input);
		const delay = offline.createDelay(1.2);
		const fb = offline.createGain();
		const mix = offline.createGain();
		const filter = offline.createBiquadFilter();
		filter.type = "lowpass";
		if (chain === "hard-delay") {
			delay.delayTime.value = .375 * (60 / 150);
			fb.gain.value = .38;
			mix.gain.value = .32;
			filter.frequency.value = 4200;
		} else if (chain === "club-verb") {
			delay.delayTime.value = .09;
			fb.gain.value = .62;
			mix.gain.value = .42;
			filter.frequency.value = 5200;
		} else if (chain === "radio") {
			mix.gain.value = 0;
			const hp = offline.createBiquadFilter();
			hp.type = "highpass";
			hp.frequency.value = 280;
			const lp = offline.createBiquadFilter();
			lp.type = "lowpass";
			lp.frequency.value = 3800;
			input.connect(hp);
			hp.connect(lp);
			lp.connect(offline.destination);
		} else if (chain === "trap-space") {
			delay.delayTime.value = .5 * (60 / 140);
			fb.gain.value = .42;
			mix.gain.value = .38;
			filter.frequency.value = 4800;
		} else {
			mix.gain.value = 0;
			fb.gain.value = 0;
			delay.delayTime.value = .1;
			filter.frequency.value = 8e3;
		}
		input.connect(offline.destination);
		input.connect(delay);
		delay.connect(filter);
		filter.connect(fb);
		fb.connect(delay);
		filter.connect(mix);
		mix.connect(offline.destination);
		src.start(0);
		return offline.startRendering();
	}
	/**
	* DSP stand-in for a recorded take. Formant / grit / grain — not a voice-print clone.
	* Apply only if the user has rapped or spoken into the slot.
	*/
	async styleKind(buffer, kind) {
		const spec = KIND_DSP[kind];
		if (kind === "choir") return this.choir(buffer);
		if (spec.grains) return this.quantize(buffer, useStudio.getState().bpm, 32);
		if (kind === "opera") {
			const hall = await this.applyChain(buffer, "club-verb");
			return this.paintKind(hall, spec);
		}
		return this.paintKind(buffer, spec);
	}
	async paintKind(buffer, spec) {
		const offline = new OfflineAudioContext(Math.max(2, buffer.numberOfChannels), buffer.length, buffer.sampleRate);
		const src = offline.createBufferSource();
		src.buffer = buffer;
		const hp = offline.createBiquadFilter();
		hp.type = "highpass";
		hp.frequency.value = spec.hp;
		const scoop = offline.createBiquadFilter();
		scoop.type = "peaking";
		scoop.frequency.value = spec.scoopHz;
		scoop.Q.value = .9;
		scoop.gain.value = spec.scoopDb;
		const presence = offline.createBiquadFilter();
		presence.type = "peaking";
		presence.frequency.value = spec.presenceHz;
		presence.Q.value = 1.05;
		presence.gain.value = spec.presenceDb;
		const air = offline.createBiquadFilter();
		air.type = "highshelf";
		air.frequency.value = 7500;
		air.gain.value = spec.airDb;
		const shaper = offline.createWaveShaper();
		const curveArr = /* @__PURE__ */ new Float32Array(1024);
		for (let i = 0; i < 1024; i++) {
			const x = i / 1023 * 2 - 1;
			curveArr[i] = Math.tanh(x * (1 + spec.sat * 3.4)) / Math.tanh(1 + spec.sat * 3.4);
		}
		shaper.curve = curveArr;
		const g = offline.createGain();
		g.gain.value = spec.gain;
		src.connect(hp);
		hp.connect(scoop);
		scoop.connect(presence);
		presence.connect(air);
		air.connect(shaper);
		shaper.connect(g);
		g.connect(offline.destination);
		src.start(0);
		return offline.startRendering();
	}
	/**
	* Sit a TTS stand-in in the user's measured F0 / centroid.
	* Scalars only. Refuses when the take was never rapped.
	*/
	async formantToward(buffer, cap) {
		if (!mimicAllowed(cap) || cap.f0Hz < 70) return buffer;
		const ratio = pitchRatioToward(measureVoice(buffer).f0Hz || 160, cap.f0Hz);
		const duration = Math.max(1, Math.floor(buffer.length / ratio));
		const offline = new OfflineAudioContext(Math.max(2, buffer.numberOfChannels), duration, buffer.sampleRate);
		const src = offline.createBufferSource();
		src.buffer = buffer;
		src.playbackRate.value = ratio;
		const presence = offline.createBiquadFilter();
		presence.type = "peaking";
		presence.frequency.value = Math.max(800, Math.min(5200, cap.centroidHz || 2200));
		presence.Q.value = .9;
		presence.gain.value = 2.2;
		const g = offline.createGain();
		g.gain.value = 1;
		src.connect(presence);
		presence.connect(g);
		g.connect(offline.destination);
		src.start(0);
		return offline.startRendering();
	}
};
var vocalProcessor = new AIVocalProcessor();
async function processCurrent(kind) {
	const buf = getVocalBuffer();
	if (!buf) return null;
	const s = useStudio.getState();
	const curve = armedCurve(s.recs);
	if (kind === "quantize") return vocalProcessor.quantize(buf, s.bpm);
	if (kind === "restore") return vocalProcessor.restore(buf);
	if (kind === "harmony") return vocalProcessor.harmony(buf);
	if (kind === "choir") return vocalProcessor.choir(buf);
	if (kind === "tune") return vocalProcessor.autotune(buf, curve, s.tuneAmount);
	if (kind === "mirror") return vocalProcessor.analogMirror(buf, curve);
	if (kind === "kind") {
		if (!mimicAllowed(s.voiceCap)) return null;
		const styled = await vocalProcessor.styleKind(buf, s.vocalKind);
		return vocalProcessor.formantToward(styled, s.voiceCap);
	}
	return vocalProcessor.applyChain(buf, s.fxChain);
}
/**
* Hear a kind on the current take without writing the slot.
* Refuses unless the user rapped. Scalars only — no print.
*/
async function auditionKind(kind) {
	const buf = getVocalBuffer();
	if (!buf) return "empty";
	const s = useStudio.getState();
	if (!mimicAllowed(s.voiceCap)) return "rap";
	const styled = await vocalProcessor.styleKind(buf, kind);
	await previewOnce(await vocalProcessor.formantToward(styled, s.voiceCap), 3.2);
	return "ok";
}
function Fader({ label, value, min = 0, max = 1, step = .01, onChange, unit }) {
	const pretty = max > 10 ? String(Math.round(value)) : value.toFixed(2).replace(/0+$/, "").replace(/\.$/, "");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "flex min-h-11 flex-col gap-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "flex items-baseline justify-between font-mono text-2xs tracking-wider text-muted uppercase",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "tabular-nums text-ink",
				children: [pretty, unit ?? ""]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			type: "range",
			min,
			max,
			step,
			value,
			onChange: (e) => onChange(Number(e.target.value)),
			className: cn("steel-range")
		})]
	});
}
function StudioBanks() {
	const lang = useStudio((s) => s.lang);
	const recs = useStudio((s) => s.recs);
	const activeRec = useStudio((s) => s.activeRec);
	const setRec = useStudio((s) => s.setRec);
	const setChannel = useStudio((s) => s.setChannel);
	const patch = useStudio((s) => s.patch);
	const processing = useStudio((s) => s.processing);
	const tuneAmount = useStudio((s) => s.tuneAmount);
	const lane = recs[activeRec];
	const bank = lane.bankId ? BANK_BY_ID[lane.bankId] : null;
	const curve = armedCurve(recs);
	function pick(id) {
		REC_IDS.forEach((rid) => setRec(rid, { armed: rid === id }));
		patch({ activeRec: id });
		pushAll();
	}
	function openBank(bankId) {
		const b = BANK_BY_ID[bankId];
		if (!b) return;
		setRec(activeRec, {
			bankId,
			loaded: true,
			armed: true
		});
		REC_IDS.forEach((rid) => {
			if (rid !== activeRec) setRec(rid, { armed: false });
		});
		setChannel("vocal", { gain: lane.gain });
		patch({
			tuneAmount: b.curve.amount,
			width: b.curve.width,
			drive: Math.min(.9, .25 + b.curve.sat * .5),
			genre: b.curve.genre
		});
		saveVault({ banks: Object.values(useStudio.getState().recs).map((r) => r.bankId).filter(Boolean) });
		pushAll();
		toast.success(`${b.name} · 5`);
	}
	async function melt(kind) {
		patch({ processing: true });
		try {
			const buf = await processCurrent(kind);
			if (!buf) {
				toast.error(t(lang, "emptyVocal"));
				return;
			}
			await applyProcessedVocal(buf, `${kind}-${activeRec}`);
			toast.success(t(lang, kind === "tune" ? "tune" : "analogMirror"));
		} catch {
			toast.error(t(lang, "decodeFail"));
		} finally {
			patch({ processing: false });
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-w-0 flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-col gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-2xs tracking-[0.18em] text-muted uppercase",
						children: t(lang, "banksKicker")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-3xl text-ink",
						children: t(lang, "banksTitle")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-w-2xl text-pretty text-muted",
						children: t(lang, "banksLead")
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "nav-scroll",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex w-max gap-2",
					children: REC_IDS.map((id, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => pick(id),
						className: cn("min-h-11 shrink-0 rounded-[var(--radius-sm)] px-3 text-sm ring-1 ring-rule", activeRec === id ? "bg-ink text-paper" : "text-muted"),
						children: [
							t(lang, "recLane"),
							" ",
							i + 1
						]
					}, id))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-mono text-2xs text-muted",
				children: lane.loaded && bank ? `${bank.name} · ${t(lang, "loaded")}` : t(lang, "sealed")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid min-w-0 gap-2 sm:grid-cols-2",
				children: BANKS$1.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => openBank(b.id),
					className: cn("min-h-11 rounded-[var(--radius-md)] px-3 py-3 text-left ring-1 ring-rule", lane.bankId === b.id && lane.loaded ? "bg-ink text-paper" : "bg-raised text-ink"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display tracking-wide",
						children: b.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: cn("mt-1 text-sm", lane.bankId === b.id && lane.loaded ? "text-paper/70" : "text-muted"),
						children: lang === "et" ? b.noteEt : b.noteEn
					})]
				}, b.id))
			}),
			lane.loaded && curve ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-[var(--radius-lg)] bg-raised p-4 ring-1 ring-rule",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-2xs tracking-wider text-muted uppercase",
						children: t(lang, "plugins")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 divide-y divide-rule",
						children: PLUGIN_IDS.map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-baseline justify-between gap-3 py-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: lang === "et" ? PLUGIN_META[id].et : PLUGIN_META[id].en }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-2xs text-live uppercase",
								children: t(lang, "loaded")
							})]
						}, id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 grid gap-3 sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fader, {
								label: t(lang, "tune"),
								value: tuneAmount,
								min: 0,
								max: 1,
								onChange: (v) => {
									patch({ tuneAmount: v });
									setRec(activeRec, { edit: {
										...lane.edit,
										amount: v
									} });
									pushAll();
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fader, {
								label: "Formant",
								value: curve.formant,
								min: .7,
								max: 1.3,
								onChange: (v) => {
									setRec(activeRec, { edit: {
										...lane.edit,
										formant: v
									} });
									pushAll();
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fader, {
								label: t(lang, "melt"),
								value: lane.gain,
								min: 0,
								max: 1,
								onChange: (v) => {
									setRec(activeRec, { gain: v });
									setChannel("vocal", { gain: v });
									pushAll();
								}
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-wrap gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "live",
								disabled: processing,
								onClick: () => void melt("tune"),
								children: t(lang, "tune")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "secondary",
								disabled: processing,
								onClick: () => void melt("mirror"),
								children: t(lang, "analogMirror")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "secondary",
								onClick: () => void import("./xlsx-banks-cWYCCkvt.mjs").then((m) => m.exportBankBook()),
								children: t(lang, "downloadXlsx")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "ghost",
								onClick: () => downloadFilmPack(),
								children: t(lang, "downloadPack")
							})
						]
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: t(lang, "sealed")
			})
		]
	});
}
var DEFAULT_ORDERS = {
	architect: {
		et: "Loe hosti signaal. Nõrk masin → veebitee. Tugev masin → tuum. Kirjuta poliitika.",
		en: "Read host signal. Weak machine → web path. Strong machine → kernel. Write policy."
	},
	builder: {
		et: "Rakenda arhitekti poliitika puhvrisse ja visuaali. Ära kirjuta mixi üle ilma põhjuseta.",
		en: "Apply architect policy to buffer and visuals. Do not overwrite the mix without cause."
	},
	maintenance: {
		et: "Hoia mootor elus. Kui latentsus või CPU jookseb, suurenda puhvrit. Logi vead.",
		en: "Keep the engine alive. If latency or CPU runs away, raise the buffer. Log faults."
	},
	seeker: {
		et: "Otsi tuuma kanalilt uuendusi ja võimekuse muutusi.",
		en: "Seek kernel-channel updates and capability changes."
	},
	executioner: {
		et: "Vaheta tuum/veeb kui arhitekt muudab poliitikat. Ära sunni kerneliversiooni ilma kinnituseta.",
		en: "Switch kernel/web when the architect changes policy. Do not force a kernel version unconfirmed."
	},
	kernel: {
		et: "Hoia AudioWorklet ja 4D maatriks. Raporteeri kui tuum ei lae.",
		en: "Hold the AudioWorklet and 4D matrix. Report if the kernel fails to load."
	},
	web: {
		et: "Kui signaal on nõrk, kanna koormus veebiteele: suurem puhver, kergem visuaal.",
		en: "When the signal is weak, carry load on the web path: larger buffer, lighter visuals."
	}
};
var AGENT_META = {
	architect: {
		et: "Arhitekt",
		en: "Architect",
		dutyEt: "Poliitika ja tee",
		dutyEn: "Policy and path"
	},
	builder: {
		et: "Ehitaja",
		en: "Builder",
		dutyEt: "Rakendus",
		dutyEn: "Apply"
	},
	maintenance: {
		et: "Hooldus",
		en: "Maintenance",
		dutyEt: "Elushoid",
		dutyEn: "Keep-alive"
	},
	seeker: {
		et: "Otsija",
		en: "Seeker",
		dutyEt: "Uuendused",
		dutyEn: "Updates"
	},
	executioner: {
		et: "Täitja",
		en: "Executioner",
		dutyEt: "Teevahetus",
		dutyEn: "Path switch"
	},
	kernel: {
		et: "Tuum",
		en: "Kernel",
		dutyEt: "Kohalik mootor",
		dutyEn: "Local motor"
	},
	web: {
		et: "Veeb",
		en: "Web",
		dutyEt: "Kerge tee",
		dutyEn: "Light path"
	}
};
var AGENT_IDS = [
	"architect",
	"builder",
	"maintenance",
	"seeker",
	"executioner",
	"kernel",
	"web"
];
var PERSIST_KEY = "steel-crew-v1";
var LOG_CAP = 80;
function defaultAgents(lang) {
	const agents = {};
	for (const id of AGENT_IDS) agents[id] = {
		id,
		status: "idle",
		order: DEFAULT_ORDERS[id][lang],
		lastLine: "",
		lastAt: 0,
		ticks: 0
	};
	return agents;
}
var useCrew = create((set, get) => ({
	watching: true,
	forcePath: null,
	policyRev: 0,
	appliedRev: 0,
	livePath: "hybrid",
	channelLatest: null,
	log: [],
	agents: defaultAgents("et"),
	setWatching: (on) => set({ watching: on }),
	setForcePath: (path) => set({ forcePath: path }),
	setOrder: (id, order) => set((s) => ({ agents: {
		...s.agents,
		[id]: {
			...s.agents[id],
			order
		}
	} })),
	setAgent: (id, patch) => set((s) => ({ agents: {
		...s.agents,
		[id]: {
			...s.agents[id],
			...patch
		}
	} })),
	pushLog: (agent, line) => {
		const entry = {
			id: Date.now() + Math.floor(Math.random() * 99),
			at: Date.now(),
			agent,
			line
		};
		const log = [...get().log, entry];
		if (log.length > LOG_CAP) log.splice(0, log.length - LOG_CAP);
		set({
			log,
			agents: {
				...get().agents,
				[agent]: {
					...get().agents[agent],
					lastLine: line,
					lastAt: entry.at
				}
			}
		});
	},
	patch: (partial) => set(partial)
}));
function hydrateCrew(lang) {
	if (typeof localStorage === "undefined") return;
	try {
		const raw = localStorage.getItem(PERSIST_KEY);
		if (!raw) {
			useCrew.setState({ agents: defaultAgents(lang) });
			return;
		}
		const saved = JSON.parse(raw);
		const agents = defaultAgents(lang);
		if (saved.orders) for (const id of AGENT_IDS) {
			const o = saved.orders[id];
			if (typeof o === "string" && o.trim()) agents[id].order = o;
		}
		useCrew.setState({
			agents,
			watching: saved.watching !== false,
			forcePath: saved.forcePath === "kernel" || saved.forcePath === "web" || saved.forcePath === "hybrid" ? saved.forcePath : null
		});
	} catch {
		useCrew.setState({ agents: defaultAgents(lang) });
	}
}
function watchCrewPersist() {
	let last = "";
	return useCrew.subscribe((s) => {
		try {
			const orders = {};
			for (const id of AGENT_IDS) orders[id] = s.agents[id].order;
			const body = JSON.stringify({
				forcePath: s.forcePath,
				watching: s.watching,
				orders
			});
			if (body === last) return;
			last = body;
			localStorage.setItem(PERSIST_KEY, JSON.stringify({
				forcePath: s.forcePath,
				watching: s.watching,
				orders
			}));
		} catch {}
	});
}
var PATHS = [
	{
		id: "auto",
		et: "Auto",
		en: "Auto"
	},
	{
		id: "kernel",
		et: "Tuum",
		en: "Kernel"
	},
	{
		id: "hybrid",
		et: "Hübriid",
		en: "Hybrid"
	},
	{
		id: "web",
		et: "Veeb",
		en: "Web"
	}
];
function statusLabel(lang, status) {
	if (status === "work") return t(lang, "dutyWork");
	if (status === "blocked") return t(lang, "dutyBlocked");
	if (status === "paused") return t(lang, "dutyPaused");
	return t(lang, "dutyIdle");
}
function timeAgo(at, lang) {
	if (!at) return "—";
	const s = Math.max(0, Math.round((Date.now() - at) / 1e3));
	if (s < 5) return lang === "et" ? "nüüd" : "now";
	if (s < 60) return `${s}s`;
	return `${Math.round(s / 60)}m`;
}
function StudioCrew() {
	const lang = useStudio((s) => s.lang);
	const path = useStudio((s) => s.path);
	const score = useStudio((s) => s.signalScore);
	const cores = useStudio((s) => s.cores);
	const memoryGb = useStudio((s) => s.memoryGb);
	const connection = useStudio((s) => s.connection);
	const bufferSize = useStudio((s) => s.bufferSize);
	const visFps = useStudio((s) => s.visFps);
	const watching = useCrew((s) => s.watching);
	const forcePath = useCrew((s) => s.forcePath);
	const agents = useCrew((s) => s.agents);
	const log = useCrew((s) => s.log);
	const setWatching = useCrew((s) => s.setWatching);
	const setForcePath = useCrew((s) => s.setForcePath);
	const setOrder = useCrew((s) => s.setOrder);
	const patchCrew = useCrew((s) => s.patch);
	const [draft, setDraft] = (0, import_react.useState)({});
	const [open, setOpen] = (0, import_react.useState)(null);
	const reversed = (0, import_react.useMemo)(() => log.slice().reverse(), [log]);
	function commit(id) {
		const text = (draft[id] ?? agents[id].order).trim();
		if (!text) return;
		setOrder(id, text);
		setDraft((d) => ({
			...d,
			[id]: void 0
		}));
		const lower = text.toLowerCase();
		if (/\b(paus|pause)\b/.test(lower)) useCrew.getState().setAgent(id, { status: "paused" });
		if (/\b(jätka|jatka|resume)\b/.test(lower)) useCrew.getState().setAgent(id, { status: "idle" });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-w-0 flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-col gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-2xs tracking-[0.18em] text-muted uppercase",
						children: t(lang, "crewKicker")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-3xl text-ink",
						children: t(lang, "crewTitle")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-w-2xl text-pretty text-muted",
						children: t(lang, "crewLead")
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-[var(--radius-lg)] bg-raised p-4 ring-1 ring-rule",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-end justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-2xs tracking-wider text-muted uppercase",
							children: t(lang, "hostSignal")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 font-display text-3xl tabular-nums",
							children: formatScore(score)
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-xl tracking-[0.12em] uppercase text-ink",
							children: path === "kernel" ? t(lang, "pathKernel") : path === "web" ? t(lang, "pathWeb") : t(lang, "pathHybrid")
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat$2, {
								label: t(lang, "coresLabel"),
								value: String(cores)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat$2, {
								label: t(lang, "memoryLabel"),
								value: memoryGb != null ? `${memoryGb} GB` : "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat$2, {
								label: t(lang, "connectionLabel"),
								value: connection
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat$2, {
								label: t(lang, "policyLabel"),
								value: `${bufferSize} · ${visFps} fps`
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-wrap gap-2",
						children: [PATHS.map((item) => {
							const active = item.id === "auto" ? forcePath == null : forcePath === item.id;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									if (item.id === "auto") setForcePath(null);
									else {
										setForcePath(item.id);
										useStudio.getState().patch({ path: item.id });
										patchCrew({ policyRev: useCrew.getState().policyRev + 1 });
									}
								},
								className: cn("min-h-11 rounded-[var(--radius-sm)] px-3 text-sm ring-1 ring-rule", active ? "bg-ink text-paper" : "text-muted"),
								children: lang === "et" ? item.et : item.en
							}, item.id);
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: watching ? "live" : "secondary",
							onClick: () => setWatching(!watching),
							children: watching ? t(lang, "watchOn") : t(lang, "watchOff")
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "grid min-w-0 gap-3 sm:grid-cols-2",
				children: AGENT_IDS.map((id) => {
					const agent = agents[id];
					const meta = AGENT_META[id];
					const led = agent.status === "work" ? "bg-live" : agent.status === "blocked" ? "bg-clip" : agent.status === "paused" ? "bg-copper" : "bg-rule";
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "min-w-0 rounded-[var(--radius-md)] bg-raised p-4 ring-1 ring-rule",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: cn("size-2 shrink-0 rounded-full", led),
											"aria-hidden": true
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-display text-lg tracking-wide",
											children: lang === "et" ? meta.et : meta.en
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-1 font-mono text-2xs tracking-wider text-muted uppercase",
										children: [
											lang === "et" ? meta.dutyEt : meta.dutyEn,
											" · ",
											statusLabel(lang, agent.status)
										]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "shrink-0 font-mono text-2xs text-muted",
									children: timeAgo(agent.lastAt, lang)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 line-clamp-2 text-sm text-muted",
								children: agent.lastLine || "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "mt-3 min-h-11 text-left font-mono text-2xs tracking-wider text-steel uppercase",
								onClick: () => setOpen(open === id ? null : id),
								children: t(lang, "standingOrder")
							}),
							open === id ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex flex-col gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "sr-only",
										htmlFor: `order-${id}`,
										children: t(lang, "standingOrder")
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
										id: `order-${id}`,
										rows: 3,
										value: draft[id] ?? agent.order,
										onChange: (e) => setDraft((d) => ({
											...d,
											[id]: e.target.value
										})),
										className: "min-h-20 w-full min-w-0 resize-y rounded-[var(--radius-sm)] bg-paper px-3 py-2 text-sm text-ink ring-1 ring-rule"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										type: "button",
										size: "sm",
										variant: "secondary",
										onClick: () => commit(id),
										children: t(lang, "issueOrder")
									})
								]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 line-clamp-2 font-mono text-2xs text-faint",
								children: agent.order
							})
						]
					}, id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-3 font-mono text-2xs tracking-wider text-muted uppercase",
				children: t(lang, "crewLog")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "flex max-h-80 min-w-0 flex-col gap-2 overflow-y-auto",
				children: reversed.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "text-sm text-muted",
					children: "—"
				}) : reversed.map((entry) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "min-w-0 rounded-[var(--radius-sm)] bg-raised px-3 py-2 ring-1 ring-rule",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-2xs tracking-wider text-steel uppercase",
						children: lang === "et" ? AGENT_META[entry.agent].et : AGENT_META[entry.agent].en
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-ink",
						children: entry.line
					})]
				}, entry.id))
			})] })
		]
	});
}
function Stat$2({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-w-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "font-mono text-2xs tracking-wider text-muted uppercase",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "mt-1 truncate font-medium tabular-nums",
			children: value
		})]
	});
}
var KEYS = [
	{
		k: "z",
		midi: 60,
		black: false
	},
	{
		k: "s",
		midi: 61,
		black: true
	},
	{
		k: "x",
		midi: 62,
		black: false
	},
	{
		k: "d",
		midi: 63,
		black: true
	},
	{
		k: "c",
		midi: 64,
		black: false
	},
	{
		k: "v",
		midi: 65,
		black: false
	},
	{
		k: "g",
		midi: 66,
		black: true
	},
	{
		k: "b",
		midi: 67,
		black: false
	},
	{
		k: "h",
		midi: 68,
		black: true
	},
	{
		k: "n",
		midi: 69,
		black: false
	},
	{
		k: "j",
		midi: 70,
		black: true
	},
	{
		k: "m",
		midi: 71,
		black: false
	}
];
function StudioKeys() {
	const last = useStudio((s) => s.lastNote);
	(0, import_react.useEffect)(() => {
		const down = /* @__PURE__ */ new Set();
		const onDown = (e) => {
			const tag = e.target?.tagName;
			if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return;
			if (e.repeat) return;
			const hit = KEYS.find((k) => k.k === e.key.toLowerCase());
			if (!hit) return;
			e.preventDefault();
			down.add(hit.k);
			sendNote$1(true, hit.midi);
		};
		const onUp = (e) => {
			const hit = KEYS.find((k) => k.k === e.key.toLowerCase());
			if (!hit) return;
			down.delete(hit.k);
			sendNote$1(false, hit.midi);
		};
		window.addEventListener("keydown", onDown);
		window.addEventListener("keyup", onUp);
		return () => {
			window.removeEventListener("keydown", onDown);
			window.removeEventListener("keyup", onUp);
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "mb-2 font-mono text-2xs tracking-wider text-muted uppercase",
		children: ["Lead · ", last]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative flex h-16 overflow-hidden rounded-[var(--radius-md)] ring-1 ring-rule",
		children: [KEYS.filter((k) => !k.black).map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "min-h-11 min-w-0 flex-1 border-r border-rule bg-ink text-paper last:border-r-0",
			onPointerDown: (e) => {
				e.preventDefault();
				sendNote$1(true, k.midi);
			},
			onPointerUp: () => sendNote$1(false, k.midi),
			onPointerLeave: () => sendNote$1(false, k.midi),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-mono text-2xs uppercase",
				children: k.k
			})
		}, k.k)), KEYS.filter((k) => k.black).map((k) => {
			const whites = KEYS.filter((x) => !x.black);
			const left = (whites.findIndex((w) => w.midi === k.midi - 1) + 1) / whites.length * 100;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: cn("absolute top-0 h-9 w-[7%] -translate-x-1/2 rounded-b-[var(--radius-sm)] bg-paper text-ink ring-1 ring-rule"),
				style: { left: `${left}%` },
				onPointerDown: (e) => {
					e.preventDefault();
					sendNote$1(true, k.midi);
				},
				onPointerUp: () => sendNote$1(false, k.midi),
				onPointerLeave: () => sendNote$1(false, k.midi)
			}, k.k);
		})]
	})] });
}
function LevelMeter({ peak, rms, vertical = false }) {
	const p = Math.min(1, peak);
	const r = Math.min(1, rms * 2.2);
	const clip = p > .95;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("relative overflow-hidden rounded-[var(--radius-xs)] bg-paper ring-1 ring-rule", vertical ? "h-28 w-2.5" : "h-2.5 w-full"),
		"aria-hidden": true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: cn("absolute bg-live/80", vertical ? "bottom-0 w-full" : "top-0 left-0 h-full"),
			style: vertical ? { height: `${r * 100}%` } : { width: `${r * 100}%` }
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: cn("absolute", clip ? "bg-clip" : "bg-ink", vertical ? "w-full" : "top-0 h-full"),
			style: vertical ? {
				bottom: `${p * 100}%`,
				height: 2
			} : {
				left: `${p * 100}%`,
				width: 2,
				height: "100%"
			}
		})]
	});
}
function DualMeter({ peak, mid, side }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid grid-cols-2 gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-1 font-mono text-2xs tracking-wider text-muted uppercase",
			children: "Mid"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LevelMeter, {
			peak,
			rms: mid
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-1 font-mono text-2xs tracking-wider text-muted uppercase",
			children: "Side"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LevelMeter, {
			peak,
			rms: side
		})] })]
	});
}
var GENRES = [
	"hardstyle",
	"rawstyle",
	"techno",
	"rap",
	"trap"
];
function StudioDesk() {
	const lang = useStudio((s) => s.lang);
	const genre = useStudio((s) => s.genre);
	const channels = useStudio((s) => s.channels);
	const steps = useStudio((s) => s.steps);
	const step = useStudio((s) => s.step);
	const playing = useStudio((s) => s.playing);
	const vocalName = useStudio((s) => s.vocalName);
	const beatName = useStudio((s) => s.beatName);
	const inputLive = useStudio((s) => s.inputLive);
	const master = useStudio((s) => s.master);
	const width = useStudio((s) => s.width);
	const drive = useStudio((s) => s.drive);
	const glue = useStudio((s) => s.glue);
	const swing = useStudio((s) => s.swing);
	const centerLock = useStudio((s) => s.centerLock);
	const peak = useStudio((s) => s.peak);
	const rms = useStudio((s) => s.rms);
	const setChannel = useStudio((s) => s.setChannel);
	const toggleStep = useStudio((s) => s.toggleStep);
	const patch = useStudio((s) => s.patch);
	const beatRef = (0, import_react.useRef)(null);
	const vocalRef = (0, import_react.useRef)(null);
	function applyMix() {
		pushAll();
	}
	async function onFile(kind, file) {
		if (!file) return;
		try {
			if (kind === "beat") await loadBeatFile(file);
			else await loadVocalFile(file);
			toast.success(file.name);
		} catch {
			toast.error(t(lang, "decodeFail"));
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-w-0 max-w-full flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-col gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-mono text-2xs tracking-[0.18em] text-muted uppercase",
						children: ["STEEL · ", t(lang, "desk")]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-3xl text-ink",
						children: "Kick in the center. Voice in the width."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-w-2xl text-pretty text-muted",
						children: lang === "et" ? "Neli-on-the-floor või rap-ruut. Üks puudutus käivitab kernel’i. Kick ja bass lukustuvad monosse; vokaal ja lead avanevad stereos." : "Four-on-the-floor or a rap grid. One tap arms the kernel. Kick and bass lock to mono-center; vocals and lead open in stereo."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "nav-scroll",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex w-max gap-2 pr-1",
					children: GENRES.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => {
							loadGenre(g);
							applyMix();
						},
						className: cn("min-h-11 shrink-0 rounded-[var(--radius-sm)] px-3 text-sm", genre === g ? "bg-ink text-paper" : "text-muted ring-1 ring-rule hover:text-ink"),
						children: [genreLabel(lang, g), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ml-2 font-mono text-2xs tabular-nums opacity-70",
							children: GENRE_META[g].bpm
						})]
					}, g))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "nav-scroll w-full min-w-0 max-w-full overflow-x-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex w-max gap-2 pr-1",
					children: CHANNELS.map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Strip, {
						id,
						label: channelLabel(lang, id),
						gain: channels[id].gain,
						mute: channels[id].mute,
						solo: channels[id].solo,
						pan: channels[id].pan,
						send: channels[id].send,
						peak: id === "kick" || id === "bass" ? peak : rms,
						onGain: (gain) => {
							setChannel(id, { gain });
							applyMix();
						},
						onMute: () => {
							setChannel(id, { mute: !channels[id].mute });
							applyMix();
						},
						onSolo: () => {
							setChannel(id, { solo: !channels[id].solo });
							applyMix();
						},
						onPan: (pan) => {
							setChannel(id, { pan });
							applyMix();
						},
						onSend: (send) => {
							setChannel(id, { send });
							applyMix();
						}
					}, id))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "min-w-0 rounded-[var(--radius-lg)] bg-raised p-3 ring-1 ring-rule sm:p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-3 font-mono text-2xs tracking-wider text-muted uppercase",
					children: "16-step"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex min-w-0 flex-col gap-1 overflow-x-auto",
					children: CHANNELS.filter((id) => id !== "vocal").map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "w-10 shrink-0 font-mono text-2xs tracking-wider text-muted uppercase",
							children: id
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid min-w-0 flex-1 grid-cols-16 gap-px",
							children: Array.from({ length: 16 }, (_, i) => {
								const on = (steps[id][i] ?? 0) > .2;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-pressed": on,
									onClick: () => {
										toggleStep(id, i);
										applyMix();
									},
									className: cn("h-8 min-h-8 rounded-[var(--radius-xs)] ring-1 ring-rule sm:h-9", on ? "bg-ink" : "bg-paper", playing && step === i && "ring-2 ring-live", i % 4 === 0 && !on && "bg-raised")
								}, i);
							})
						})]
					}, id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-[var(--radius-lg)] bg-raised p-4 ring-1 ring-rule",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-2xs tracking-wider text-muted uppercase",
							children: t(lang, "loadBeat")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 truncate text-sm text-ink",
							children: beatName ?? t(lang, "emptyVocal")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex flex-wrap gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "secondary",
								size: "sm",
								onClick: () => beatRef.current?.click(),
								children: t(lang, "loadBeat")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								ref: beatRef,
								type: "file",
								accept: "audio/*",
								className: "hidden",
								onChange: (e) => void onFile("beat", e.target.files?.[0])
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-[var(--radius-lg)] bg-raised p-4 ring-1 ring-rule",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-2xs tracking-wider text-muted uppercase",
							children: t(lang, "vocal")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 truncate text-sm text-ink",
							children: vocalName ?? t(lang, "emptyVocal")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex flex-wrap gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									variant: "secondary",
									size: "sm",
									onClick: () => vocalRef.current?.click(),
									children: t(lang, "loadVocal")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									variant: inputLive ? "live" : "secondary",
									size: "sm",
									onClick: () => void (inputLive ? stopMic() : startMic()),
									children: t(lang, "liveMic")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									ref: vocalRef,
									type: "file",
									accept: "audio/*",
									className: "hidden",
									onChange: (e) => void onFile("vocal", e.target.files?.[0])
								})
							]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fader, {
						label: t(lang, "master"),
						value: master,
						onChange: (v) => {
							patch({ master: v });
							applyMix();
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fader, {
						label: t(lang, "width"),
						value: width,
						onChange: (v) => {
							patch({ width: v });
							applyMix();
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fader, {
						label: t(lang, "drive"),
						value: drive,
						onChange: (v) => {
							patch({ drive: v });
							applyMix();
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fader, {
						label: t(lang, "glue"),
						value: glue,
						onChange: (v) => {
							patch({ glue: v });
							applyMix();
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fader, {
						label: t(lang, "swing"),
						value: swing,
						max: .4,
						onChange: (v) => {
							patch({ swing: v });
							applyMix();
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex min-h-11 items-center justify-between gap-3 rounded-[var(--radius-md)] px-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-2xs tracking-wider text-muted uppercase",
							children: t(lang, "center")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							role: "switch",
							"aria-checked": centerLock,
							onClick: () => {
								patch({ centerLock: !centerLock });
								applyMix();
							},
							className: cn("h-7 w-12 rounded-full ring-1 ring-rule transition-colors duration-[var(--motion-quick)]", centerLock ? "bg-live" : "bg-raised"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("block size-6 rounded-full bg-ink transition-transform duration-[var(--motion-quick)]", centerLock ? "translate-x-5" : "translate-x-0.5") })
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudioKeys, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-mono text-2xs tracking-wider text-muted uppercase",
				children: t(lang, "keys")
			})
		]
	});
}
function Strip({ id, label, gain, mute, solo, pan, send, peak, onGain, onMute, onSolo, onPan, onSend }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex w-20 shrink-0 flex-col items-center gap-2 rounded-[var(--radius-md)] bg-raised p-2 ring-1 ring-rule",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-mono text-2xs tracking-wider text-muted uppercase",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onMute,
					className: cn("h-9 min-w-9 rounded-[var(--radius-xs)] font-mono text-2xs uppercase ring-1 ring-rule", mute ? "bg-clip text-paper" : "text-muted"),
					children: "M"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onSolo,
					className: cn("h-9 min-w-9 rounded-[var(--radius-xs)] font-mono text-2xs uppercase ring-1 ring-rule", solo ? "bg-live text-paper" : "text-muted"),
					children: "S"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LevelMeter, {
				peak: peak * gain,
				rms: peak * gain * .6,
				vertical: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				type: "range",
				min: 0,
				max: 1,
				step: .01,
				value: gain,
				"aria-label": label,
				onChange: (e) => onGain(Number(e.target.value)),
				className: "steel-range"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				type: "range",
				min: -1,
				max: 1,
				step: .01,
				value: pan,
				"aria-label": `${label} pan`,
				onChange: (e) => onPan(Number(e.target.value)),
				className: "steel-range"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				type: "range",
				min: 0,
				max: 1,
				step: .01,
				value: send,
				"aria-label": `${label} send`,
				onChange: (e) => onSend(Number(e.target.value)),
				className: "steel-range"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "sr-only",
				children: id
			})
		]
	});
}
var MAP = {
	a: "open",
	ä: "open",
	á: "open",
	à: "open",
	â: "open",
	e: "wide",
	é: "wide",
	è: "wide",
	ê: "wide",
	ë: "wide",
	i: "teeth",
	í: "teeth",
	ï: "teeth",
	y: "teeth",
	o: "round",
	ö: "round",
	õ: "round",
	ó: "round",
	ò: "round",
	u: "round",
	ü: "round",
	ú: "round",
	ù: "round",
	m: "closed",
	b: "closed",
	p: "closed",
	f: "teeth",
	v: "teeth",
	w: "round",
	l: "teeth",
	r: "open",
	s: "teeth",
	š: "teeth",
	ß: "teeth",
	z: "teeth",
	ž: "teeth",
	t: "teeth",
	d: "teeth",
	n: "teeth",
	ñ: "teeth",
	k: "open",
	g: "open",
	h: "open",
	j: "wide",
	q: "round",
	x: "teeth",
	c: "teeth",
	" ": "rest",
	".": "rest",
	",": "rest",
	";": "rest",
	":": "rest",
	"!": "rest",
	"?": "rest",
	"¿": "rest",
	"¡": "rest",
	"\n": "rest",
	а: "open",
	я: "open",
	э: "wide",
	е: "wide",
	є: "wide",
	и: "teeth",
	ы: "teeth",
	й: "teeth",
	і: "teeth",
	ї: "teeth",
	о: "round",
	ё: "round",
	у: "round",
	ю: "round",
	б: "closed",
	п: "closed",
	м: "closed",
	в: "teeth",
	ф: "teeth",
	с: "teeth",
	з: "teeth",
	ц: "teeth",
	ш: "teeth",
	ж: "teeth",
	щ: "teeth",
	ч: "teeth",
	т: "teeth",
	д: "teeth",
	н: "teeth",
	л: "teeth",
	р: "open",
	к: "open",
	г: "open",
	ґ: "open",
	х: "open",
	ь: "rest",
	ъ: "rest"
};
function visemeAt(lyrics, t, bpm, rms) {
	const text = lyrics.trim();
	if (!text || rms < .02) return "rest";
	const chars = [...text.toLowerCase()];
	const spb = 60 / Math.max(60, bpm);
	const idx = Math.floor(t / (spb * .25) % chars.length);
	let v = MAP[chars[Math.max(0, idx)] ?? " "] ?? "open";
	if (rms > .28 && (v === "rest" || v === "closed")) v = "open";
	if (rms < .05) v = "closed";
	return v;
}
function visemePath(v) {
	switch (v) {
		case "closed": return {
			w: .42,
			h: .06,
			rx: .4
		};
		case "wide": return {
			w: .72,
			h: .16,
			rx: .5
		};
		case "round": return {
			w: .32,
			h: .32,
			rx: .5
		};
		case "teeth": return {
			w: .58,
			h: .12,
			rx: .2
		};
		case "open": return {
			w: .5,
			h: .38,
			rx: .45
		};
		default: return {
			w: .36,
			h: .08,
			rx: .5
		};
	}
}
function readTokens(el) {
	const s = getComputedStyle(el);
	const v = (name, fallback) => s.getPropertyValue(name).trim() || fallback;
	return {
		paper: v("--color-paper", "#0c0d0b"),
		raised: v("--color-raised", "#161714"),
		ink: v("--color-ink", "#e6e1d4"),
		muted: v("--color-muted", "#8a877c"),
		rule: v("--color-rule", "#2c2d28"),
		steel: v("--color-steel", "#8fa0ab"),
		live: v("--color-live", "#6aa56f"),
		clip: v("--color-clip", "#c45c4a"),
		copper: v("--color-copper", "#c47a4a")
	};
}
function hexToRgb(hex) {
	const raw = hex.trim();
	if (raw.startsWith("rgb")) {
		const m = raw.match(/[\d.]+/g);
		if (m && m.length >= 3) return [
			Number(m[0]),
			Number(m[1]),
			Number(m[2])
		];
	}
	const h = raw.replace("#", "");
	if (h.length === 3) {
		const n = parseInt(h.split("").map((c) => c + c).join(""), 16);
		return [
			n >> 16 & 255,
			n >> 8 & 255,
			n & 255
		];
	}
	if (h.length >= 6 && /^[0-9a-fA-F]+$/.test(h.slice(0, 6))) {
		const n = parseInt(h.slice(0, 6), 16);
		return [
			n >> 16 & 255,
			n >> 8 & 255,
			n & 255
		];
	}
	return [
		230,
		225,
		212
	];
}
function rgba(hex, a) {
	const [r, g, b] = hexToRgb(hex);
	return `rgba(${r},${g},${b},${a})`;
}
function drawVisualizer(opts) {
	const { canvas, freq, wave, tokens, style, genre, peak, step, playing, lyrics, still, t } = opts;
	const rms = opts.rms ?? peak;
	const bpm = opts.bpm ?? 140;
	const ctx = canvas.getContext("2d");
	if (!ctx) return;
	const dpr = Math.min(2, window.devicePixelRatio || 1);
	const w = canvas.clientWidth;
	const h = canvas.clientHeight;
	if (canvas.width !== Math.floor(w * dpr) || canvas.height !== Math.floor(h * dpr)) {
		canvas.width = Math.floor(w * dpr);
		canvas.height = Math.floor(h * dpr);
	}
	ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
	ctx.fillStyle = tokens.paper;
	ctx.fillRect(0, 0, w, h);
	if (still && still.complete && still.naturalWidth) {
		const scale = Math.max(w / still.naturalWidth, h / still.naturalHeight) * (1 + peak * .04);
		const dw = still.naturalWidth * scale;
		const dh = still.naturalHeight * scale;
		ctx.globalAlpha = .28 + peak * .22;
		ctx.drawImage(still, (w - dw) / 2, (h - dh) / 2, dw, dh);
		ctx.globalAlpha = 1;
	}
	const bass = avg(freq, 0, 8) / 255;
	const mid = avg(freq, 12, 40) / 255;
	const high = avg(freq, 60, 120) / 255;
	const resolved = style === "auto" ? genre === "rap" || genre === "trap" ? "scope" : genre === "techno" ? "tunnel" : "rings" : style;
	if (resolved === "tunnel") drawTunnel(ctx, w, h, tokens, bass, mid, t, playing);
	else if (resolved === "bars") drawBars(ctx, w, h, freq, tokens, peak);
	else if (resolved === "scope") drawScope(ctx, w, h, wave, tokens, bass);
	else if (resolved === "film") drawFilm(ctx, w, h, wave, tokens, lyrics, t, bpm, rms);
	else if (resolved === "lips") drawLips(ctx, w, h, tokens, lyrics, t, bpm, rms, peak);
	else drawRings(ctx, w, h, tokens, bass, mid, high, peak, t);
	drawSteelOverlay(ctx, w, h, tokens, step, peak, lyrics, playing);
}
function avg(arr, a, b) {
	const end = Math.min(arr.length, b);
	let s = 0;
	let n = 0;
	for (let i = a; i < end; i++) {
		s += arr[i];
		n++;
	}
	return n ? s / n : 0;
}
function drawRings(ctx, w, h, tokens, bass, mid, high, peak, t) {
	const cx = w / 2;
	const cy = h * .48;
	const maxR = Math.min(w, h) * .42;
	ctx.strokeStyle = rgba(tokens.rule, .9);
	ctx.lineWidth = 1;
	for (let i = 0; i < 7; i++) {
		const r = maxR * (.18 + i * .12) * (1 + bass * .18);
		ctx.beginPath();
		ctx.arc(cx, cy, r, 0, Math.PI * 2);
		ctx.stroke();
	}
	ctx.strokeStyle = rgba(tokens.steel, .85);
	ctx.lineWidth = 2;
	ctx.beginPath();
	ctx.arc(cx, cy, maxR * (.22 + bass * .55), 0, Math.PI * 2);
	ctx.stroke();
	ctx.strokeStyle = rgba(tokens.live, .55 + peak * .35);
	ctx.lineWidth = 1.5;
	ctx.beginPath();
	ctx.arc(cx, cy, maxR * (.4 + mid * .3), t * .4, t * .4 + Math.PI * (.8 + high));
	ctx.stroke();
	if (peak > .55) {
		ctx.fillStyle = rgba(tokens.ink, .04 + (peak - .55) * .08);
		ctx.fillRect(0, 0, w, h);
	}
}
function drawTunnel(ctx, w, h, tokens, bass, mid, t, playing) {
	const cx = w / 2;
	const cy = h / 2;
	const speed = playing ? t * (.6 + bass * 1.4) : t * .08;
	ctx.strokeStyle = rgba(tokens.steel, .55);
	ctx.lineWidth = 1;
	for (let i = 0; i < 14; i++) {
		const z = (i / 14 + speed) % 1;
		const s = .06 + z * 1.2;
		const rw = w * s * (.28 + bass * .12);
		const rh = h * s * (.22 + mid * .08);
		ctx.globalAlpha = .15 + z * .7;
		ctx.strokeRect(cx - rw / 2, cy - rh / 2, rw, rh);
	}
	ctx.globalAlpha = 1;
}
function drawBars(ctx, w, h, freq, tokens, peak) {
	const n = 48;
	const gap = 2;
	const bw = (w - 98) / n;
	for (let i = 0; i < n; i++) {
		const v = freq[Math.floor(i / n * freq.length * .7)] / 255;
		const bh = Math.max(2, v * (h * .72));
		ctx.fillStyle = i % 8 === 0 ? rgba(tokens.steel, .9) : rgba(tokens.ink, .55 + v * .35);
		ctx.fillRect(gap + i * (bw + gap), h - bh - 28, bw, bh);
	}
	ctx.fillStyle = rgba(tokens.live, .8);
	ctx.fillRect(0, 8, w * Math.min(1, peak), 3);
}
function drawScope(ctx, w, h, wave, tokens, bass) {
	ctx.strokeStyle = rgba(tokens.rule, .8);
	ctx.beginPath();
	ctx.moveTo(0, h / 2);
	ctx.lineTo(w, h / 2);
	ctx.stroke();
	ctx.strokeStyle = rgba(tokens.ink, .9);
	ctx.lineWidth = 1.5;
	ctx.beginPath();
	const n = wave.length;
	for (let i = 0; i < n; i++) {
		const x = i / (n - 1) * w;
		const y = h / 2 + (wave[i] - 128) / 128 * (h * .32) * (.7 + bass);
		if (i === 0) ctx.moveTo(x, y);
		else ctx.lineTo(x, y);
	}
	ctx.stroke();
}
var FILM_N = 1e3;
function resampleWave(wave, out) {
	const n = wave.length;
	if (n < 2) {
		out.fill(0);
		return;
	}
	for (let i = 0; i < out.length; i++) {
		const x = i / (out.length - 1) * (n - 1);
		const i0 = x | 0;
		const i1 = Math.min(n - 1, i0 + 1);
		out[i] = (wave[i0] * (1 - (x - i0)) + wave[i1] * (x - i0)) / 128 - 1;
	}
}
function drawFilm(ctx, w, h, wave, tokens, lyrics, t, bpm, rms) {
	const bins = new Float32Array(FILM_N);
	resampleWave(wave, bins);
	ctx.beginPath();
	ctx.strokeStyle = tokens.ink;
	ctx.lineWidth = 1.25;
	for (let i = 0; i < FILM_N; i++) {
		const x = i / 999 * w;
		const y = h * .62 + bins[i] * h * .18;
		if (i === 0) ctx.moveTo(x, y);
		else ctx.lineTo(x, y);
	}
	ctx.stroke();
	const mouth = visemePath(visemeAt(lyrics, t, bpm, rms));
	ctx.strokeStyle = tokens.live;
	ctx.lineWidth = 2;
	ctx.beginPath();
	ctx.ellipse(w / 2, h * .34, mouth.w * 70, mouth.h * 70, 0, 0, Math.PI * 2);
	ctx.stroke();
}
function drawLips(ctx, w, h, tokens, lyrics, t, bpm, rms, peak) {
	const vis = visemeAt(lyrics, t, bpm, rms);
	const mouth = visemePath(vis);
	const cx = w / 2;
	const cy = h * .48;
	const s = Math.min(w, h) * .42;
	ctx.strokeStyle = rgba(tokens.rule, .9);
	ctx.lineWidth = 1;
	ctx.beginPath();
	ctx.ellipse(cx, cy, s * .72, s * .55, 0, 0, Math.PI * 2);
	ctx.stroke();
	ctx.fillStyle = rgba(tokens.ink, .08 + peak * .12);
	ctx.beginPath();
	ctx.ellipse(cx, cy, mouth.w * s, mouth.h * s, 0, 0, Math.PI * 2);
	ctx.fill();
	ctx.strokeStyle = tokens.live;
	ctx.lineWidth = 2.5;
	ctx.stroke();
	ctx.fillStyle = tokens.muted;
	ctx.font = "11px IBM Plex Mono, ui-monospace, monospace";
	ctx.fillText(vis.toUpperCase(), 16, h - 36);
}
function drawSteelOverlay(ctx, w, h, tokens, step, peak, lyrics, playing) {
	ctx.strokeStyle = rgba(tokens.rule, .9);
	ctx.strokeRect(8, 8, w - 16, h - 16);
	ctx.fillStyle = tokens.muted;
	ctx.font = "11px IBM Plex Mono, ui-monospace, monospace";
	ctx.fillText(playing ? `STEP ${String(step + 1).padStart(2, "0")} / 16` : "IDLE", 16, 26);
	ctx.fillText(`${Math.round(peak * 100)}%`, w - 52, 26);
	if (lyrics) {
		const line = lyrics.split("\n")[0]?.slice(0, 64) ?? "";
		ctx.fillStyle = tokens.ink;
		ctx.font = "500 14px IBM Plex Sans Condensed, sans-serif";
		ctx.fillText(line, 16, h - 18);
	}
}
var N = 1e3;
function StudioFilm() {
	const lang = useStudio((s) => s.lang);
	const lyrics = useStudio((s) => s.lyrics);
	const bpm = useStudio((s) => s.bpm);
	const peak = useStudio((s) => s.peak);
	const canvasRef = (0, import_react.useRef)(null);
	const videoRef = (0, import_react.useRef)(null);
	const recRef = (0, import_react.useRef)(null);
	const [camOn, setCamOn] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		let raf = 0;
		const t0 = performance.now();
		const bins = new Float32Array(N);
		const loop = () => {
			const canvas = canvasRef.current;
			if (canvas) {
				const ctx = canvas.getContext("2d");
				const tap = getAnalyser();
				if (ctx) {
					const tokens = readTokens(document.documentElement);
					const dpr = Math.min(2, window.devicePixelRatio || 1);
					const w = canvas.clientWidth;
					const h = canvas.clientHeight;
					if (canvas.width !== Math.floor(w * dpr) || canvas.height !== Math.floor(h * dpr)) {
						canvas.width = Math.floor(w * dpr);
						canvas.height = Math.floor(h * dpr);
					}
					ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
					ctx.fillStyle = tokens.paper;
					ctx.fillRect(0, 0, w, h);
					const wave = tap?.wave;
					if (wave && wave.length > 1) for (let i = 0; i < N; i++) {
						const x = i / 999 * (wave.length - 1);
						const i0 = x | 0;
						const i1 = Math.min(wave.length - 1, i0 + 1);
						bins[i] = (wave[i0] * (1 - (x - i0)) + wave[i1] * (x - i0)) / 128 - 1;
					}
					ctx.beginPath();
					ctx.strokeStyle = tokens.ink;
					ctx.lineWidth = 1.25;
					for (let i = 0; i < N; i++) {
						const x = i / 999 * w;
						const y = h * .62 + bins[i] * h * .18;
						if (i === 0) ctx.moveTo(x, y);
						else ctx.lineTo(x, y);
					}
					ctx.stroke();
					const vid = videoRef.current;
					if (camOn && vid && vid.readyState >= 2) {
						const side = Math.min(w, h) * .42;
						ctx.globalAlpha = .88;
						ctx.drawImage(vid, (w - side) / 2, h * .08, side, side);
						ctx.globalAlpha = 1;
					}
					const vis = visemeAt(lyrics, (performance.now() - t0) / 1e3, bpm, peak);
					const mouth = visemePath(vis);
					const cx = w / 2;
					const cy = h * .36;
					ctx.strokeStyle = tokens.live;
					ctx.lineWidth = 2;
					ctx.beginPath();
					ctx.ellipse(cx, cy, mouth.w * 70, mouth.h * 70, 0, 0, Math.PI * 2);
					ctx.stroke();
					ctx.fillStyle = tokens.muted;
					ctx.font = "11px ui-monospace, Menlo, monospace";
					ctx.fillText(`STEEL FILM · ${N} · ${vis}`, 16, 22);
				}
			}
			raf = requestAnimationFrame(loop);
		};
		raf = requestAnimationFrame(loop);
		return () => cancelAnimationFrame(raf);
	}, [
		bpm,
		camOn,
		lyrics,
		peak
	]);
	async function onCam() {
		if (camOn) {
			(videoRef.current?.srcObject)?.getTracks().forEach((tr) => tr.stop());
			if (videoRef.current) videoRef.current.srcObject = null;
			setCamOn(false);
			return;
		}
		try {
			const stream = await navigator.mediaDevices.getUserMedia({
				video: { facingMode: "user" },
				audio: false
			});
			if (videoRef.current) {
				videoRef.current.srcObject = stream;
				await videoRef.current.play();
			}
			setCamOn(true);
		} catch {
			toast.error(t(lang, "decodeFail"));
		}
	}
	function onRecord() {
		const canvas = canvasRef.current;
		if (!canvas) return;
		if (recRef.current && recRef.current.state === "recording") {
			recRef.current.stop();
			return;
		}
		const stream = canvas.captureStream(30);
		const rec = new MediaRecorder(stream, { mimeType: "video/webm" });
		const chunks = [];
		rec.ondataavailable = (e) => {
			if (e.data.size) chunks.push(e.data);
		};
		rec.onstop = () => {
			downloadBlob(new Blob(chunks, { type: "video/webm" }), "steel-film.webm");
			recRef.current = null;
		};
		rec.start();
		recRef.current = rec;
		toast.message(t(lang, "recordFilm"));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-w-0 flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-col gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-2xs tracking-[0.18em] text-muted uppercase",
						children: t(lang, "filmKicker")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-3xl text-ink",
						children: t(lang, "filmTitle")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-w-2xl text-pretty text-muted",
						children: t(lang, "filmLead")
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative min-w-0 overflow-hidden rounded-[var(--radius-lg)] bg-raised ring-1 ring-rule",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
					ref: canvasRef,
					className: "block h-[52vh] w-full min-h-64"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
					ref: videoRef,
					className: "pointer-events-none absolute h-0 w-0 opacity-0",
					playsInline: true,
					muted: true
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "secondary",
						onClick: () => void onCam(),
						children: t(lang, "cam")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "secondary",
						onClick: onRecord,
						children: t(lang, "recordFilm")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "live",
						onClick: () => downloadFilmPack(),
						children: t(lang, "downloadPack")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "secondary",
						onClick: () => void import("./xlsx-banks-cWYCCkvt.mjs").then((m) => m.exportBankBook()),
						children: t(lang, "downloadXlsx")
					})
				]
			})
		]
	});
}
var BUFFER_SIZES = [
	64,
	128,
	256,
	512,
	1024,
	2048
];
var SAMPLE_RATES = [
	44100,
	48e3,
	88200,
	96e3
];
var ASIO4ALL_VERSION = "2.22";
function roundTripMs(buffer, rate, extraBuffers = 2) {
	return buffer / rate * extraBuffers * 1e3;
}
function asioClass(rtl) {
	if (rtl <= 8) return "Tracking";
	if (rtl <= 16) return "Mixing";
	if (rtl <= 32) return "Producing";
	return "Playback";
}
var OS_MATRIX = [
	{
		id: "win8",
		label: "Windows 8 / 8.1",
		driver: `ASIO4ALL ${ASIO4ALL_VERSION}`,
		note: "Confirmed by Michael Tippach. Minor GUI artefacts. Use 48 kHz / 256 if USB devices drop."
	},
	{
		id: "win10",
		label: "Windows 10",
		driver: `ASIO4ALL ${ASIO4ALL_VERSION}`,
		note: "Official floor for the 2.21 installer. Enable the device in the WDM list, hardware buffer off unless the vendor driver is stable."
	},
	{
		id: "win11",
		label: "Windows 11 / ARM64",
		driver: `ASIO4ALL ${ASIO4ALL_VERSION}`,
		note: "2.22 adds native and EC ARM64, including USB Audio Class devices without vendor drivers."
	},
	{
		id: "linux",
		label: "Linux (Wine 7.5+ / PipeWire)",
		driver: "PipeASIO · JACK2 · ALSA",
		note: "No kernel ASIO. PipeWire 0.3+ or JACK is the low-latency path. Wine 7.5+ runs FL / Live; Ableton-Linux uses PipeASIO so Link can arm."
	}
];
var handle = null;
function addonFlag(id) {
	return useSteel.getState().addons[id] ? 1 : 0;
}
function currentParams() {
	const s = useSteel.getState();
	return {
		inGain: s.inGain,
		outGain: s.outGain,
		master: s.master,
		hpf: addonFlag("hpf"),
		hpHz: s.hpHz,
		eqLo: s.eqLo,
		eqMid: s.eqMid,
		eqHi: s.eqHi,
		sat: addonFlag("sat"),
		satAmt: s.satAmt,
		comp: addonFlag("comp"),
		thresh: s.thresh,
		limit: addonFlag("limit"),
		synth: addonFlag("synth"),
		transient: addonFlag("transient"),
		transAmt: s.transAmt
	};
}
function pushParams() {
	handle?.node.port.postMessage({
		type: "params",
		params: currentParams()
	});
}
function sendNote(on, note, vel = .8) {
	handle?.node.port.postMessage({
		type: on ? "noteOn" : "noteOff",
		note,
		vel
	});
}
async function playNote(on, note, vel = .85) {
	if (!useSteel.getState().armed) {
		if (!on) return;
		try {
			await armKernel();
		} catch {
			return;
		}
		if (!useSteel.getState().armed) return;
	}
	sendNote(on, note, vel);
}
function panic() {
	handle?.node.port.postMessage({ type: "panic" });
}
async function tryMic(ctx, node) {
	if (!navigator.mediaDevices?.getUserMedia) return {
		mic: null,
		stream: null
	};
	try {
		const stream = await Promise.race([navigator.mediaDevices.getUserMedia({ audio: {
			echoCancellation: false,
			noiseSuppression: false,
			autoGainControl: false,
			channelCount: 1
		} }), new Promise((_, reject) => {
			setTimeout(() => reject(/* @__PURE__ */ new Error("mic-timeout")), 900);
		})]);
		const mic = ctx.createMediaStreamSource(stream);
		mic.connect(node);
		return {
			mic,
			stream
		};
	} catch {
		return {
			mic: null,
			stream: null
		};
	}
}
async function armKernel() {
	const { sampleRate, kernel, webOut, patch } = useSteel.getState();
	if (handle) await disarmKernel();
	const hint = policyFor(probeSignal().path).latencyHint;
	const ctx = new AudioContext({
		sampleRate,
		latencyHint: hint
	});
	await ctx.audioWorklet.addModule(`/worklets/steel-kernel.js?k=${encodeURIComponent(kernel)}`);
	const node = new AudioWorkletNode(ctx, "steel-kernel", {
		numberOfInputs: 1,
		numberOfOutputs: 1,
		outputChannelCount: [2]
	});
	const master = ctx.createGain();
	master.gain.value = 1;
	const dest = ctx.createMediaStreamDestination();
	node.connect(master);
	master.connect(ctx.destination);
	if (webOut) master.connect(dest);
	node.port.onmessage = (ev) => {
		const data = ev.data;
		if (data?.type !== "meter") return;
		useSteel.getState().patch({
			peak: data.peak ?? 0,
			rms: data.rms ?? 0,
			voices: data.voices ?? 0,
			cpu: Math.min(100, (data.peak ?? 0) * 40 + (data.voices ?? 0) * 3)
		});
	};
	const { mic, stream } = await tryMic(ctx, node);
	handle = {
		ctx,
		node,
		master,
		dest,
		mic,
		stream,
		destOn: webOut
	};
	node.port.postMessage({
		type: "params",
		params: currentParams()
	});
	await ctx.resume();
	patch({
		armed: true,
		running: ctx.state === "running",
		error: null,
		inputLive: Boolean(stream)
	});
}
async function disarmKernel() {
	if (!handle) {
		useSteel.getState().patch({
			armed: false,
			running: false,
			inputLive: false
		});
		return;
	}
	try {
		handle.node.port.onmessage = null;
		handle.node.disconnect();
		handle.master.disconnect();
		handle.mic?.disconnect();
		handle.stream?.getTracks().forEach((t) => t.stop());
		await handle.ctx.close();
	} catch {}
	handle = null;
	useSteel.getState().patch({
		armed: false,
		running: false,
		peak: 0,
		rms: 0,
		voices: 0,
		cpu: 0,
		inputLive: false
	});
}
async function toggleKernel() {
	if (useSteel.getState().armed) await disarmKernel();
	else await armKernel();
}
function measuredLatencyMs() {
	if (!handle) return null;
	const { ctx } = handle;
	return ((ctx.baseLatency || 0) + (ctx.outputLatency || 0)) * 1e3;
}
var access = null;
var boundIn = null;
var KEY_LABEL = Object.fromEntries(Object.entries({
	a: 60,
	w: 61,
	s: 62,
	e: 63,
	d: 64,
	f: 65,
	t: 66,
	g: 67,
	y: 68,
	h: 69,
	u: 70,
	j: 71,
	k: 72
}).map(([k, n]) => [n, k.toUpperCase()]));
var NAMES = [
	"C",
	"C#",
	"D",
	"D#",
	"E",
	"F",
	"F#",
	"G",
	"G#",
	"A",
	"A#",
	"B"
];
function noteLabel(note) {
	return `${NAMES[note % 12]}${Math.floor(note / 12) - 1}`;
}
function listPorts(a) {
	const ports = [];
	a.inputs.forEach((p) => {
		ports.push({
			id: p.id,
			name: p.name || "MIDI in",
			manufacturer: p.manufacturer || "",
			type: "in"
		});
	});
	a.outputs.forEach((p) => {
		ports.push({
			id: p.id,
			name: p.name || "MIDI out",
			manufacturer: p.manufacturer || "",
			type: "out"
		});
	});
	return ports;
}
function onMidi(ev) {
	const data = ev.data;
	if (!data || data.length < 1) return;
	const status = data[0] & 240;
	const note = data[1] ?? 0;
	const vel = (data[2] ?? 0) / 127;
	if (status === 144 && vel > 0) {
		sendNote(true, note, vel);
		useSteel.getState().patch({ lastNote: `${noteLabel(note)} · ${Math.round(vel * 127)}` });
	} else if (status === 128 || status === 144 && vel === 0) sendNote(false, note);
	else if (status === 176) {
		const cc = data[1];
		const v = (data[2] ?? 0) / 127;
		const patch = useSteel.getState().patch;
		useSteel.getState().patch({ lastCc: `CC ${cc} · ${Math.round(v * 127)}` });
		if (cc === 7) patch({ master: v });
		else if (cc === 1) patch({ satAmt: v });
		else if (cc === 10) patch({ inGain: .2 + v * 1.8 });
		else if (cc === 74 || cc === 19) patch({ eqHi: .4 + v * 1.4 });
		else if (cc === 71 || cc === 18) patch({ eqMid: .4 + v * 1.4 });
		else if (cc === 17) patch({ eqLo: .4 + v * 1.4 });
		else if (cc === 16) patch({ thresh: .1 + v * .7 });
		else if (cc === 76) patch({ hpHz: 30 + v * 370 });
	}
}
async function enableMidi() {
	if (!navigator.requestMIDIAccess) return;
	access = await navigator.requestMIDIAccess({ sysex: false });
	useSteel.getState().patch({ midiPorts: listPorts(access) });
	access.onstatechange = () => {
		if (access) useSteel.getState().patch({ midiPorts: listPorts(access) });
	};
	const firstIn = [...access.inputs.values()][0];
	if (firstIn) selectMidiIn(firstIn.id);
}
function selectMidiIn(id) {
	if (boundIn) {
		boundIn.onmidimessage = null;
		boundIn = null;
	}
	useSteel.getState().patch({ midiIn: id });
	if (!id || !access) return;
	const port = access.inputs.get(id);
	if (!port) return;
	boundIn = port;
	port.onmidimessage = onMidi;
}
function versionGte(a, b) {
	const pa = a.split(".").map((n) => Number(n) || 0);
	const pb = b.split(".").map((n) => Number(n) || 0);
	for (let i = 0; i < 3; i++) {
		if ((pa[i] ?? 0) > (pb[i] ?? 0)) return true;
		if ((pa[i] ?? 0) < (pb[i] ?? 0)) return false;
	}
	return true;
}
async function fetchManifest() {
	const res = await fetch(`/kernel/manifest.json?t=${Date.now()}`, {
		cache: "no-store",
		signal: AbortSignal.timeout(4e3)
	});
	if (!res.ok) throw new Error("Kernel channel unreachable");
	return await res.json();
}
async function checkChannel() {
	const man = await fetchManifest();
	useSteel.getState().patch({ latest: man.latest });
	return man;
}
async function applyKernel(version) {
	const s = useSteel.getState();
	s.patch({
		updating: true,
		error: null
	});
	try {
		const man = await fetchManifest();
		const nextAddons = { ...s.addons };
		for (const addon of man.addons) if (!versionGte(version, addon.minKernel)) nextAddons[addon.id] = false;
		else if (addon.id === "transient") nextAddons[addon.id] = true;
		s.patch({
			kernel: version,
			addons: nextAddons,
			latest: man.latest,
			updating: false
		});
		if (s.armed) await armKernel();
	} catch (err) {
		s.patch({
			updating: false,
			error: err instanceof Error ? err.message : "Update failed"
		});
	}
}
var WHITE = [
	0,
	2,
	4,
	5,
	7,
	9,
	11
];
var NOTES = [
	"C",
	"C#",
	"D",
	"D#",
	"E",
	"F",
	"F#",
	"G",
	"G#",
	"A",
	"A#",
	"B"
];
var LOW = 48;
var HIGH = 72;
function SteelConsole() {
	const s = useSteel();
	const rtl = roundTripMs(s.buffer, s.sampleRate);
	const measured = s.armed ? measuredLatencyMs() : null;
	const transOn = Boolean(s.addons.transient) && versionGte(s.kernel, "3.5.0");
	(0, import_react.useEffect)(() => {
		if (s.armed) pushParams();
	}, [
		s.armed,
		s.inGain,
		s.outGain,
		s.master,
		s.hpHz,
		s.eqLo,
		s.eqMid,
		s.eqHi,
		s.satAmt,
		s.thresh,
		s.transAmt,
		s.addons
	]);
	async function arm() {
		try {
			await toggleKernel();
			if (!useSteel.getState().armed) return;
			toast.success(t$1(useSteel.getState().lang, "armOk"));
			try {
				await enableMidi();
			} catch {}
		} catch (err) {
			toast.error(err instanceof Error ? err.message : t$1(useSteel.getState().lang, "armFail"));
		}
	}
	const peakDb = s.peak > 0 ? (20 * Math.log10(s.peak)).toFixed(1) : "-∞";
	const clip = s.peak > .95;
	const klass = asioClass(rtl);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-8 lg:grid-cols-[minmax(0,1.15fr)_minmax(0,0.85fr)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "min-w-0",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-2xs tracking-[0.2em] text-steel uppercase",
					children: t$1(s.lang, "consoleKicker")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 text-3xl sm:text-4xl",
					children: t$1(s.lang, "consoleTitle")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 max-w-prose text-sm leading-relaxed text-muted",
					children: t$1(s.lang, "consoleLead")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 flex flex-wrap items-center gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: s.armed ? "stamp" : "live",
							onClick: () => void arm(),
							children: s.armed ? t$1(s.lang, "disarm") : t$1(s.lang, "armKernel")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "secondary",
							disabled: !s.armed,
							onClick: () => panic(),
							children: t$1(s.lang, "panic")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-2xs text-muted",
							children: s.armed ? s.inputLive ? t$1(s.lang, "runningLive") : t$1(s.lang, "runningKeys") : t$1(s.lang, "armHint")
						})
					]
				}),
				s.error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-clip",
					children: s.error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 grid grid-cols-2 gap-3 sm:grid-cols-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat$1, {
							label: "Buffer",
							value: `${s.buffer}`,
							unit: "samples"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat$1, {
							label: "Rate",
							value: `${s.sampleRate / 1e3}`,
							unit: "kHz"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat$1, {
							label: "ASIO RTL",
							value: rtl.toFixed(1),
							unit: "ms"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat$1, {
							label: "Measured",
							value: measured != null ? measured.toFixed(1) : "—",
							unit: "ms"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 font-mono text-2xs text-faint",
					children: [
						"Class ",
						klass,
						" · extra buffers 2 (ASIO4ALL model)"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 grid gap-4 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-2xs tracking-wider text-muted uppercase",
							children: "Buffer"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: "mt-1 h-11 w-full rounded-[var(--radius-md)] border border-rule bg-raised px-3 text-sm",
							value: s.buffer,
							onChange: (e) => s.patch({ buffer: Number(e.target.value) }),
							children: BUFFER_SIZES.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: n,
								children: n
							}, n))
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-2xs tracking-wider text-muted uppercase",
							children: "Sample rate"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: "mt-1 h-11 w-full rounded-[var(--radius-md)] border border-rule bg-raised px-3 text-sm",
							value: s.sampleRate,
							onChange: (e) => s.patch({ sampleRate: Number(e.target.value) }),
							children: SAMPLE_RATES.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
								value: n,
								children: [n / 1e3, " kHz"]
							}, n))
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-xs text-muted",
					children: "Re-arm after changing rate. Buffer size here is the host ASIO figure; the worklet quantum stays 128."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-2xs tracking-wider text-muted uppercase",
							children: "MIDI poly · C3–C5 · A–K is C4–C5"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Piano, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 font-mono text-2xs text-muted",
							children: [
								"Last ",
								s.lastNote,
								" · ",
								s.lastCc
							]
						})
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "rounded-[var(--radius-lg)] border border-rule bg-raised/60 p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-2xs tracking-wider text-muted uppercase",
					children: "Meters"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex items-end gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
							label: "Peak",
							value: s.peak,
							clip
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
							label: "RMS",
							value: Math.min(1, s.rms * 2.2),
							clip: false
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "pb-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: cn("font-mono text-3xl tabular-nums", clip ? "text-clip" : "text-ink"),
									children: peakDb
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-mono text-2xs text-muted",
									children: "dBFS"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-3 font-mono text-2xs text-muted",
									children: [
										"Voices ",
										s.voices,
										" · load ",
										s.cpu.toFixed(0),
										"%"
									]
								})
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
							label: "Input",
							value: s.inGain,
							min: 0,
							max: 2,
							onChange: (v) => s.patch({ inGain: v })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
							label: "Master",
							value: s.master,
							min: 0,
							max: 1.2,
							onChange: (v) => s.patch({ master: v })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
							label: "HP Hz",
							value: s.hpHz,
							min: 20,
							max: 400,
							onChange: (v) => s.patch({ hpHz: v })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
							label: "Lo",
							value: s.eqLo,
							min: .2,
							max: 2,
							onChange: (v) => s.patch({ eqLo: v })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
							label: "Mid",
							value: s.eqMid,
							min: .2,
							max: 2,
							onChange: (v) => s.patch({ eqMid: v })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
							label: "Hi",
							value: s.eqHi,
							min: .2,
							max: 2,
							onChange: (v) => s.patch({ eqHi: v })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
							label: "Sat",
							value: s.satAmt,
							min: 0,
							max: 1,
							onChange: (v) => s.patch({ satAmt: v })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
							label: "Thresh",
							value: s.thresh,
							min: .05,
							max: .9,
							onChange: (v) => s.patch({ thresh: v })
						}),
						transOn ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
							label: "Transient",
							value: s.transAmt,
							min: 0,
							max: 1,
							onChange: (v) => s.patch({ transAmt: v })
						}) : null
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-2xs tracking-wider text-muted uppercase",
							children: "MIDI in"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: "mt-1 h-11 w-full rounded-[var(--radius-md)] border border-rule bg-paper px-3 text-sm",
							value: s.midiIn ?? "",
							onChange: (e) => selectMidiIn(e.target.value || null),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "Computer keyboard (A–K)"
							}), s.midiPorts.filter((p) => p.type === "in").map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: p.id,
								children: p.name
							}, p.id))]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "secondary",
							size: "sm",
							className: "mt-2",
							onClick: () => void enableMidi(),
							children: "Scan MIDI"
						})
					]
				})
			]
		})]
	});
}
function Piano() {
	const [held, setHeld] = (0, import_react.useState)(() => /* @__PURE__ */ new Set());
	const pointerHeld = (0, import_react.useRef)(/* @__PURE__ */ new Set());
	const whites = [];
	const blacks = [];
	for (let n = LOW; n <= HIGH; n++) if (WHITE.includes(n % 12)) whites.push(n);
	else blacks.push(n);
	function down(note) {
		setHeld((prev) => new Set(prev).add(note));
		const pc = note % 12;
		useSteel.getState().patch({ lastNote: `${NOTES[pc]}${Math.floor(note / 12) - 1}` });
		playNote(true, note, .85);
	}
	function up(note) {
		setHeld((prev) => {
			const next = new Set(prev);
			next.delete(note);
			return next;
		});
		playNote(false, note);
	}
	function tap(note) {
		if (pointerHeld.current.has(note)) return;
		down(note);
		window.setTimeout(() => up(note), 280);
	}
	function blackLeft(note) {
		const pc = note % 12;
		return (Math.floor((note - LOW) / 12) * 7 + ({
			1: .72,
			3: 1.72,
			6: 3.72,
			8: 4.72,
			10: 5.72
		}[pc] ?? 0)) / whites.length * 100;
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-3 overflow-x-auto overscroll-x-contain",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative h-36 w-[32rem] max-w-none sm:w-[36rem]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 flex overflow-hidden rounded-[var(--radius-md)] border border-rule",
				children: whites.map((note) => {
					const pc = note % 12;
					const on = held.has(note);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": `${NOTES[pc]}${Math.floor(note / 12) - 1}`,
						className: cn("relative h-full flex-1 border-r border-rule last:border-r-0", on ? "bg-live text-paper" : "bg-ink text-paper"),
						onPointerDown: (e) => {
							e.currentTarget.setPointerCapture(e.pointerId);
							pointerHeld.current.add(note);
							down(note);
						},
						onPointerUp: () => {
							pointerHeld.current.delete(note);
							up(note);
						},
						onPointerCancel: () => {
							pointerHeld.current.delete(note);
							up(note);
						},
						onClick: () => tap(note),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "absolute bottom-2 left-0 right-0 text-center font-mono text-2xs text-paper/70",
							children: KEY_LABEL[note] ?? (pc === 0 ? `C${Math.floor(note / 12) - 1}` : "")
						})
					}, note);
				})
			}), blacks.map((note) => {
				const pc = note % 12;
				const on = held.has(note);
				const w = .58 / whites.length * 100;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": `${NOTES[pc]}${Math.floor(note / 12) - 1}`,
					style: {
						left: `calc(${blackLeft(note)}% + 0.15%)`,
						width: `${w}%`
					},
					className: cn("absolute top-0 z-10 h-[58%] rounded-b-[var(--radius-sm)] border border-rule", on ? "bg-live" : "bg-paper"),
					onPointerDown: (e) => {
						e.preventDefault();
						e.currentTarget.setPointerCapture(e.pointerId);
						pointerHeld.current.add(note);
						down(note);
					},
					onPointerUp: () => {
						pointerHeld.current.delete(note);
						up(note);
					},
					onPointerCancel: () => {
						pointerHeld.current.delete(note);
						up(note);
					},
					onClick: () => tap(note),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "sr-only",
						children: KEY_LABEL[note]
					})
				}, note);
			})]
		})
	});
}
function Stat$1({ label, value, unit }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-[var(--radius-md)] border border-rule bg-raised/40 px-3 py-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-mono text-2xs tracking-wider text-muted uppercase",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 font-display text-2xl tabular-nums leading-none",
				children: value
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 font-mono text-2xs text-faint",
				children: unit
			})
		]
	});
}
function Meter({ label, value, clip }) {
	const h = Math.min(1, Math.max(0, value));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col items-center gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "relative h-40 w-8 overflow-hidden rounded-[var(--radius-sm)] border border-rule bg-paper",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: cn("absolute inset-x-0 bottom-0", clip ? "bg-clip" : "bg-live"),
				style: { height: `${h * 100}%` }
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-mono text-2xs tracking-wider text-muted uppercase",
			children: label
		})]
	});
}
function Slider({ label, value, min, max, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "flex justify-between font-mono text-2xs text-muted",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "tracking-wider uppercase",
				children: label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "tabular-nums text-ink",
				children: value.toFixed(2)
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			type: "range",
			min,
			max,
			step: (max - min) / 200,
			value,
			onChange: (e) => onChange(Number(e.target.value)),
			className: "mt-1 w-full accent-live"
		})]
	});
}
var HOSTS$1 = [
	{
		id: "fl",
		name: "FL Studio",
		since: "20.8 MIDI engine (the line you called FL 17+) · 21+ current",
		clock: "Link optional · internal 24 ppq",
		midi: [
			"Options → MIDI → Enable MIDI input / output",
			"Controller type: generic controller. Sync: send MIDI clock if Steel is master",
			"Route Steel MIDI Out to an FL input (loopMIDI on Windows, a2jmidid on Linux)",
			"Mixer: insert Steel as an audio input via ASIO4ALL / PipeASIO, not WASAPI shared"
		],
		steps: [
			"Install ASIO4ALL 2.22 (Windows) or PipeWire JACK (Linux).",
			"Audio settings → Device: ASIO4ALL v2 / PipeASIO. Buffer 128–256 at 48 kHz.",
			"Create a loopback MIDI port named STEEL.",
			"In Steel, pick that port. Notes hit MIDI poly; clock follows the transport."
		],
		map: [
			{
				cc: 1,
				dest: "Mod → sat amount"
			},
			{
				cc: 7,
				dest: "Master"
			},
			{
				cc: 10,
				dest: "Input trim"
			},
			{
				cc: 74,
				dest: "EQ high"
			},
			{
				cc: 71,
				dest: "EQ mid"
			},
			{
				cc: 76,
				dest: "High-pass Hz"
			}
		]
	},
	{
		id: "ableton",
		name: "Ableton Live 12",
		since: "Live 12.0 · Extensions SDK 12.4.5+",
		clock: "Ableton Link when the host is on ASIO / PipeASIO",
		midi: [
			"Settings → Link, Tempo & MIDI → MIDI Ports: track / sync in+out on the STEEL port",
			"Control Surface: None (Steel speaks CCs) or a generated v3 remote script",
			"Extensions SDK (Suite 12.4.5+) can open Steel as a right-click tool; MIDI still carries transport",
			"Linux: enable Link only after PipeASIO is the audio device"
		],
		steps: [
			"Audio → Driver Type: ASIO. Device: ASIO4ALL v2 (Win) or PipeASIO (Linux).",
			"Buffer 128 at 48 kHz for tracking; 256 for large sessions.",
			"Arm Link if other peers need the same clock. Steel follows MIDI clock when present.",
			"Map CCs below — Steel applies them live on the kernel."
		],
		map: [
			{
				cc: 1,
				dest: "Mod → sat amount"
			},
			{
				cc: 7,
				dest: "Master"
			},
			{
				cc: 16,
				dest: "Compressor threshold"
			},
			{
				cc: 17,
				dest: "EQ low"
			},
			{
				cc: 18,
				dest: "EQ mid"
			},
			{
				cc: 19,
				dest: "EQ high"
			}
		]
	},
	{
		id: "generic",
		name: "Any ASIO host",
		since: "ASIO 2.x · Reaper, Bitwig, Cubase, Studio One, Mixbus",
		clock: "MIDI clock in · Link only if the host is on ASIO / PipeASIO",
		midi: [
			"Create a loopback port named STEEL (loopMIDI, rtpMIDI, or a2jmidid)",
			"Enable that port as a MIDI input on Steel and as an output in the host",
			"Do not use WASAPI / DirectSound / Pulse shared mode for the round-trip"
		],
		steps: [
			"Windows: ASIO4ALL 2.22 as the device if the interface has no vendor ASIO.",
			"Linux: PipeWire JACK or PipeASIO. Wine 7.5+ for Windows-only hosts.",
			"Match sample rate with Steel (48 kHz default). Buffer 128–256.",
			"Send notes and CCs to Steel; tap Web out if another page needs the stream."
		],
		map: [
			{
				cc: 1,
				dest: "Mod → sat amount"
			},
			{
				cc: 7,
				dest: "Master"
			},
			{
				cc: 10,
				dest: "Input trim"
			},
			{
				cc: 16,
				dest: "Compressor threshold"
			}
		]
	}
];
function SteelHosts() {
	const host = useSteel((s) => s.host);
	const os = useSteel((s) => s.os);
	const patch = useSteel((s) => s.patch);
	const profile = HOSTS$1.find((h) => h.id === host) ?? HOSTS$1[0];
	const osRow = OS_MATRIX.find((o) => o.id === os) ?? OS_MATRIX[1];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-10 lg:grid-cols-[minmax(0,0.9fr)_minmax(0,1.1fr)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "min-w-0",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-2xs tracking-[0.2em] text-steel uppercase",
					children: "Local hosts"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-2 text-3xl",
					children: "FL Studio and Live 12, on the OS you actually boot."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-5 flex flex-wrap gap-2",
					children: HOSTS$1.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => patch({ host: h.id }),
						className: cn("min-h-11 rounded-[var(--radius-sm)] border px-3 py-2 text-sm", host === h.id ? "border-ink bg-ink text-paper" : "border-rule text-muted hover:text-ink"),
						children: h.name
					}, h.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-sm text-muted",
					children: profile.since
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: profile.clock
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-6 space-y-3",
					children: profile.steps.map((step, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "border-t border-rule pt-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-2xs text-steel",
							children: String(i + 1).padStart(2, "0")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm",
							children: step
						})]
					}, step))
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-mono text-2xs tracking-[0.2em] text-muted uppercase",
				children: "Operating system"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 flex flex-wrap gap-2",
				children: OS_MATRIX.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => patch({ os: row.id }),
					className: cn("min-h-11 rounded-[var(--radius-sm)] border px-3 py-2 text-sm", os === row.id ? "border-ink bg-ink text-paper" : "border-rule text-muted hover:text-ink"),
					children: row.label
				}, row.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 rounded-[var(--radius-md)] border border-rule bg-raised/50 p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-2xs tracking-wider text-live uppercase",
					children: osRow.driver
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm leading-relaxed text-muted",
					children: osRow.note
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 font-mono text-2xs tracking-wider text-muted uppercase",
				children: "CC map"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("table", {
				className: "mt-2 w-full text-sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: profile.map.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-b border-rule/80",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
						className: "py-2 font-mono text-steel",
						children: ["CC ", row.cc]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "py-2 text-muted",
						children: row.dest
					})]
				}, row.cc)) })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-6 space-y-2 text-sm text-muted",
				children: profile.midi.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: line }, line))
			})
		] })]
	});
}
function SteelKernel() {
	const kernel = useSteel((s) => s.kernel);
	const latest = useSteel((s) => s.latest);
	const updating = useSteel((s) => s.updating);
	const addons = useSteel((s) => s.addons);
	const [man, setMan] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		checkChannel().then(setMan).catch((err) => toast.error(err instanceof Error ? err.message : "Channel down"));
	}, []);
	const behind = latest != null && !versionGte(kernel, latest);
	async function apply() {
		if (!latest) return;
		await applyKernel(latest);
		toast.success(`Kernel ${latest} on this host`);
		const next = await checkChannel();
		setMan(next);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-10 lg:grid-cols-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-mono text-2xs tracking-[0.2em] text-steel uppercase",
				children: "Update channel"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
				className: "mt-2 text-3xl",
				children: ["Kernel ", kernel]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 text-sm text-muted",
				children: [
					"Channel ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-ink",
						children: man?.channel ?? "stable"
					}),
					". ASIO4ALL target",
					" ",
					man?.asio4all ?? "2.22",
					". The worklet reloads when you apply a version — same contract a host would use for add-on reform."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "mt-6 grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-[var(--radius-md)] border border-rule px-3 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "font-mono text-2xs tracking-wider text-muted uppercase",
						children: "Running"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "mt-1 font-display text-2xl",
						children: kernel
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-[var(--radius-md)] border border-rule px-3 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "font-mono text-2xs tracking-wider text-muted uppercase",
						children: "Channel latest"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "mt-1 font-display text-2xl",
						children: latest ?? "—"
					})]
				})]
			}),
			man?.hosts ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4 font-mono text-2xs text-muted",
				children: [
					"FL ",
					man.hosts.fl,
					" · Live ",
					man.hosts.ableton,
					" · Win ",
					man.hosts.windows,
					" · Linux ",
					man.hosts.linux
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "secondary",
					onClick: () => void checkChannel().then(setMan),
					children: "Check channel"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "live",
					disabled: !behind || updating,
					onClick: () => void apply(),
					children: updating ? "Reforming…" : behind ? `Apply ${latest}` : "Up to date"
				})]
			}),
			man ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm text-muted",
				children: man.notes
			}) : null
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-mono text-2xs tracking-wider text-muted uppercase",
			children: "Add-ons"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-3 divide-y divide-rule border-y border-rule",
			children: (man?.addons ?? []).map((addon) => {
				const allowed = versionGte(kernel, addon.minKernel);
				const on = Boolean(addons[addon.id]);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-baseline justify-between gap-3 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium",
						children: addon.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-mono text-2xs text-muted",
						children: [
							addon.version,
							" · min kernel ",
							addon.minKernel
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-2xs tracking-wider uppercase text-muted",
						children: !allowed ? "locked" : on ? "live" : "off"
					})]
				}, addon.id);
			})
		})] })]
	});
}
function StudioKernelBay() {
	const lang = useStudio((s) => s.lang);
	const path = useStudio((s) => s.path);
	const score = useStudio((s) => s.signalScore);
	const bufferSize = useStudio((s) => s.bufferSize);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-w-0 flex-col gap-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-col gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-2xs tracking-[0.18em] text-muted uppercase",
						children: t(lang, "kernelKicker")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-3xl text-ink",
						children: path === "web" ? t(lang, "pathWeb") : path === "hybrid" ? t(lang, "pathHybrid") : t(lang, "pathKernel")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-w-2xl text-pretty text-muted",
						children: t(lang, "kernelLead")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-mono text-2xs tracking-wider text-muted uppercase",
						children: [
							t(lang, "hostSignal"),
							" ",
							formatScore(score),
							" · ",
							bufferSize
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SteelKernel, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SteelConsole, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SteelHosts, {})
		]
	});
}
/**
* Kärestik tunnelling — processing velocity.
* V = S / T
* S = signal (channels × sampleRate × active voices)
* T = computational need (buffer / sampleRate) = latency in seconds
*/
function karestik(sampleRate, buffer, voices, channels = 2) {
	const T = buffer / Math.max(1, sampleRate);
	const S = channels * sampleRate * Math.max(1, voices);
	return {
		signal: S,
		need: T,
		velocity: S / Math.max(1e-9, T),
		latencyMs: T * 1e3
	};
}
function formatVelocity(v) {
	const sign = v < 0 ? "−" : "";
	const a = Math.abs(v);
	if (a >= 1e9) return `${sign}${(a / 1e9).toFixed(2)} G`;
	if (a >= 1e6) return `${sign}${(a / 1e6).toFixed(2)} M`;
	if (a >= 1e3) return `${sign}${(a / 1e3).toFixed(1)} k`;
	return `${sign}${a.toFixed(0)}`;
}
function hostLatencyOffset(host, buffer, sampleRate) {
	return buffer / sampleRate * 1e3 + (host === "fl" ? 1.2 : host === "ableton" ? .8 : host === "logic" ? 1.6 : 0);
}
/**
* Signed Kärestik. V = S / T has no gravity — it does not command a place.
* (+) is kernel velocity. (−) is the web reflection, exponentially reduced
* toward the origin. When |+| ≈ |−| the pair cancels into a null, which is
* still lawful: the equation holds, it just stops pointing.
*/
function signedKarestik(sampleRate, buffer, voices, pathBias = 0) {
	const T = buffer / Math.max(1, sampleRate);
	const S = 2 * sampleRate * Math.max(1, voices);
	const V = S / Math.max(1e-9, T);
	const steps = Array.from({ length: 5 }, (_, i) => {
		const k = i / 4;
		const plus = V * Math.exp(-k * .35) * (1 + Math.max(0, pathBias));
		const minus = -V * Math.exp(-k * .55) * (1 + Math.max(0, -pathBias));
		return {
			k,
			plus,
			minus,
			sum: plus + minus,
			cancel: Math.abs(plus + minus) / Math.max(1, Math.abs(plus) + Math.abs(minus))
		};
	});
	return {
		V,
		S,
		T,
		steps,
		nullAt: steps.reduce((best, s, i) => s.cancel < steps[best].cancel ? i : best, 0)
	};
}
function pathBiasFrom(path) {
	if (path === "kernel") return .45;
	if (path === "web") return -.45;
	return 0;
}
var TRANSLATES = [
	"phone",
	"jbl",
	"festival"
];
function StudioMatrix() {
	const lang = useStudio((s) => s.lang);
	const sampleRate = useStudio((s) => s.sampleRate);
	const bufferSize = useStudio((s) => s.bufferSize);
	const voices = useStudio((s) => s.voices);
	const velocity = useStudio((s) => s.velocity);
	const signal = useStudio((s) => s.signal);
	const need = useStudio((s) => s.need);
	const latency = useStudio((s) => s.latency);
	const peak = useStudio((s) => s.peak);
	const mid = useStudio((s) => s.mid);
	const side = useStudio((s) => s.side);
	const width = useStudio((s) => s.width);
	const ceiling = useStudio((s) => s.ceiling);
	const translate = useStudio((s) => s.translate);
	const playing = useStudio((s) => s.playing);
	const patch = useStudio((s) => s.patch);
	const path = useStudio((s) => s.path);
	const local = karestik(sampleRate, bufferSize, Math.max(1, voices));
	const v = velocity || local.velocity;
	const py = signedKarestik(sampleRate, bufferSize, Math.max(1, voices), pathBiasFrom(path));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-w-0 flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-col gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-mono text-2xs tracking-[0.18em] text-muted uppercase",
						children: ["STEEL · ", t(lang, "karestik")]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-3xl text-ink",
						children: "V = S / T"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-mono text-2xs tracking-wider text-steel uppercase",
						children: [
							path === "kernel" ? t(lang, "pathKernel") : path === "web" ? t(lang, "pathWeb") : t(lang, "pathHybrid"),
							" · ",
							bufferSize
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-w-2xl text-pretty text-muted",
						children: lang === "et" ? "Töötluskiirus on signaal jagatud ajaga. Peegeldus hoiab kahte puhvrit. Gravitatsiooni pole: kui V+ ja V− tühistuvad, võrrand kehtib, ta lihtsalt ei osuta." : "Processing velocity is signal over time. Mirror holds two buffers. No gravity: when V+ and V− cancel, the equation still holds — it just stops pointing."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3 sm:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: t(lang, "velocity"),
						value: formatVelocity(v)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: t(lang, "signal"),
						value: formatVelocity(signal || local.signal)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: t(lang, "need"),
						value: `${((need || local.need) * 1e3).toFixed(2)} ms`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: t(lang, "latency"),
						value: `${latency.toFixed(2)} ms`
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-[var(--radius-lg)] bg-raised p-4 ring-1 ring-rule",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-3 font-mono text-2xs tracking-wider text-muted uppercase",
						children: t(lang, "pyramid")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-2 flex justify-between font-mono text-2xs tracking-wider text-muted uppercase",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, "minusV") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, "nullTier") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, "plusV") })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "flex flex-col gap-2",
						children: py.steps.map((step, i) => {
							const mag = Math.max(1, Math.abs(py.V));
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: cn("flex min-h-8 items-center gap-2 rounded-[var(--radius-sm)] px-1", i === py.nullAt ? "ring-1 ring-live" : ""),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex h-2 min-w-0 flex-1 justify-end overflow-hidden rounded-[var(--radius-xs)] bg-paper",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block h-full bg-steel",
											style: { width: `${Math.min(100, Math.abs(step.minus) / mag * 100)}%` }
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "w-8 shrink-0 text-center font-mono text-2xs tabular-nums text-muted",
										children: i + 1
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "h-2 min-w-0 flex-1 overflow-hidden rounded-[var(--radius-xs)] bg-paper",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block h-full bg-live",
											style: { width: `${Math.min(100, step.plus / mag * 100)}%` }
										})
									})
								]
							}, i);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 font-mono text-2xs tabular-nums text-muted",
						children: [
							t(lang, "plusV"),
							" ",
							formatVelocity(py.steps[0]?.plus ?? 0),
							" · ",
							t(lang, "minusV"),
							" ",
							formatVelocity(py.steps[0]?.minus ?? 0),
							" · ",
							t(lang, "nullTier"),
							" ",
							py.nullAt + 1
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 grid grid-cols-3 gap-2 font-mono text-2xs tracking-wider text-muted uppercase",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, "pyramid") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-center",
								children: t(lang, "banks")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-right",
								children: t(lang, "film")
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-[var(--radius-lg)] bg-raised p-4 ring-1 ring-rule",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-3 font-mono text-2xs tracking-wider text-muted uppercase",
						children: t(lang, "mirror")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BufferFace, {
							label: "A",
							active: playing,
							peak
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BufferFace, {
							label: "B",
							active: !playing,
							peak: mid
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted",
						children: lang === "et" ? "Nest / peegeldus: AI ja mõõdikud loevad peegelpuhvrit, kernel kirjutab teise. CPU ei oota joonistust." : "Nest / mirror: meters read the reflected buffer while the kernel writes the other. Draw never blocks the quantum."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DualMeter, {
				peak,
				mid,
				side
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-2 font-mono text-2xs tracking-wider text-muted uppercase",
					children: t(lang, "translate")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-2",
					children: TRANSLATES.map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => {
							patch({ translate: id });
							pushAll();
						},
						className: cn("min-h-11 rounded-[var(--radius-sm)] px-3 text-sm ring-1 ring-rule", translate === id ? "bg-ink text-paper" : "text-muted"),
						children: t(lang, id)
					}, id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: lang === "et" ? "Telefon = mono ja kitsas riba. JBL = veidi bassi. Festival = täisriba, kick keskel." : "Phone = mono, narrow band. JBL = slight bass. Festival = full band, kick centered."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fader, {
				label: t(lang, "width"),
				value: width,
				onChange: (v) => {
					patch({ width: v });
					pushAll();
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fader, {
				label: t(lang, "ceiling"),
				value: ceiling,
				min: .4,
				max: 1,
				onChange: (v) => {
					patch({ ceiling: v });
					pushAll();
				}
			})
		]
	});
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-[var(--radius-md)] bg-raised p-3 ring-1 ring-rule",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-mono text-2xs tracking-wider text-muted uppercase",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 font-mono text-lg tabular-nums text-ink",
			children: value
		})]
	});
}
function BufferFace({ label, active, peak }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("rounded-[var(--radius-md)] p-3 ring-1 ring-rule", active ? "bg-paper" : "bg-raised"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "font-mono text-2xs tracking-wider text-muted uppercase",
			children: [
				"Buffer ",
				label,
				active ? " · write" : " · read"
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-2 h-16 overflow-hidden rounded-[var(--radius-xs)] bg-paper",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-full bg-steel/40",
				style: { width: `${Math.min(100, peak * 140)}%` }
			})
		})]
	});
}
var writeHook = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("5e9d181f18f88538dd562a585a605b3513846dbf7cfed09452e8f0a567d0da5d"));
var speakHook = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("9a1b68d71c937e4539d4123efdcdf02834147108e7690e8669ef06f68247f3dc"));
var detectLyrics = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("a35ba60b943647906b56c0515dd54ba5479da050701d6249467c7c310e72e572"));
var visualParams = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("19af9131710b37ec6a7f52059a4c1b1a4665452e8c7237f674cdea3d73c1359f"));
var scaleRadar = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("6da032ae7970813ffe388ea83db1935c8bcb2c7ade50e7a658c16e6a70beccac"));
/** Curated studio radar — not a live scrape. Honest, dated notes. */
var RADAR = [
	{
		id: "fl-arrangement",
		source: "FL Studio",
		title: "Playlist clips follow the arrangement clock more tightly",
		note: "Recent FL playlist work emphasises clip start/end on the grid without stretching the audio file itself.",
		steel: "STEEL already snaps vocal grains to the 16-step grid. Next: clip envelopes per channel."
	},
	{
		id: "ableton-mpe",
		source: "Ableton Live",
		title: "MPE expression on stock devices",
		note: "Live keeps pushing per-note slide and pressure into simpler devices, not only Push-era synths.",
		steel: "Web MIDI here is note + velocity. Pressure can ride the lead filter if a compatible controller is present."
	},
	{
		id: "logic-stem",
		source: "Logic Pro",
		title: "Stem-split and bounce-in-place remain the mix-export path",
		note: "Logic’s stem workflow is still the reference for handing a vocal to video.",
		steel: "Bounce WAV is the web equivalent. Video stays on the visualizer clock, not a separate timeline yet."
	}
];
var HOSTS = [
	"standalone",
	"fl",
	"ableton",
	"logic"
];
var BUFFERS = [
	128,
	256,
	512
];
function StudioMonitor() {
	const lang = useStudio((s) => s.lang);
	const host = useStudio((s) => s.host);
	const bufferSize = useStudio((s) => s.bufferSize);
	const sampleRate = useStudio((s) => s.sampleRate);
	const cpu = useStudio((s) => s.cpu);
	const armed = useStudio((s) => s.armed);
	const radarNote = useStudio((s) => s.radarNote);
	const processing = useStudio((s) => s.processing);
	const patch = useStudio((s) => s.patch);
	const lat = hostLatencyOffset(host, bufferSize, sampleRate);
	async function onScale(id) {
		const item = RADAR.find((r) => r.id === id);
		if (!item) return;
		patch({ processing: true });
		try {
			const res = await scaleRadar({ data: {
				title: item.title,
				note: item.note,
				lang
			} });
			if (!res.ok) {
				toast.error(res.error);
				return;
			}
			patch({ radarNote: res.text });
		} finally {
			patch({ processing: false });
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-col gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-mono text-2xs tracking-[0.18em] text-muted uppercase",
						children: ["STEEL · ", t(lang, "monitor")]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-3xl text-ink",
						children: t(lang, "localBridge")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-w-2xl text-pretty text-muted",
						children: t(lang, "localBridgeNote")
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "grid grid-cols-2 gap-3 sm:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-[var(--radius-md)] bg-raised p-3 ring-1 ring-rule",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "font-mono text-2xs tracking-wider text-muted uppercase",
							children: "Engine"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "mt-1 text-ink",
							children: armed ? t(lang, "armed") : "idle"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-[var(--radius-md)] bg-raised p-3 ring-1 ring-rule",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "font-mono text-2xs tracking-wider text-muted uppercase",
							children: "SR"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "mt-1 font-mono tabular-nums text-ink",
							children: sampleRate
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-[var(--radius-md)] bg-raised p-3 ring-1 ring-rule",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "font-mono text-2xs tracking-wider text-muted uppercase",
							children: t(lang, "latency")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
							className: "mt-1 font-mono tabular-nums text-ink",
							children: [lat.toFixed(2), " ms"]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-[var(--radius-md)] bg-raised p-3 ring-1 ring-rule",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "font-mono text-2xs tracking-wider text-muted uppercase",
							children: "CPU"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
							className: "mt-1 font-mono tabular-nums text-ink",
							children: [Math.round(cpu), "%"]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-2 font-mono text-2xs tracking-wider text-muted uppercase",
				children: t(lang, "host")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: HOSTS.map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => patch({ host: id }),
					className: cn("min-h-11 rounded-[var(--radius-sm)] px-3 text-sm ring-1 ring-rule", host === id ? "bg-ink text-paper" : "text-muted"),
					children: t(lang, id)
				}, id))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-2 font-mono text-2xs tracking-wider text-muted uppercase",
				children: t(lang, "buffer")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: BUFFERS.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => {
						patch({ bufferSize: n });
						pushAll();
					},
					className: cn("min-h-11 rounded-[var(--radius-sm)] px-3 font-mono text-sm ring-1 ring-rule", bufferSize === n ? "bg-ink text-paper" : "text-muted"),
					children: n
				}, n))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-3 font-mono text-2xs tracking-wider text-muted uppercase",
					children: t(lang, "radar")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "flex flex-col gap-3",
					children: RADAR.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-[var(--radius-lg)] bg-raised p-4 ring-1 ring-rule",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-mono text-2xs tracking-wider text-muted uppercase",
								children: item.source
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-ink",
								children: item.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted",
								children: item.note
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-steel",
								children: item.steel
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "secondary",
								size: "sm",
								className: "mt-3",
								disabled: processing,
								onClick: () => void onScale(item.id),
								children: t(lang, "radarGo")
							})
						]
					}, item.id))
				}),
				radarNote ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
					className: "mt-4 whitespace-pre-wrap rounded-[var(--radius-md)] bg-paper p-4 text-sm text-ink ring-1 ring-rule",
					children: radarNote
				}) : null
			] })
		]
	});
}
var TICK_MS = 6e3;
var HIDDEN_MS = 2e4;
var timer$1 = null;
var cursor = 0;
var running$1 = false;
function lang() {
	return useStudio.getState().lang;
}
function line(et, en) {
	return lang() === "en" ? en : et;
}
function applyPolicy(path) {
	const policy = policyFor(path);
	useStudio.getState().patch({
		path: policy.path,
		signalScore: probeSignal().score,
		bufferSize: policy.bufferSize,
		visFps: policy.visFps,
		visQuality: policy.visQuality
	});
	useSteel.getState().patch({
		buffer: policy.bufferSize,
		webOut: policy.path !== "kernel"
	});
	useCrew.getState().patch({
		livePath: policy.path,
		appliedRev: useCrew.getState().policyRev
	});
}
function readForceFromOrder(order) {
	const o = order.toLowerCase();
	if (/\b(paus|pause|stopp?)\b/.test(o)) return "pause";
	if (/\b(jätka|jatka|resume|continue)\b/.test(o)) return "resume";
	if (/\b(tuum|kernel)\b/.test(o) && !/\b(veeb|web)\b/.test(o)) return "kernel";
	if (/\b(veeb|web)\b/.test(o) && !/\b(tuum|kernel)\b/.test(o)) return "web";
	if (/\b(hübriid|hubriid|hybrid)\b/.test(o)) return "hybrid";
	return null;
}
async function duty(id) {
	const crew = useCrew.getState();
	const agent = crew.agents[id];
	if (agent.status === "paused") return;
	crew.setAgent(id, {
		status: "work",
		ticks: agent.ticks + 1
	});
	try {
		switch (id) {
			case "architect": {
				const report = probeSignal(true);
				const path = crew.forcePath ?? report.path;
				useStudio.getState().patch({
					signalScore: report.score,
					cores: report.cores,
					memoryGb: report.memoryGb,
					connection: report.connection,
					path
				});
				if (path !== crew.livePath) {
					crew.patch({ policyRev: crew.policyRev + 1 });
					crew.pushLog(id, line(`Poliitika ${path.toUpperCase()} · signaal ${Math.round(report.score * 100)} · ${report.cores} tuuma`, `Policy ${path.toUpperCase()} · signal ${Math.round(report.score * 100)} · ${report.cores} cores`));
				} else crew.pushLog(id, line(`Signaal ${Math.round(report.score * 100)} hoiab teed ${path}.`, `Signal ${Math.round(report.score * 100)} holds path ${path}.`));
				break;
			}
			case "builder": {
				const next = useCrew.getState();
				if (next.policyRev !== next.appliedRev) {
					applyPolicy(useStudio.getState().path);
					next.pushLog(id, line(`Rakendatud ${useStudio.getState().path} · puhver ${useStudio.getState().bufferSize} · ${useStudio.getState().visFps} fps`, `Applied ${useStudio.getState().path} · buffer ${useStudio.getState().bufferSize} · ${useStudio.getState().visFps} fps`));
				} else next.pushLog(id, line("Pult on poliitikaga kooskõlas.", "Desk matches policy."));
				break;
			}
			case "maintenance": {
				const s = useStudio.getState();
				if (s.error) useCrew.getState().pushLog(id, line(`Viga: ${s.error}`, `Fault: ${s.error}`));
				else if (s.cpu > 78 && s.bufferSize < 1024) {
					const nextBuf = s.bufferSize <= 128 ? 256 : s.bufferSize <= 256 ? 512 : 1024;
					s.patch({ bufferSize: nextBuf });
					useSteel.getState().patch({ buffer: nextBuf });
					useCrew.getState().pushLog(id, line(`CPU ${s.cpu.toFixed(0)} · puhver ${nextBuf}`, `CPU ${s.cpu.toFixed(0)} · buffer ${nextBuf}`));
				} else useCrew.getState().pushLog(id, line(s.armed ? "Mootor sees, latentsus stabiilne." : "Mootor ootel. Vahid jäävad.", s.armed ? "Engine live, latency stable." : "Engine idle. Watch holds."));
				break;
			}
			case "seeker":
				try {
					const man = await checkChannel();
					useCrew.getState().patch({ channelLatest: man.latest });
					const k = useSteel.getState().kernel;
					const behind = !versionGte(k, man.latest);
					useCrew.getState().pushLog(id, behind ? line(`Kanal ${man.latest} ootab (jookseb ${k}).`, `Channel ${man.latest} waiting (running ${k}).`) : line(`Kanal paigas · ${k}.`, `Channel current · ${k}.`));
				} catch (err) {
					useCrew.getState().setAgent(id, { status: "blocked" });
					useCrew.getState().pushLog(id, line(`Kanal vaikne: ${err instanceof Error ? err.message : "down"}`, `Channel quiet: ${err instanceof Error ? err.message : "down"}`));
					return;
				}
				break;
			case "executioner": {
				const next = useCrew.getState();
				const want = useStudio.getState().path;
				if (want !== next.livePath) {
					applyPolicy(want);
					next.pushLog(id, line(`Tee vahetatud → ${want}.`, `Path switched → ${want}.`));
				} else next.pushLog(id, line("Täitmist ei ole. Tee paigas.", "Nothing to execute. Path holds."));
				break;
			}
			case "kernel": {
				const report = probeSignal();
				const armed = useStudio.getState().armed || useSteel.getState().armed;
				if (!report.worklet) {
					useCrew.getState().setAgent(id, { status: "blocked" });
					useCrew.getState().pushLog(id, line("AudioWorklet puudub — jääb veebitee.", "No AudioWorklet — staying on web."));
					return;
				}
				useCrew.getState().pushLog(id, line(armed ? "Tuum laetud, worklet sees." : "Tuum valmis. Ootab esimest puudutust.", armed ? "Kernel loaded, worklet live." : "Kernel ready. Waiting for first tap."));
				break;
			}
			case "web": {
				const path = useStudio.getState().path;
				const fps = useStudio.getState().visFps;
				useCrew.getState().pushLog(id, path === "web" ? line(`Veebitee kandev · visuaal ${fps} fps.`, `Web path carrying · visuals ${fps} fps.`) : line(`Veeb ootel. Tuum kannab.`, `Web standing by. Kernel carries.`));
				break;
			}
		}
		const after = useCrew.getState().agents[id];
		if (after.status !== "paused" && after.status !== "blocked") useCrew.getState().setAgent(id, { status: "idle" });
	} catch (err) {
		useCrew.getState().setAgent(id, { status: "blocked" });
		useCrew.getState().pushLog(id, err instanceof Error ? err.message : "blocked");
	}
	const hint = readForceFromOrder(useCrew.getState().agents[id].order);
	if (hint === "pause") useCrew.getState().setAgent(id, { status: "paused" });
	if (hint === "resume") useCrew.getState().setAgent(id, { status: "idle" });
	if (hint === "kernel" || hint === "web" || hint === "hybrid") {
		if (id === "architect") useCrew.getState().setForcePath(hint);
	}
}
function schedule() {
	if (!running$1) return;
	const ms = typeof document !== "undefined" && document.visibilityState === "hidden" ? HIDDEN_MS : TICK_MS;
	timer$1 = setTimeout(() => {
		tick();
	}, ms);
}
async function tick() {
	if (!running$1) return;
	if (!useCrew.getState().watching) {
		schedule();
		return;
	}
	const id = AGENT_IDS[cursor % AGENT_IDS.length];
	cursor += 1;
	const cap = new Promise((_, reject) => {
		setTimeout(() => reject(/* @__PURE__ */ new Error("watch cap")), 4500);
	});
	try {
		await Promise.race([duty(id), cap]);
	} catch {
		if (useCrew.getState().agents[id].status === "work") useCrew.getState().setAgent(id, { status: "idle" });
	}
	schedule();
}
function startCrew() {
	if (running$1) return;
	running$1 = true;
	const report = probeSignal(true);
	const path = useCrew.getState().forcePath ?? report.path;
	useStudio.getState().patch({
		path,
		signalScore: report.score,
		cores: report.cores,
		memoryGb: report.memoryGb,
		connection: report.connection
	});
	applyPolicy(path);
	useCrew.getState().pushLog("architect", line(`Vahid sees · ${path.toUpperCase()} · signaal ${Math.round(report.score * 100)}`, `Watch on · ${path.toUpperCase()} · signal ${Math.round(report.score * 100)}`));
	schedule();
}
function stopCrew() {
	running$1 = false;
	if (timer$1) {
		clearTimeout(timer$1);
		timer$1 = null;
	}
}
var timer = null;
var running = false;
function beat() {
	if (!running) return;
	try {
		const s = useStudio.getState();
		if (s.armed) pushAll();
		const banks = Object.values(s.recs).map((r) => r.bankId).filter((id) => Boolean(id));
		const prev = loadVault();
		saveVault({
			banks,
			extras: [...EXTRA_IDS],
			visemes: prev.visemes,
			patterns: prev.patterns
		});
		armedCurve(s.recs);
		signedKarestik(s.sampleRate, s.bufferSize, Math.max(1, s.voices), pathBiasFrom(s.path));
	} catch {}
	const hidden = typeof document !== "undefined" && document.visibilityState === "hidden";
	timer = setTimeout(beat, hidden ? 18e3 : 4e3);
}
function startStudioWatch() {
	if (running) return;
	running = true;
	beat();
}
function stopStudioWatch() {
	running = false;
	if (timer) {
		clearTimeout(timer);
		timer = null;
	}
}
function Transport() {
	const lang = useStudio((s) => s.lang);
	const playing = useStudio((s) => s.playing);
	const armed = useStudio((s) => s.armed);
	const recording = useStudio((s) => s.recording);
	const bpm = useStudio((s) => s.bpm);
	const peak = useStudio((s) => s.peak);
	const rms = useStudio((s) => s.rms);
	const processing = useStudio((s) => s.processing);
	const patch = useStudio((s) => s.patch);
	async function onBounce() {
		try {
			const blob = await bounceWav(8);
			if (blob) downloadBlob(blob, "steel-studio.wav");
		} catch {
			toast.error(t(lang, "decodeFail"));
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "steel-transport shell-pad sticky bottom-0 z-30 border-t border-rule bg-paper/95 backdrop-blur-sm",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-6xl items-center gap-2 py-2 sm:gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: playing ? "live" : "primary",
					size: "icon",
					className: "shrink-0",
					"aria-label": playing ? t(lang, "stop") : t(lang, "play"),
					onClick: () => {
						togglePlay().catch((err) => {
							toast.error(err instanceof Error ? err.message : t(lang, "needArm"));
						});
					},
					children: playing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Square, { className: "size-4 fill-current" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
						viewBox: "0 0 24 24",
						className: "size-4 fill-current",
						"aria-hidden": true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M8 5.5v13l11-6.5L8 5.5z" })
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: recording ? "stamp" : "secondary",
					size: "icon",
					className: "shrink-0",
					"aria-label": t(lang, "recVoice"),
					onClick: () => {
						toggleVoiceRec().then((state) => {
							if (state === "start") toast.message(t(lang, "recStart"));
							if (state === "stop") toast.message(t(lang, "recDone"));
						});
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Circle, { className: "size-3.5 fill-current" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "hidden min-w-0 items-center gap-2 sm:flex",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-mono text-2xs tracking-wider text-muted uppercase",
						children: t(lang, "bpm")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "number",
						min: 70,
						max: 180,
						value: bpm,
						onChange: (e) => {
							patch({ bpm: Math.min(180, Math.max(70, Number(e.target.value) || 70)) });
							pushAll();
						},
						className: "h-11 w-16 rounded-[var(--radius-sm)] border border-rule bg-raised px-2 font-mono text-sm tabular-nums text-ink"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LevelMeter, {
						peak,
						rms
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 hidden font-mono text-2xs tracking-wider text-muted uppercase sm:block",
						children: [armed ? t(lang, "armed") : t(lang, "arm"), processing ? ` · ${t(lang, "processing")}` : ""]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "secondary",
					size: "icon",
					className: "shrink-0",
					"aria-label": t(lang, "downloadPack"),
					onClick: () => downloadFilmPack(),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {
						className: "size-4",
						strokeWidth: 1.75
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "secondary",
					size: "sm",
					className: "hidden sm:inline-flex",
					onClick: () => void onBounce(),
					children: t(lang, "bounce")
				})
			]
		})
	});
}
var TABS = [
	{
		id: "desk",
		key: "desk"
	},
	{
		id: "vocals",
		key: "vocals"
	},
	{
		id: "visuals",
		key: "visuals"
	},
	{
		id: "matrix",
		key: "matrix"
	},
	{
		id: "monitor",
		key: "monitor"
	},
	{
		id: "kernel",
		key: "kernel"
	},
	{
		id: "crew",
		key: "crew"
	},
	{
		id: "audit",
		key: "audit"
	},
	{
		id: "banks",
		key: "banks"
	},
	{
		id: "film",
		key: "film"
	},
	{
		id: "theory",
		key: "theory"
	}
];
function isolate(next) {
	if (next === "kernel") disarmEngine();
	else if (next !== "crew") disarmKernel();
}
function StudioShell({ children }) {
	const tab = useStudio((s) => s.tab);
	const setTab = useStudio((s) => s.setTab);
	const lang = useStudio((s) => s.lang);
	const patch = useStudio((s) => s.patch);
	const armed = useStudio((s) => s.armed);
	const playing = useStudio((s) => s.playing);
	const processing = useStudio((s) => s.processing);
	const path = useStudio((s) => s.path);
	(0, import_react.useEffect)(() => {
		hydrateStudio();
		hydrateSteel();
		hydrateCrew(useStudio.getState().lang);
		const stop = watchStudioPersist();
		const stopSteel = watchSteelPersist();
		const stopCrewPersist = watchCrewPersist();
		startCrew();
		startStudioWatch();
		const onVis = () => onVisibility();
		document.addEventListener("visibilitychange", onVis);
		const onKey = (e) => {
			if (e.code !== "Space" || e.metaKey || e.ctrlKey || e.altKey) return;
			const tag = e.target?.tagName;
			if (tag === "INPUT" || tag === "SELECT" || tag === "TEXTAREA") return;
			e.preventDefault();
			togglePlay();
		};
		window.addEventListener("keydown", onKey);
		return () => {
			stop();
			stopSteel();
			stopCrewPersist();
			stopCrew();
			stopStudioWatch();
			document.removeEventListener("visibilitychange", onVis);
			window.removeEventListener("keydown", onKey);
			disarmEngine();
			disarmKernel();
		};
	}, []);
	(0, import_react.useEffect)(() => {
		document.documentElement.lang = lang;
		useSteel.getState().patch({ lang });
	}, [lang]);
	(0, import_react.useEffect)(() => {
		pushAll();
	}, [tab]);
	const pathLabel = path === "kernel" ? t(lang, "pathKernel") : path === "web" ? t(lang, "pathWeb") : t(lang, "pathHybrid");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh w-full min-w-0 flex-col overflow-x-hidden bg-paper text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: "#main",
				className: "sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 focus:bg-ink focus:px-3 focus:py-2 focus:text-paper",
				children: t(lang, "skip")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "sticky top-0 z-20 border-b border-rule bg-paper/95 backdrop-blur-sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "shell-header shell-pad mx-auto max-w-6xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-3 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex min-w-0 items-center gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: cn("size-2 shrink-0 rounded-full", processing ? "bg-copper" : armed || playing ? "bg-live" : "bg-rule"),
									"aria-hidden": true
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-display text-xl tracking-[0.14em]",
										children: "STEEL"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-mono text-2xs tracking-[0.18em] text-muted uppercase",
										children: t(lang, "studio")
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setTab("crew"),
									className: "hidden min-h-11 shrink-0 rounded-[var(--radius-sm)] px-2 font-mono text-2xs tracking-[0.16em] text-steel uppercase ring-1 ring-rule sm:inline-flex sm:items-center",
									children: pathLabel
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => patch({ lang: lang === "et" ? "en" : "et" }),
							className: "min-h-11 min-w-11 shrink-0 rounded-[var(--radius-sm)] ring-1 ring-rule px-2 font-mono text-2xs tracking-wider text-muted uppercase",
							"aria-label": "Language",
							children: lang === "et" ? "ET" : "EN"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						"aria-label": "Primary",
						className: "nav-scroll -mx-1 pb-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex w-max flex-nowrap gap-1 px-1",
							children: TABS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									isolate(item.id);
									setTab(item.id);
								},
								"aria-current": tab === item.id ? "page" : void 0,
								className: cn("min-h-11 shrink-0 rounded-[var(--radius-sm)] px-3 py-2 text-sm transition-colors duration-[var(--motion-quick)]", tab === item.id ? "bg-ink text-paper" : "text-muted hover:bg-ink/[0.06] hover:text-ink"),
								children: t(lang, item.key)
							}, item.id))
						})
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				id: "main",
				className: "shell-pad mx-auto w-full min-w-0 max-w-6xl flex-1 py-6 sm:py-8",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "shell-pad mx-auto max-w-6xl py-4 font-mono text-2xs tracking-wide text-muted uppercase",
				children: t(lang, "footer")
			}),
			tab !== "kernel" && tab !== "audit" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Transport, {}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
				position: "bottom-center",
				toastOptions: { className: "!bg-raised !text-ink !border-rule !font-[inherit] !rounded-[6px]" }
			})
		]
	});
}
var lookupHost = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("c244bf9d2a84abd80e71350a3b24ae789f10e088f6681ba97f3513e34509772a"));
var lockRhyme = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("e366012e87c7f9f61afe69826e18e78acf2adce9c73cb30ecb29117424df0845"));
function StudioTheory() {
	const lang = useStudio((s) => s.lang);
	const genre = useStudio((s) => s.genre);
	const bpm = useStudio((s) => s.bpm);
	const recs = useStudio((s) => s.recs);
	const dirtBias = useStudio((s) => s.dirtBias);
	const theoryPaste = useStudio((s) => s.theoryPaste);
	const rhymeSeed = useStudio((s) => s.rhymeSeed);
	const rhymeOut = useStudio((s) => s.rhymeOut);
	const lyrics = useStudio((s) => s.lyrics);
	const vocalLang = useStudio((s) => s.vocalLang);
	const nightLane = useStudio((s) => s.nightLane);
	const processing = useStudio((s) => s.processing);
	const geoBusy = useStudio((s) => s.geoBusy);
	const geoLine = useStudio((s) => s.geoLine);
	const patch = useStudio((s) => s.patch);
	const curve = armedCurve(recs);
	const loadedId = Object.values(recs).find((r) => r.loaded && r.bankId)?.bankId ?? null;
	const spine = buildSpine({
		genre,
		bpm,
		bank: loadedId ? BANKS$1.find((b) => b.id === loadedId) ?? null : null,
		curve,
		paste: theoryPaste,
		dirtBias,
		nightLane
	});
	async function rhyme(want) {
		const seed = (rhymeSeed || lyrics).trim();
		if (!seed) {
			toast.error(t(lang, "lockSeed"));
			return;
		}
		patch({
			processing: true,
			rhymeSeed: seed
		});
		try {
			const res = await lockRhyme({ data: {
				seed,
				bpm,
				lang: vocalLang,
				want
			} });
			if (!res.ok) {
				toast.error(res.error);
				return;
			}
			patch({
				rhymeOut: res.text,
				lyrics: want === "fix" ? seed : lyrics
			});
			if (want !== "fix") patch({ lyrics: res.text });
		} finally {
			patch({ processing: false });
		}
	}
	async function geo() {
		if (useStudio.getState().geoBusy) return;
		patch({ geoBusy: true });
		try {
			const res = await lookupHost({ data: {} });
			if (!res.ok) {
				toast.error(res.error);
				return;
			}
			patch({ geoLine: `${res.line} · ${res.isp}` });
		} catch {
			toast.error(t(lang, "decodeFail"));
		} finally {
			patch({ geoBusy: false });
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-w-0 flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-col gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-2xs tracking-[0.18em] text-muted uppercase",
						children: t(lang, "theoryKicker")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-3xl text-ink",
						children: t(lang, "theoryTitle")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-w-2xl text-pretty text-muted",
						children: t(lang, "theoryLead")
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-[var(--radius-lg)] bg-raised p-4 ring-1 ring-rule",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex min-h-11 items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-2xs tracking-wider text-muted uppercase",
							children: t(lang, "nightLane")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							role: "switch",
							"aria-checked": nightLane,
							"aria-label": t(lang, "nightLane"),
							onClick: () => patch({
								nightLane: !nightLane,
								vocalKind: !nightLane ? "whisper" : useStudio.getState().vocalKind
							}),
							className: cn("h-7 w-12 rounded-full ring-1 ring-rule", nightLane ? "bg-live" : "bg-paper"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("block size-6 rounded-full bg-ink", nightLane ? "translate-x-5" : "translate-x-0.5") })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted",
						children: t(lang, "nightLead")
					}),
					nightLane ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 font-mono text-2xs tracking-wider text-live uppercase",
						children: "TAKT-LOCK · ENERGY-MATCH · STEREO-MX"
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-mono text-2xs tracking-wider text-muted uppercase",
					children: t(lang, "pasteTrack")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					rows: 3,
					value: theoryPaste,
					onChange: (e) => patch({ theoryPaste: e.target.value }),
					className: "mt-2 w-full min-w-0 resize-y rounded-[var(--radius-sm)] bg-raised px-3 py-2 text-sm text-ink ring-1 ring-rule"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex justify-between font-mono text-2xs tracking-wider text-muted uppercase",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, "dirtClear") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums text-ink",
						children: dirtBias.toFixed(2)
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "range",
					min: 0,
					max: 1,
					step: .01,
					value: dirtBias,
					onChange: (e) => patch({ dirtBias: Number(e.target.value) }),
					className: "steel-range mt-2"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "grid grid-cols-2 gap-3 text-sm sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
						k: "pulse",
						v: spine.pulse
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
						k: "takt",
						v: spine.takt
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
						k: "pitch",
						v: spine.pitchHouse
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
						k: "dirt",
						v: spine.dirt.toFixed(2)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
						k: "clear",
						v: spine.clear.toFixed(2)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
						k: "chroma",
						v: spine.chroma
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-2 font-mono text-2xs tracking-wider text-muted uppercase",
					children: t(lang, "extras")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "divide-y divide-rule rounded-[var(--radius-md)] bg-raised ring-1 ring-rule",
					children: spine.extras.map((ex) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex min-w-0 items-baseline justify-between gap-3 px-3 py-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: cn("font-mono text-2xs tracking-wider uppercase", ex.on ? "text-live" : "text-faint"),
									children: ex.id
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted",
									children: ex.action
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate font-mono text-2xs text-faint",
									children: ex.why
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "shrink-0 font-mono text-sm tabular-nums",
							children: ex.intensity
						})]
					}, ex.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 font-mono text-2xs text-muted",
					children: spine.hearFirst.join(" · ")
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-mono text-2xs tracking-wider text-muted uppercase",
					children: t(lang, "lockSeed")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					rows: 5,
					value: rhymeSeed,
					onChange: (e) => patch({ rhymeSeed: e.target.value }),
					className: "mt-2 w-full min-w-0 resize-y rounded-[var(--radius-sm)] bg-raised px-3 py-2 text-sm text-ink ring-1 ring-rule"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "secondary",
						disabled: processing,
						onClick: () => void rhyme("fix"),
						children: t(lang, "fixBars")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "secondary",
						disabled: processing,
						onClick: () => void rhyme("hook"),
						children: t(lang, "writeHook")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "live",
						disabled: processing,
						onClick: () => void rhyme("verse"),
						children: t(lang, "writeVerse")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "ghost",
						disabled: geoBusy,
						onClick: () => void geo(),
						children: t(lang, "hostLookup")
					})
				]
			}),
			geoLine ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-mono text-2xs text-muted",
				children: geoLine
			}) : null,
			rhymeOut ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
				className: "max-h-80 overflow-auto whitespace-pre-wrap rounded-[var(--radius-md)] bg-raised p-3 text-sm text-ink ring-1 ring-rule",
				children: rhymeOut
			}) : null
		]
	});
}
function Item({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-w-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "font-mono text-2xs tracking-wider text-muted uppercase",
			children: k
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "mt-1 truncate",
			children: v
		})]
	});
}
var STYLES = [
	"auto",
	"rings",
	"tunnel",
	"scope",
	"bars",
	"film",
	"lips"
];
function StudioVisuals() {
	const lang = useStudio((s) => s.lang);
	const style = useStudio((s) => s.visualStyle);
	const prompt = useStudio((s) => s.visualPrompt);
	const lyrics = useStudio((s) => s.lyrics);
	const stillUrl = useStudio((s) => s.stillUrl);
	const processing = useStudio((s) => s.processing);
	const patch = useStudio((s) => s.patch);
	const canvasRef = (0, import_react.useRef)(null);
	const stillRef = (0, import_react.useRef)(null);
	const recRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		if (!stillUrl) {
			stillRef.current = null;
			return;
		}
		const img = new Image();
		img.crossOrigin = "anonymous";
		img.src = stillUrl;
		stillRef.current = img;
	}, [stillUrl]);
	(0, import_react.useEffect)(() => {
		let raf = 0;
		const t0 = performance.now();
		let last = 0;
		const loop = (now) => {
			const fps = useStudio.getState().visFps || 60;
			const minDt = 1e3 / Math.max(12, fps);
			if (now - last >= minDt) {
				last = now;
				const canvas = canvasRef.current;
				if (canvas) {
					const tap = getAnalyser();
					if (tap) {
						tap.analyser.getByteFrequencyData(tap.freq);
						tap.analyser.getByteTimeDomainData(tap.wave);
					}
					const tokens = readTokens(document.documentElement);
					const empty = /* @__PURE__ */ new Uint8Array(512);
					const s = useStudio.getState();
					drawVisualizer({
						canvas,
						freq: tap?.freq ?? empty,
						wave: tap?.wave ?? empty,
						tokens,
						style: s.visualStyle,
						genre: s.genre,
						peak: s.peak,
						rms: s.rms,
						bpm: s.bpm,
						step: s.step,
						playing: s.playing,
						lyrics: s.lyrics,
						still: stillRef.current,
						t: (performance.now() - t0) / 1e3
					});
				}
			}
			raf = requestAnimationFrame(loop);
		};
		raf = requestAnimationFrame(loop);
		return () => cancelAnimationFrame(raf);
	}, []);
	async function onStill() {
		const p = prompt.trim();
		if (!p) return;
		patch({ processing: true });
		try {
			const res = await visualParams({ data: { prompt: p } });
			if (!res.ok) {
				toast.error(res.error);
				return;
			}
			patch({ stillUrl: res.url });
		} finally {
			patch({ processing: false });
		}
	}
	async function onLyrics() {
		patch({ processing: true });
		try {
			const res = await detectLyrics({ data: {
				genre: useStudio.getState().genre,
				hint: prompt,
				lang
			} });
			if (!res.ok) {
				toast.error(res.error);
				return;
			}
			patch({ lyrics: res.text });
		} finally {
			patch({ processing: false });
		}
	}
	function onRecord() {
		const canvas = canvasRef.current;
		if (!canvas) return;
		if (recRef.current) {
			recRef.current.stop();
			recRef.current = null;
			return;
		}
		try {
			const stream = canvas.captureStream(30);
			const rec = new MediaRecorder(stream, { mimeType: "video/webm" });
			const chunks = [];
			rec.ondataavailable = (e) => {
				if (e.data.size) chunks.push(e.data);
			};
			rec.onstop = () => {
				const blob = new Blob(chunks, { type: "video/webm" });
				const a = document.createElement("a");
				a.href = URL.createObjectURL(blob);
				a.download = "steel-visual.webm";
				a.click();
			};
			rec.start();
			recRef.current = rec;
			toast.message(t(lang, "recordVis"));
		} catch {
			toast.error(t(lang, "decodeFail"));
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-col gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-mono text-2xs tracking-[0.18em] text-muted uppercase",
					children: ["STEEL · ", t(lang, "visuals")]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl text-ink",
					children: "Locked to the grid."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
				ref: canvasRef,
				className: "aspect-video w-full rounded-[var(--radius-lg)] bg-paper ring-1 ring-rule",
				"aria-label": "Visualizer"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: STYLES.map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => patch({ visualStyle: id }),
					className: cn("min-h-11 rounded-[var(--radius-sm)] px-3 text-sm ring-1 ring-rule", style === id ? "bg-ink text-paper" : "text-muted"),
					children: id === "film" ? t(lang, "filmStyle") : t(lang, id)
				}, id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex flex-col gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-mono text-2xs tracking-wider text-muted uppercase",
						children: t(lang, "prompt")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						value: prompt,
						maxLength: 500,
						rows: 3,
						onChange: (e) => patch({ visualPrompt: e.target.value }),
						className: "rounded-[var(--radius-md)] border border-rule bg-raised p-3 text-sm text-ink"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-muted",
						children: t(lang, "promptHint")
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						disabled: processing,
						onClick: () => void onStill(),
						children: t(lang, "still")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "secondary",
						disabled: processing,
						onClick: () => void onLyrics(),
						children: t(lang, "detectLyrics")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "secondary",
						onClick: onRecord,
						children: t(lang, "recordVis")
					})
				]
			}),
			lyrics ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-ink",
				children: lyrics
			}) : null
		]
	});
}
var CHAINS = [
	{
		id: "dry",
		key: "dry"
	},
	{
		id: "hard-delay",
		key: "hardDelay"
	},
	{
		id: "club-verb",
		key: "clubVerb"
	},
	{
		id: "radio",
		key: "radio"
	},
	{
		id: "trap-space",
		key: "trapSpace"
	}
];
var BANKS = [
	{
		id: "lead",
		key: "leadVoice"
	},
	{
		id: "harmony",
		key: "female"
	},
	{
		id: "choir",
		key: "choir"
	},
	{
		id: "adlib",
		key: "adlib"
	}
];
function StudioVocals() {
	const lang = useStudio((s) => s.lang);
	const vocalLang = useStudio((s) => s.vocalLang);
	const vocalKind = useStudio((s) => s.vocalKind);
	const nightLane = useStudio((s) => s.nightLane);
	const voiceBank = useStudio((s) => s.voiceBank);
	const fxChain = useStudio((s) => s.fxChain);
	const hook = useStudio((s) => s.hook);
	const lyrics = useStudio((s) => s.lyrics);
	const vocalName = useStudio((s) => s.vocalName);
	const mic = useStudio((s) => s.mic);
	const restoreOn = useStudio((s) => s.restoreOn);
	const tuneAmount = useStudio((s) => s.tuneAmount);
	const processing = useStudio((s) => s.processing);
	const kindBusy = useStudio((s) => s.kindBusy);
	const processNote = useStudio((s) => s.processNote);
	const genre = useStudio((s) => s.genre);
	const pitch = useStudio((s) => s.pitch);
	const voiceCap = useStudio((s) => s.voiceCap);
	const patch = useStudio((s) => s.patch);
	const canMimic = mimicAllowed(voiceCap);
	const busy = processing || kindBusy;
	async function run(kind) {
		if (kind === "kind" && !canMimic) {
			toast.error(t(lang, "rapFirst"));
			return;
		}
		if (kind === "kind") patch({
			kindBusy: true,
			processNote: t(lang, "processing")
		});
		else patch({
			processing: true,
			processNote: t(lang, "processing")
		});
		try {
			const buf = await processCurrent(kind);
			if (!buf) {
				toast.error(kind === "kind" ? t(lang, "rapFirst") : t(lang, "emptyVocal"));
				return;
			}
			await applyProcessedVocal(buf, `${kind}-${vocalName ?? "take"}`);
			toast.success(kind === "kind" ? KIND_LABEL[vocalKind] : kind);
		} catch {
			toast.error(t(lang, "decodeFail"));
		} finally {
			if (kind === "kind") patch({
				kindBusy: false,
				processNote: null
			});
			else patch({
				processing: false,
				processNote: null
			});
		}
	}
	async function onHook() {
		patch({
			processing: true,
			processNote: t(lang, "processing")
		});
		try {
			const res = await writeHook({ data: {
				lang: vocalLang,
				genre,
				seed: hook
			} });
			if (!res.ok) {
				toast.error(res.error);
				return;
			}
			patch({
				lyrics: res.text,
				hook: res.text
			});
		} finally {
			patch({
				processing: false,
				processNote: null
			});
		}
	}
	async function onSpeak() {
		const text = (lyrics || hook).trim();
		if (!text) return;
		patch({
			kindBusy: true,
			processNote: t(lang, "processing")
		});
		try {
			const res = await speakHook({ data: {
				text,
				bank: voiceBank,
				kind: vocalKind,
				lang: vocalLang
			} });
			if (!res.ok) {
				toast.error(res.error);
				return;
			}
			const ctx = getContext();
			if (!ctx) {
				toast.error(t(lang, "needArm"));
				return;
			}
			const bin = atob(res.audio);
			const bytes = new Uint8Array(bin.length);
			for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
			const buf = await ctx.decodeAudioData(bytes.buffer.slice(0));
			let styled = await vocalProcessor.styleKind(buf, vocalKind);
			if (canMimic) styled = await vocalProcessor.formantToward(styled, voiceCap);
			await applyProcessedVocal(styled, `${vocalKind}-tts`);
			toast.success(canMimic ? t(lang, "mimicOn") : t(lang, "tagsOnly"));
		} catch {
			toast.error(t(lang, "decodeFail"));
		} finally {
			patch({
				kindBusy: false,
				processNote: null
			});
		}
	}
	async function onStandin() {
		patch({
			kindBusy: true,
			processNote: t(lang, "processing")
		});
		try {
			await loadNightStandin();
			toast.success(t(lang, "standinOn"));
		} catch {
			toast.error(t(lang, "decodeFail"));
		} finally {
			patch({
				kindBusy: false,
				processNote: null
			});
		}
	}
	function onMeasure() {
		if (!getVocalBuffer()) {
			toast.error(t(lang, "emptyVocal"));
			return;
		}
		const cap = captureVoiceCap();
		toast.success(cap.rapped ? t(lang, "takeLive") : t(lang, "rapFirst"));
	}
	async function onKindTap(id) {
		patch({ vocalKind: id });
		if (!canMimic) return;
		patch({ kindBusy: true });
		try {
			const res = await auditionKind(id);
			if (res === "empty") toast.error(t(lang, "emptyVocal"));
			if (res === "rap") toast.error(t(lang, "rapFirst"));
		} catch {
			toast.error(t(lang, "decodeFail"));
		} finally {
			patch({ kindBusy: false });
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-w-0 flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-col gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-mono text-2xs tracking-[0.18em] text-muted uppercase",
						children: [
							"STEEL · ",
							t(lang, "vocals"),
							" · ",
							t(lang, "gen3")
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-3xl text-ink",
						children: lang === "et" ? "Kümme kätt. Sinu vahemik." : "Ten kinds. Your range."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-w-2xl text-pretty text-muted",
						children: t(lang, "capsLead")
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-[var(--radius-lg)] bg-raised p-4 ring-1 ring-rule",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-2xs tracking-wider text-muted uppercase",
							children: t(lang, "nightLane")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							role: "switch",
							"aria-checked": nightLane,
							"aria-label": t(lang, "nightLane"),
							onClick: () => {
								const next = !nightLane;
								patch({
									nightLane: next,
									vocalKind: next ? "whisper" : vocalKind
								});
								if (next) onStandin();
								else pushAll();
							},
							className: cn("h-7 w-12 rounded-full ring-1 ring-rule", nightLane ? "bg-live" : "bg-paper"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("block size-6 rounded-full bg-ink", nightLane ? "translate-x-5" : "translate-x-0.5") })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 font-mono text-2xs tracking-wider text-muted uppercase",
						children: [
							nightLane ? `${t(lang, "standinOn")} · ` : "",
							t(lang, "quietLead"),
							" · ",
							t(lang, "loudStack")
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "secondary",
						className: "mt-3",
						disabled: kindBusy,
						onClick: () => void onStandin(),
						children: t(lang, "standin")
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-[var(--radius-lg)] bg-raised p-4 ring-1 ring-rule",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-baseline justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-2xs tracking-wider text-muted uppercase",
							children: t(lang, "capsTitle")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: cn("font-mono text-2xs tracking-wider uppercase", canMimic ? "text-live" : "text-faint"),
							children: canMimic ? t(lang, "mimicOn") : t(lang, "mimicOff")
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: canMimic ? t(lang, "takeLive") : t(lang, "tagsOnly")
					}),
					voiceCap.hasTake ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-3 grid grid-cols-3 gap-3 font-mono text-sm tabular-nums",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-2xs tracking-wider text-muted uppercase",
								children: t(lang, "f0")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
								className: "text-ink",
								children: [voiceCap.f0Hz || "—", " Hz"]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-2xs tracking-wider text-muted uppercase",
								children: t(lang, "range")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "text-ink",
								children: voiceCap.f0Min && voiceCap.f0Max ? `${voiceCap.f0Min}–${voiceCap.f0Max}` : "—"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-2xs tracking-wider text-muted uppercase",
								children: "RMS"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "text-ink",
								children: voiceCap.rms.toFixed(3)
							})] })
						]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 flex flex-col gap-2",
						children: VOCAL_KINDS.map((id) => {
							const score = voiceCap.scores[id] ?? 0;
							const pct = Math.max(2, Math.min(100, score * 10));
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex min-w-0 items-center gap-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => patch({ vocalKind: id }),
										className: cn("w-16 shrink-0 text-left font-mono text-2xs tracking-wider uppercase", vocalKind === id ? "text-ink" : "text-muted"),
										children: KIND_LABEL[id]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "h-2 min-w-0 flex-1 overflow-hidden rounded-full bg-paper ring-1 ring-rule",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: cn("h-full rounded-full", canMimic ? "bg-live" : "bg-steel/50"),
											style: { width: `${pct}%` }
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "w-8 shrink-0 text-right font-mono text-2xs tabular-nums text-muted",
										children: score.toFixed(1)
									})
								]
							}, id);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-wrap gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "secondary",
							disabled: kindBusy || !vocalName,
							onClick: onMeasure,
							children: t(lang, "measureTake")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "live",
							disabled: kindBusy || !canMimic,
							onClick: () => void run("kind"),
							children: t(lang, "applyKind")
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-2 font-mono text-2xs tracking-wider text-muted uppercase",
					children: t(lang, "variant")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-3 text-sm text-muted",
					children: t(lang, "hearKind")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-2",
					children: VOCAL_KINDS.map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						disabled: kindBusy,
						onClick: () => void onKindTap(id),
						className: cn("min-h-11 rounded-[var(--radius-sm)] px-3 font-mono text-2xs tracking-wider uppercase ring-1 ring-rule", vocalKind === id ? "bg-ink text-paper" : "text-muted"),
						children: KIND_LABEL[id]
					}, id))
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-[var(--radius-lg)] bg-raised p-4 ring-1 ring-rule",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-2xs tracking-wider text-muted uppercase",
						children: t(lang, "micTitle")
					}),
					mic ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-3 grid grid-cols-2 gap-3 font-mono text-sm tabular-nums",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-2xs tracking-wider text-muted uppercase",
								children: "In"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "truncate text-ink",
								children: mic.label
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-2xs tracking-wider text-muted uppercase",
								children: "Noise"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "text-ink",
								children: mic.noiseFloor.toFixed(3)
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-2xs tracking-wider text-muted uppercase",
								children: "SR"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "text-ink",
								children: mic.sampleRate
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-2xs tracking-wider text-muted uppercase",
								children: "Pitch"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "text-ink",
								children: pitch ? `${Math.round(pitch)} Hz` : "—"
							})] })
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: t(lang, "micNone")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "mt-4 flex min-h-11 items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm",
							children: t(lang, "restoreOn")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							role: "switch",
							"aria-checked": restoreOn,
							onClick: () => {
								patch({ restoreOn: !restoreOn });
								pushAll();
							},
							className: cn("h-7 w-12 rounded-full ring-1 ring-rule", restoreOn ? "bg-live" : "bg-paper"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("block size-6 rounded-full bg-ink", restoreOn ? "translate-x-5" : "translate-x-0.5") })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fader, {
						label: "Tune",
						value: tuneAmount,
						onChange: (v) => {
							patch({ tuneAmount: v });
							pushAll();
						}
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "secondary",
						disabled: processing,
						onClick: () => void run("quantize"),
						children: t(lang, "quantize")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "secondary",
						disabled: processing,
						onClick: () => void run("restore"),
						children: t(lang, "restore")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "secondary",
						disabled: processing,
						onClick: () => void run("harmony"),
						children: t(lang, "harmony")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "secondary",
						disabled: processing,
						onClick: () => void run("choir"),
						children: t(lang, "choir")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "secondary",
						disabled: processing,
						onClick: () => void run("fx"),
						children: t(lang, "fx")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "live",
						disabled: processing,
						onClick: () => void run("tune"),
						children: t(lang, "tune")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "secondary",
						disabled: processing,
						onClick: () => void run("mirror"),
						children: t(lang, "analogMirror")
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-2 font-mono text-2xs tracking-wider text-muted uppercase",
				children: t(lang, "fx")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: CHAINS.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => {
						patch({ fxChain: c.id });
						pushAll();
					},
					className: cn("min-h-11 rounded-[var(--radius-sm)] px-3 text-sm ring-1 ring-rule", fxChain === c.id ? "bg-ink text-paper" : "text-muted"),
					children: t(lang, c.key)
				}, c.id))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-2 font-mono text-2xs tracking-wider text-muted uppercase",
				children: t(lang, "voiceBank")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: BANKS.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => patch({ voiceBank: b.id }),
					className: cn("min-h-11 rounded-[var(--radius-sm)] px-3 text-sm ring-1 ring-rule", voiceBank === b.id ? "bg-ink text-paper" : "text-muted"),
					children: t(lang, b.key)
				}, b.id))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-2 font-mono text-2xs tracking-wider text-muted uppercase",
				children: t(lang, "langVocal")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: VOCAL_LANGS.map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => patch({ vocalLang: id }),
					className: cn("min-h-11 min-w-11 rounded-[var(--radius-sm)] px-3 font-mono text-sm uppercase ring-1 ring-rule", vocalLang === id ? "bg-ink text-paper" : "text-muted"),
					children: id
				}, id))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex flex-col gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-mono text-2xs tracking-wider text-muted uppercase",
					children: t(lang, "hook")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					value: hook,
					rows: 4,
					maxLength: 400,
					onChange: (e) => patch({ hook: e.target.value }),
					className: "min-h-24 rounded-[var(--radius-md)] bg-raised p-3 text-sm text-ink ring-1 ring-rule",
					placeholder: HOOK_PLACEHOLDER[vocalLang]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					disabled: processing,
					onClick: () => void onHook(),
					children: t(lang, "generate")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "secondary",
					disabled: busy || !(lyrics || hook).trim(),
					onClick: () => void onSpeak(),
					children: t(lang, "adlib")
				})]
			}),
			lyrics ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
				className: "whitespace-pre-wrap rounded-[var(--radius-md)] bg-paper p-4 text-sm text-ink ring-1 ring-rule",
				children: lyrics
			}) : null,
			processNote ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-mono text-2xs tracking-wider text-copper uppercase",
				children: processNote
			}) : null
		]
	});
}
var routes_exports = /* @__PURE__ */ __exportAll({ component: () => Home });
function Home() {
	const tab = useStudio((s) => s.tab);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(StudioShell, { children: [
		tab === "desk" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudioDesk, {}) : null,
		tab === "vocals" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudioVocals, {}) : null,
		tab === "visuals" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudioVisuals, {}) : null,
		tab === "matrix" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudioMatrix, {}) : null,
		tab === "monitor" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudioMonitor, {}) : null,
		tab === "kernel" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudioKernelBay, {}) : null,
		tab === "crew" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudioCrew, {}) : null,
		tab === "audit" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SteelAudit, {}) : null,
		tab === "banks" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudioBanks, {}) : null,
		tab === "film" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudioFilm, {}) : null,
		tab === "theory" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudioTheory, {}) : null
	] });
}
//#endregion
export { downloadBlob as a, PLUGIN_IDS as i, EXTRA_IDS as n, formatStampDate as o, BANKS$1 as r, slugify as s, routes_exports as t };
