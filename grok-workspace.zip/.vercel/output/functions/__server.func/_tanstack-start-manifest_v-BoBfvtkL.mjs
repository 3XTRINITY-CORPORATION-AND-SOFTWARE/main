//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BoBfvtkL.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-BIIt1Wyd.js", "/assets/rolldown-runtime-Dd_uD5pT.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BIIt1Wyd.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-OVbiiVqV.js"]
	}
} });
//#endregion
export { tsrStartManifest };
